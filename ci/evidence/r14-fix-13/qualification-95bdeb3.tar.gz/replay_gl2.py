from __future__ import annotations

import datetime
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[1]
PYTHON = str(ROOT / "tls-env/bin/python")
TRUSTED = ROOT / "proof/plan39-trusted"
env = os.environ.copy()
env["PYTHONDONTWRITEBYTECODE"] = "1"
for phase in ("before", "after"):
    target = ROOT / "proof" / ("gate-" + phase)
    out = ROOT / "proof" / phase
    records = []
    for name, command in [
        ("gl2-make-structure", ["make", "structure", "PY=" + PYTHON]),
        ("gl2-trusted-ceiling", [PYTHON, "-I", str(TRUSTED / "scripts/reshape/check_structure_ceiling.py"),
                                 "--root", str(target)]),
    ]:
        started = datetime.datetime.now(datetime.timezone.utc).isoformat()
        print("START", phase, name, flush=True)
        with (out / (name + ".log")).open("w") as stream:
            result = subprocess.run(command, cwd=target, env=env, stdout=stream, stderr=subprocess.STDOUT)
        records.append({"name": name, "command": command, "cwd": str(target), "started_at": started,
                        "exit_code": result.returncode,
                        "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat()})
        (out / "gl2-commands.json").write_text(json.dumps(records, indent=2) + "\n")
        print("END", phase, name, "exit", result.returncode, flush=True)
        print((out / (name + ".log")).read_text(), flush=True)
