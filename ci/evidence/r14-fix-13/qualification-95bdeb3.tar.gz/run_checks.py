from __future__ import annotations

import datetime
import importlib.metadata
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PHASE = sys.argv[1]
REPO = Path(sys.argv[2]).resolve()
OUT = ROOT / "proof" / PHASE
OUT.mkdir(parents=True, exist_ok=True)
PYTHON = str(ROOT / "tls-env/bin/python")
POLICY = "astrid/_tls_policy.py" if PHASE.startswith("before") else "astrid/installer/_tls_policy.py"
CHANGED = [
    POLICY,
    "astrid/core/util/http.py",
    "astrid/core/generation/model_downloader.py",
    "astrid/packs/runpod/pod_watchdog.py",
    "astrid/packs/runpod/h3_release_remote.py",
    "astrid/packs/runpod/h3_release_bootstrap.py",
    "tests/installer/test_tls_fallback.py",
    "tests/test_721_remaining_tls_policy.py",
    "tests/packs/runpod/test_h3_release.py",
]
TLS = [
    "tests/core/util/test_http_trust.py",
    "tests/installer/test_tls_fallback.py",
    "tests/test_721_remaining_tls_policy.py",
    "tests/test_721_urllib_os_tls_policy.py",
    "tests/test_721_tls_review.py",
    "tests/test_721_http_policy_guard.py",
    "tests/test_astrid_error_contract.py",
]
CONTRACT = "tests/test_astrid_error_contract.py::test_to_envelope_omits_code_and_source_type_when_none"
TRANSPORT = [
    "tests/packs/runpod/test_h3_release.py::test_bootstrap_packages_exact_product_sources_deterministically",
    "tests/packs/runpod/test_h3_release.py::test_actual_transport_bootstrap_downloads_and_skips_on_stdlib_only_cold_target",
    "tests/packs/runpod/test_h3_release.py::test_cold_bootstrap_refuses_tampering_before_provision",
    "tests/packs/runpod/test_h3_release.py::test_release_identity_binds_dependencies_and_refuses_stale_wire_source",
]
ENV = os.environ.copy()
for variable in ("SSL_CERT_FILE", "SSL_CERT_DIR"):
    ENV.pop(variable, None)
ENV.update({
    "PYTHONDONTWRITEBYTECODE": "1",
    "PYTHONPATH": str(REPO),
    "ASTRID_RUNTIME_CHECKOUT": "/workspace/scratch/46846b7cc836/astrid-agent.env/runtime",
    "ASTRID_TEST_LIFECYCLE_CHECKOUT": "/workspace/scratch/46846b7cc836/astrid-agent.env/lifecycle",
    "ASTRID_VIBECOMFY_CHECKOUT": "/workspace/scratch/46846b7cc836/astrid-agent.env/vibecomfy",
})

def git(*args: str) -> str:
    return subprocess.check_output(["git", "-C", str(REPO), *args], text=True).strip()

commands = [
    ("tls-policy", [PYTHON, "-m", "pytest", "-q", "-rA", *TLS, "--deselect=" + CONTRACT,
                    "--junitxml=" + str(OUT / "tls-policy.xml")]),
    ("independent-error-contract", [PYTHON, "-m", "pytest", "-q", "-rA", CONTRACT,
                                   "--junitxml=" + str(OUT / "independent-error-contract.xml")]),
    ("transport", [PYTHON, "-m", "pytest", "-q", "-rA", *TRANSPORT,
                   "--junitxml=" + str(OUT / "transport.xml")]),
    ("structure-102", [PYTHON, "-m", "scripts.reshape.compare_structure_baseline", "--baseline",
                       str(ROOT / "proof/gates/structure_ceiling.json")]),
    ("ruff", [PYTHON, "-m", "ruff", "check", "--output-format=json", *CHANGED]),
    ("mypy", [PYTHON, "-m", "mypy", "--no-incremental", "--cache-dir=" + str(OUT / "mypy-cache"),
              "--no-pretty", "--no-error-summary", "--show-error-codes", *CHANGED]),
]
if len(sys.argv) > 3:
    commands = [pair for pair in commands if pair[0] in sys.argv[3:]]
records = []
identity = {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "dirty": git("status", "--porcelain"), "root": str(REPO), "python": PYTHON,
            "cleared_environment": ["SSL_CERT_FILE", "SSL_CERT_DIR"],
            "environment_overrides": {k: ENV[k] for k in ("PYTHONDONTWRITEBYTECODE", "PYTHONPATH",
             "ASTRID_RUNTIME_CHECKOUT", "ASTRID_TEST_LIFECYCLE_CHECKOUT", "ASTRID_VIBECOMFY_CHECKOUT")}}
for name, command in commands:
    print("START", PHASE, name, flush=True)
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (OUT / (name + ".log")).open("w") as stream:
        result = subprocess.run(command, cwd=REPO, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    record = {"name": name, "command": command, "shell_display": shlex.join(command),
              "started_at": start, "finished_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
              "exit_code": result.returncode}
    records.append(record)
    (OUT / "commands.json").write_text(json.dumps({"identity": identity, "commands": records}, indent=2) + "\n")
    print("END", PHASE, name, "exit", result.returncode, flush=True)
    lines = (OUT / (name + ".log")).read_text().splitlines()
    print("\n".join(lines[-8:]), flush=True)
