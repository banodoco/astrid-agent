"""Run the unchanged audit assertion against one deliberately altered source input."""
from __future__ import annotations

import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(sys.argv[1]).resolve()))
from tests import test_721_http_policy_guard as guard

kind = sys.argv[2]
sources = guard._agent_sources()
approved = {**guard.POLICY_OPENINGS, **guard.LOOPBACK_HTTP_OPENINGS}
clean = guard._violations(guard._inventory(sources), approved)
print("Unmodified candidate:", json.dumps(clean, sort_keys=True), flush=True)
assert not any(clean.values()), clean
if kind == "seventh-function":
    path = "astrid/installer/tls_fallback.py"
    original = "request, timeout=timeout, context=http_util.os_trust_ssl_context()"
    replacement = "request, timeout=timeout, context=None"
    assert sources[path].count(original) == 1
    sources[path] = sources[path].replace(original, replacement, 1)
    expected = {
        "new": [],
        "changed": [(path, "urlopen_with_tls_fallback", "urllib.request.urlopen")],
        "stale": [],
    }
elif kind == "new-opening":
    path = "astrid/unapproved_https_probe.py"
    assert path not in sources
    sources[path] = "import httpx\nhttpx.Client(verify=False)\n"
    expected = {"new": [(path, "<module>", "httpx.Client")], "changed": [], "stale": []}
else:
    raise SystemExit("Unknown injection")

observed = guard._violations(guard._inventory(sources), approved)
assert observed == expected, observed
print("Injected source:", json.dumps(observed, sort_keys=True), flush=True)
# Only the scanner's source input changes. The original assertion, expected
# records, scanner logic and on-disk candidate sources remain unchanged.
guard._agent_sources = lambda: sources
guard.test_agent_http_openings_use_the_audited_policy_or_loopback_contract()
raise SystemExit("ERROR: the injected change unexpectedly passed the original assertion")
