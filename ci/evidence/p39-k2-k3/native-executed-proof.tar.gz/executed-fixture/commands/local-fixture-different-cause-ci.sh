node --test --test-reporter=spec --test-reporter-destination=stdout --test-reporter=./scripts/ci/ceiling_node.mjs --test-reporter-destination=stdout custody.test.mjs
