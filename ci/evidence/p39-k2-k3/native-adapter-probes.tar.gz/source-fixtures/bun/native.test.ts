import { test, expect, describe } from 'bun:test';
test('control passes', () => expect(1).toBe(1));
describe('nested identity', () => {
  test('complete failing result', () => expect(process.env.PROBE_READY).toBe('ready'));
});
