import { test, expect } from 'vitest';
test('control passes', () => expect(1).toBe(1));
test('complete failing result', () => expect(process.env.PROBE_READY).toBe('ready'));
