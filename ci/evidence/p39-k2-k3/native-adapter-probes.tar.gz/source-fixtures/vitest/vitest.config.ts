import { defineConfig } from 'vitest/config';
import CeilingVitest from '../../../astrid-app/scripts/ci/ceiling_vitest';
export default defineConfig({ test: { include: ['probes/vitest/*.test.ts'], reporters: ['default', new CeilingVitest()], maxWorkers: 1, fileParallelism: false } });
