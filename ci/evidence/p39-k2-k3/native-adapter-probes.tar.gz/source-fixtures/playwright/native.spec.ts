import { test, expect } from '@playwright/test';
test('control passes', () => expect(1).toBe(1));
test('complete failing result', () => expect(process.env.PROBE_READY).toBe('ready'));
