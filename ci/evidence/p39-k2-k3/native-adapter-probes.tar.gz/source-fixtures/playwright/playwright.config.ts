import { defineConfig } from '@playwright/test';
export default defineConfig({ testDir: '.', reporter: [['list'], ['../../../astrid-app/scripts/ci/ceiling_playwright.ts']], workers: 1, retries: 0, projects: [{ name: 'native-proof' }] });
