printf "unchanged native output\n"
exit 7
