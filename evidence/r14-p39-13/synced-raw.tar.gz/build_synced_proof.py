from __future__ import annotations

import collections
import hashlib
import json
import pathlib
import subprocess
import tarfile

ROOT = pathlib.Path('/workspace/scratch/ed89673be2cd')
RAW = ROOT / 'resume-evidence'
REPO = ROOT / 'astrid-agent'
OUT = REPO / 'evidence/r14-p39-13'
SOURCE = 'c10c0923ec655b38260076b82f1aafa02f2ed4dd'
BASE = '32bd22ee69fc12a46c82de4942b1ed26aeae4dcc'
TARGET = 'tests/core/rendering/test_local_schema.py::test_installed_probe_refuses_a_nonisolated_interpreter'
NEW_PREFIX = 'tests/scripts/test_ci_test_evidence.py::test_external_evidence_preserves_repository_root_and_config_in_both_passes['


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_scope(name, stem='probes'):
    directory = RAW / name
    reference = json.loads((directory / f'{stem}.reference.json').read_text())
    actual = json.loads((directory / f'{stem}.collection.json').read_text())
    events = [json.loads(line) for line in (directory / f'{stem}.jsonl').read_text().splitlines()]
    grouped = collections.defaultdict(list)
    for event in events:
        if event.get('type') == 'report' and not event.get('subtest'):
            grouped[event['nodeid']].append(event)
    outcomes = {}
    for nodeid, rows in grouped.items():
        if any(row['outcome'] == 'failed' and row['when'] != 'call' for row in rows):
            outcome = 'error'
        elif any(row['outcome'] == 'failed' for row in rows):
            outcome = 'failed'
        elif any(row.get('xfail') for row in rows):
            outcome = 'xfail-present'
        elif any(row['outcome'] == 'skipped' for row in rows):
            outcome = 'skipped'
        elif any(row['when'] == 'call' and row['outcome'] == 'passed' for row in rows):
            outcome = 'passed'
        else:
            outcome = 'incomplete'
        outcomes[nodeid] = outcome
    finish = [event for event in events if event.get('type') == 'finish']
    result = {
        'directory': name,
        'command': json.loads((directory / 'command.json').read_text()) if (directory / 'command.json').exists() else reference['invocation'],
        'reference_equals_collection': reference == actual,
        'selected_ids': sorted(reference['selected']),
        'primary_report_ids': sorted(grouped),
        'missing_primary_reports': sorted(set(reference['selected']) - set(grouped)),
        'unexpected_primary_reports': sorted(set(grouped) - set(reference['selected'])),
        'outcomes': dict(sorted(outcomes.items())),
        'outcome_counts': dict(collections.Counter(outcomes.values())),
        'finish_events': finish,
        'raw_returncode': int((directory / 'exit-code.txt').read_text()) if (directory / 'exit-code.txt').exists() else finish[0]['exitstatus'],
        'configuration_headers': {
            suffix: [line for line in (directory / f'{stem}.{suffix}').read_text().splitlines()
                     if line.startswith(('rootdir:', 'configfile:', 'testpaths:'))]
            for suffix in ('reference.log', 'log')
        },
    }
    assert result['reference_equals_collection']
    assert not result['missing_primary_reports'] and not result['unexpected_primary_reports']
    assert len(finish) == 1
    return result


base = read_scope('synced-base-final')
candidate = read_scope('synced-candidate-final')
original_gate = read_scope('original-ci/agent-gate-probes')
first = read_scope('synced-candidate')
second = read_scope('synced-candidate-provisioned')
base_ids, candidate_ids = set(base['selected_ids']), set(candidate['selected_ids'])
added = sorted(candidate_ids - base_ids)
missing = sorted(base_ids - candidate_ids)
changed = {node: {'before': base['outcomes'][node], 'after': candidate['outcomes'][node]}
           for node in sorted(base_ids & candidate_ids)
           if base['outcomes'][node] != candidate['outcomes'][node]}
assert len(base_ids) == 293 and len(candidate_ids) == 297
assert added == [NEW_PREFIX + str(group) + ']' for group in range(1, 5)]
assert not missing
assert changed == {TARGET: {'before': 'failed', 'after': 'passed'}}
assert candidate['outcome_counts'] == {'passed': 278, 'skipped': 19}
assert candidate['raw_returncode'] == 0 and base['raw_returncode'] == 1
assert {node for node, outcome in base['outcomes'].items() if outcome == 'skipped'} == {
    node for node, outcome in candidate['outcomes'].items() if outcome == 'skipped'}
assert len(original_gate['selected_ids']) == 162
assert set(original_gate['selected_ids']) <= candidate_ids
assert all(candidate['outcomes'][node] == 'passed' for node in original_gate['selected_ids'])
assert {node for node, outcome in original_gate['outcomes'].items() if outcome != 'passed'} == set(added)
assert base['command']['source_sha'] == BASE and candidate['command']['source_sha'] == SOURCE

log = (RAW / 'synced-candidate-final/probes.log').read_text()
refusal = ['schema refusal probe: parent isolated=1; child exit=1',
           'probe child isolated=0',
           'RuntimeError: schema validation requires an isolated installed interpreter']
assert all(line in log for line in refusal)
expected_headers = ['rootdir: ' + str(REPO), 'configfile: pyproject.toml']
assert all(all(line in headers for line in expected_headers)
           for headers in candidate['configuration_headers'].values())

def compact(scope, full_outcomes=True):
    result = {key: value for key, value in scope.items()
              if key not in ('selected_ids', 'primary_report_ids', 'outcomes')}
    result['selected_count'] = len(scope['selected_ids'])
    result['primary_report_id_count'] = len(scope['primary_report_ids'])
    result['selected_id_sha256'] = hashlib.sha256(
        ''.join(node + '\n' for node in scope['selected_ids']).encode()).hexdigest()
    result['outcomes' if full_outcomes else 'failed_or_error_outcomes'] = {
        node: outcome for node, outcome in scope['outcomes'].items()
        if full_outcomes or outcome in ('failed', 'error', 'incomplete')}
    return result


archive = OUT / 'synced-raw.tar.gz'
include_dirs = [
    'original-ci', 'reference-census', 'sync-baseline-schema', 'sync-baseline-provisioned',
    'synced-candidate', 'synced-candidate-provisioned', 'synced-base-final',
    'synced-candidate-final', 'environment-repair',
]
include_files = ['advance-receipt.json', 'source-preservation.json', 'sync-baseline-summary.json',
                 'original-ci-terminal/summary.json', 'original-ci-terminal/failure-ids.json',
                 'original-ci-terminal/run.json', 'original-ci-terminal/jobs.json',
                 'original-ci-terminal/artifacts.json', 'original-ci-terminal/branch-runs-snapshot.json',
                 'build_synced_proof.py']
paths = sorted({path for directory in include_dirs for path in (RAW / directory).rglob('*') if path.is_file()}
               | {RAW / name for name in include_files})
with tarfile.open(archive, 'w:gz') as tar:
    for path in paths:
        tar.add(path, arcname=str(path.relative_to(RAW)), recursive=False)
manifest = {str(path.relative_to(RAW)): {'sha256': sha(path), 'bytes': path.stat().st_size} for path in paths}
report = {
    'qualification': 'Focused synced-source proof, frozen for Lead-hosted four-shard dispatch; no full integration or green-CI claim.',
    'tested_source_sha': SOURCE,
    'tested_source_tree': '1b14ebd6da681af4dbdf418914e84e8434977e6c',
    'merge_parents': ['12cf7d8705189f162ca4a1b32fd33600deabce87', BASE],
    'runtime_sha': '2537fed24385ec1c24f48a812e09af4bb63fb794',
    'synced_base': compact(base),
    'candidate': compact(candidate),
    'candidate_vs_synced_base': {'missing_ids': missing, 'added_ids': added, 'changed_outcomes': changed},
    'original_hosted_gate': compact(original_gate),
    'retained_environment_attempts': [compact(first, False), compact(second, False)],
    'refusal_output': refusal,
    'environment_repairs': {
        'mypy': 'Installed repository-pinned mypy==1.17.0 in the private environment. All 13 associated failures clear with unchanged tests.',
        'project': 'Installed editable Agent metadata with --no-deps. Trusted fixture copies lack pyproject.toml; astrid.version uses installed metadata as in hosted CI.',
        'runtime': 'Installed exact synced Runtime and Python client with --no-deps. Isolated structure subprocesses correctly ignore PYTHONPATH and require installed runtime_protocol.',
        'source_or_assertion_changes': False,
    },
    'original_unit': json.loads((RAW / 'original-ci-terminal/summary.json').read_text()),
    'g2_oracle': {'run_id': 44308562424, 'source_sha': '2266c24a8d898ce122da2c9e616a870b3410fe06',
                  'selected_counts': [516, 516, 516, 516], 'selected_union_count': 2064,
                  'canonical_encoding': 'Sorted native IDs; each followed by LF; UTF-8',
                  'canonical_union_sha256': 'eb3b5a73c87c19f15fc51bd3a9c761156514843fffc1928194cf3c7c1389d224',
                  'inventory_receipt': 'reference-census/expected-inventory.json in synced-raw.tar.gz'},
    'g1_shard_3': 'Unavailable. Not reconstructed and not a blocker under Lead6997062550/6997194447.',
    'pending': ['Lead dispatch of all four integration shards on the frozen head',
                'Per-shard/current-reference and executed-ID reconciliation against G2 2064 union, with additions and shard movement explicit',
                'Hosted raw exits, failures and product-cause classification'],
    'inherited_out_of_scope': 'astrid-dev#964 structure ceiling; no repair or allowance change in this packet',
    'preservation': json.loads((RAW / 'source-preservation.json').read_text()),
    'raw_archive': {'file': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size, 'members': manifest},
    'routes': 'Unknown: no authenticated model-usage trace. Packet root performed engineering; a same-model helper collected existing evidence only.',
}
(OUT / 'synced-proof.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'base': base['outcome_counts'], 'candidate': candidate['outcome_counts'],
                  'changed_outcomes': changed, 'added_ids': added, 'archive_bytes': archive.stat().st_size,
                  'archive_sha256': sha(archive), 'members': len(paths)}, indent=2))
