"""Classify observed setup errors only; do not execute or alter their tests."""
import collections
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SOURCE = ROOT / 'hosted-proof/candidate-44454822934'
groups = sorted(json.loads((SOURCE / 'setup-error-preliminary-groups.json').read_text()),
                key=lambda x: (-len(x['rows']), x['key'][0]))

# Deliberate root-authored classifications, based on the preserved raw traces.
# Related G2 rows are not promoted into ownership of new Agent consumers.
classifications = [
 ('Provider-managed edge replacement',
  'astrid/sdk/timeline/_doc_patch.py:372 — validate_submitted_change raises CommandError when whole-document replacement changes managed_edges.',
  'unowned', 'Shared fixture calls _create_fixture at test_commit_runtime_occurrence_media.py:93; no exact G2/current Plan39 row assigns these integration IDs.'),
 ('Missing authentic G5 archive at session scratch path',
  'tests/editing_conformance/test_current_pair_reader.py:68 — archive.read_bytes(); pathlib.py:1044 raises FileNotFoundError.',
  'unowned', '44 consumers share reader(). AE2 provisions a historical Git commit, not this authenticated tarball; no archive bytes or hash assertion changed.'),
 ('Legacy word anchor absent',
  'astrid/sdk/timeline/native_word_anchor.py:172 — raises TimingCompileError("legacy word anchor is missing"); later service.py:3274 only republishes the failure.',
  'unowned', 'Related G2 mechanism RT6.50 (Runtime consumers, R15 RT6 tail). The current Agent setup consumers have no explicit owner assignment; not silently assigned by matching message.'),
 ('CaptureRuntime sees an empty occurrence list',
  'tests/sdk/test_capture_source_runtime.py:41 — occurrence = self.occurrences[0] raises IndexError.',
  'unowned', '16 rendering/capture consumers assume a seeded occurrence after reading the Runtime parent; different from AT9 imported-source checks and SF6d missing verified-host helper.'),
 ('Projection fixture sees empty shot items',
  'tests/sdk/test_timeline_capture_projection.py:316 — item = source_payload["items"][0] raises IndexError.',
  'unowned', 'Nine consumers stop while decorating source fixture items; no cause-specific assigned Plan39 row.'),
 ('Sealed Agent commit source hash differs',
  'tests/editing_conformance/test_inverse_stage_runtime_regressions.py:80 — _assert_source_identity compares commit.py hash f9acfbb1... with expected 2b81e46a....',
  'unowned', 'Seven exact source-byte witnesses; AT9 concerns Runtime checkout/import identity for its named 179 IDs, not these Agent hash literals. No witness was refreshed.'),
 ('Historical text binding declaration/source refused',
  'astrid/sdk/timeline/validation.py:568 — _validate_element_reference calls _fail at :31 because historical text binding requires unchanged declaration and source.',
  'unowned', 'Related G2 Runtime mechanism RT6.55 in the R15 tail; these five Agent setup IDs are newly exposed consumers, not an explicit current ownership assignment.'),
 ('Native-sheet fixture sees empty clips',
  'tests/editing_conformance/test_native_sheet_ordinary_runtime.py:114 — clips[0] in the opaque-fields fixture check raises IndexError.',
  'unowned', 'Four historical-shape setup cases; earlier checks and full trace retained. No stale-fixture versus product-acceptance judgment is claimed.'),
 ('Missing authentic G5 archive at workstation path',
  'tests/sdk/test_timeline_checkout_history_runtime.py:82 — film() raises AssertionError after AUTHENTIC_ARCHIVE.is_file() is false.',
  'unowned', 'Four cases require /home/user/timeline-hub/hub/design/g5-sdk-authentic-capture-20261023-b6069d1d.tar.gz. Same archive basename as cluster2, distinct provisioning path and fixture.'),
 ('Opaque-item patch previous value mismatch',
  'astrid/sdk/timeline/_doc_patch.py:400 — guard raises CommandError("patch previous value does not match").',
  'unowned', 'Four setup commits fail guarded patch comparison before the intended test body; no matching assigned card.'),
 ('Migrated realm not provider/baseline ready',
  'astrid-runtime/runtime_protocol/v33_lifecycle.py:300 — require_ready raises ConflictError while verification is pending.',
  'RT1', 'Same explicit v33 readiness fence and shared mechanism named by Plan39 RT1. These three Agent consumers extend its observed surface; this is not a product fix or a waiver of provider_ready().'),
 ('Fixed Runtime SHA witness differs',
  'tests/editing_conformance/test_gate1_fresh_word_transcript_frontends.py:70 — actual Runtime2537fed2... is compared with fixed f103bb46....',
  'unowned', 'Three pin-equality witnesses, not AT9 root/site-packages mismatches. No repin or witness edit is authorized or performed.'),
 ('Shot item correspondence invalid',
  'astrid/sdk/timeline/_command_state.py:393 — _item_ids raises CommandError("shot item correspondence changed").',
  'unowned', 'Two opaque-item setup variants fail the item identity guard; later service.py:3274 is only the public wrapper.'),
 ('Historical short-lease Runtime commit unavailable',
  'tests/integrations/test_generic_host_runtime_restart.py:30 calls use_runtime(df3d4dd...); tests/helpers/runtime.py:84 emits the missing-commit refusal.',
  'Plan55 LS-7.2 (via Plan39 AE2)', 'Plan39 AE2 explicitly routes these two df3d4dd short-lease cases to LS-7.2. Raw error is message-only; frame is source-located. Fetching that commit previously leaked schema into later tests; no fetch/fixture repair attempted.'),
 ('Provider dependency union omits captured read',
  'astrid/sdk/timeline/sync.py:162 — _http_response raises WorkspaceClientError from the Runtime refusal, then :1160 wraps it as CommitRefused.',
  'unowned', 'First recorded causal response frame. Runtime timeline_commit_auth.py has matching guards at434 and462, but the HTTP trace does not identify which; no exact upstream frame is invented.'),
 ('Opaque transcript seed changes closure/provenance',
  'tests/editing_conformance/native_word_anchor_fixture.py:332 — _retained_case observes seed child exit1; its stderr names emitter.DocumentPatchError: closure membership or provenance changed.',
  'unowned', 'First preserved parent frame. Exact matching raise is source-located at astrid/sdk/timeline/emitter.py:267; pytest truncates the middle of child stderr, so that line is not claimed as an observed child stack frame.'),
 ('Remotion host/worker validation returns no launch',
  'tests/integrations/test_generic_host_remotion_render.py:249 — remotion_launch asserts launch is not None after _prepare_render_validation returns None.',
  'unowned', 'First observable failed assertion; prerequisites passed. No lower causal trace is emitted, so no renderer-input, custody or AT1.x attribution is inferred.'),
 ('Raw patch changes managed closure membership',
  'astrid/sdk/timeline/_doc_patch.py:366 — validate_submitted_change raises CommandError("closure membership and edges require semantic commands").',
  'unowned', 'One current-checkout fixture uses a guarded raw patch before the journey body; separate from whole-replacement edge mismatch at372.'),
 ('Missing configured fixture',
  'tests/integrations/test_pinned_element_render_proof.py:379 — pytest fixture resolution cannot supply configured.',
  'unowned', 'One setup lookup failure; not a dependency collection error and not the SF6d verified-host helper.'),
 ('Missing pod_watchdog_transport fixture',
  'tests/packs/runpod/test_target_selection.py:20 — case fixture requests absent pod_watchdog_transport, reached through retained→small_lease.',
  'unowned', 'One setup lookup failure in test_runpod_host_endpoint_r5.py:261. AT1.4 is the lifecycle checkout environment and does not assign this fixture visibility issue.'),
]
assert len(groups) == len(classifications) == 20
records = []
seen = set()
for i, (group, classification) in enumerate(zip(groups, classifications), 1):
    title, frame, owner, basis = classification
    counts = {str(n): sum(x['shard'] == n for x in group['rows']) for n in range(1, 5)}
    representative = group['rows'][0]
    ids = sorted(x['event']['nodeid'] for x in group['rows'])
    assert len(ids) == len(set(ids))
    assert not seen.intersection(ids)
    seen.update(ids)
    records.append({
        'cluster': f'S{i:02}', 'cause': title, 'counts_by_shard': counts,
        'total': len(ids), 'representative_shard': representative['shard'],
        'representative_id': representative['event']['nodeid'],
        'first_causal_or_observable_frame': frame,
        'owner': owner, 'ownership_basis_and_limits': basis,
        'native_ids': ids, 'representative_raw_diagnostic': representative['event']['detail'],
        'diagnostic_sha256_by_id': {x['event']['nodeid']: hashlib.sha256(x['event']['detail'].encode()).hexdigest() for x in group['rows']},
    })
totals = {str(n): sum(c['counts_by_shard'][str(n)] for c in records) for n in range(1, 5)}
assert totals == {'1': 0, '2': 172, '3': 62, '4': 14}
assert len(seen) == 248
owner_counts = collections.Counter()
for c in records: owner_counts[c['owner']] += c['total']
assert owner_counts['unowned'] == 243
report = {
    'source_run': 44454822934, 'source_sha': '086845def6ec28216384163d835f47d8cebbae81',
    'authority': 'Lead7002163080 item2',
    'plan39_tasks_sha': '3a2b40ae53fe07972706ea3b7180d8cd57d3b522',
    'method': 'Exhaustive partition of primary when=setup,outcome=failed events. Counts are native IDs, not duplicate traceback frames. First causal raise is used where shown; response/fixture frames and source-located inferences are labeled when a deeper trace is missing. No fixes, new row creation or assertion changes.',
    'mapping_limit': 'No setup ID has an exact match in G2 cause_inventory because the integration execution aborted collection there. RT1 is a supported shared-mechanism mapping; AE2 explicitly routes df3d4dd to LS-7.2. Related RT6.50/.55 remain mentioned as candidates, not ownership assignments. No cluster is mislabeled AT9 or SF6d.',
    'counts_by_shard': totals, 'total_setup_error_ids': 248,
    'owner_id_counts': dict(owner_counts), 'clusters': records,
}
(SOURCE / 'setup-error-classification.json').write_text(json.dumps(report, indent=2)+'\n')
lines = ['# Setup-error classification — Lanes 44454822934', '',
         'Read-only classification under Lead 7002163080. All 248 setup-error IDs are included exactly once; none executes its test body. No failure was fixed or hidden.', '',
         '| Cluster | Cause | Shard1 | Shard2 | Shard3 | Shard4 | Owner |',
         '| --- | --- | ---: | ---: | ---: | ---: | --- |']
for c in records:
    lines.append('| '+c['cluster']+' | '+c['cause']+' | '+' | '.join(str(c['counts_by_shard'][str(n)]) for n in range(1,5))+' | '+c['owner']+' |')
lines += ['', 'Counts: **0 / 172 / 62 / 14 = 248**. Explicit/shared ownership: RT1 3; Plan55 LS-7.2 via AE2 2. **Unowned: 243 IDs in18 clusters**, for Lead routing. AT9 and SF6d are not catch-all labels for unrelated setup failures.', '',
          'Ownership is checked against Plan39 tasks at3a2b40ae53fe07972706ea3b7180d8cd57d3b522 and the sealed G2 cause inventory. Related G2 RT6.50/.55 signatures do not establish assignment of these newly visible Agent consumers.', '']
for c in records:
    lines += ['## '+c['cluster']+' — '+c['cause'], '',
              '**Representative native ID** (shard'+str(c['representative_shard'])+'):', '',
              '```text', c['representative_id'], '```', '',
              '**First causal / observable frame:** '+c['first_causal_or_observable_frame'], '',
              '**Owner:** '+c['owner']+'. '+c['ownership_basis_and_limits'], '']
lines += ['Full per-cluster membership, exact representative traces and every diagnostic hash are in setup-error-classification.json. Original artifact JSONL/JUnit and logs retain every raw diagnostic.','']
(SOURCE / 'setup-error-classification.md').write_text('\n'.join(lines))
print(json.dumps({'clusters':len(records),'counts':totals,'owners':dict(owner_counts)},indent=2))
