"""Build the packet's terminal receipt and no-rebase landing proof."""
import ast
import collections
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
HOSTED = HERE.parent / 'candidate-44454822934'
REPO = ROOT / 'astrid-agent'
OUT = HERE / 'deliverables'
OUT.mkdir(exist_ok=True)
MERGE = '1a234537e768fe1641f308433da5bcd05b59f875'
BASE = '68e7aa8593d13eaeb6a55da1d97bed8b494df15b'
OLD = '086845def6ec28216384163d835f47d8cebbae81'
def read(path): return json.loads(path.read_text())
def git(*args): return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()
assert git('rev-parse', 'HEAD') == MERGE
assert git('show', '-s', '--format=%P', MERGE).split() == [OLD, BASE]
assert git('rev-parse', MERGE+'^{tree}') == '202445e1615e0acd7cff1acf5ca6559484e57623'
packet_files = ['scripts/ci/run_pytest.py', 'tests/core/rendering/test_local_schema.py', 'tests/scripts/test_ci_test_evidence.py']
changed = git('diff', '--name-only', BASE, MERGE).splitlines()
assert sorted(x for x in changed if not x.startswith('evidence/r14-p39-13/')) == sorted(packet_files)
assert not git('diff', '--name-only', OLD, MERGE, '--', *packet_files)
packet_hashes = {f: hashlib.sha256((REPO/f).read_bytes()).hexdigest() for f in packet_files}

local = {}
for side, count in [('base',293), ('candidate',297)]:
    folder = HERE / ('focused-'+side)
    invocation = read(folder/'invocation.json')
    ref, execution = read(folder/'probes.reference.json'), read(folder/'probes.collection.json')
    assert ref == execution and len(ref['selected']) == count
    events = [json.loads(l) for l in (folder/'probes.jsonl').read_text().splitlines()]
    reports = [e for e in events if e['type']=='report' and not e.get('subtest')]
    by = collections.defaultdict(list)
    for e in reports: by[e['nodeid']].append(e)
    assert set(by) == set(ref['selected']) and len(by)==count
    outcomes = {}
    for native_id, rows in by.items():
        if any(e['outcome']=='failed' and e['when']!='call' for e in rows): outcome='ERROR'
        elif any(e['outcome']=='failed' for e in rows): outcome='FAILED'
        elif any(e['outcome']=='skipped' for e in rows): outcome='SKIPPED'
        else:
            assert any(e['when']=='call' and e['outcome']=='passed' for e in rows)
            outcome='PASSED'
        outcomes[native_id]=outcome
    finish = [e for e in events if e['type']=='finish']
    assert len(finish)==1 and finish[0]['exitstatus']==invocation['raw_returncode']==1
    capture_folder=folder/'runner-temp/failure-ceiling'/('local-packet-focused-'+side)/'packet-focused'
    capture=read(capture_folder/'command.json')
    assert capture['head']==invocation['source_sha'] and capture['complete'] and capture['raw_exit']==1
    natives=[]
    for f in sorted(capture_folder.glob('pytest-*.jsonl')):
        ev=[json.loads(l) for l in f.read_text().splitlines()]
        assert ev[0]['event']=='start' and ev[-1]['event']=='finish'
        census=[e for e in ev if e['event']=='collection']
        assert len(census)==1 and collections.Counter(census[0]['nodeids'])==collections.Counter(ref['selected'])
        assert not any(e['event']=='collection_error' for e in ev)
        if ev[0]['collect_only']:
            assert ev[-1]['exitstatus']==0 and not any(e['event']=='report' for e in ev)
        else:
            assert ev[-1]['exitstatus']==1
            observed=collections.Counter((e['native_id'],e['stage'],e['outcome']) for e in ev if e['event']=='report')
            expected=collections.Counter((e['nodeid'],e['when'],e['outcome']) for e in reports)
            assert observed==expected
        natives.append({'file':str(f.relative_to(folder)), 'collect_only':ev[0]['collect_only'],
                        'raw_exit':ev[-1]['exitstatus'],'collected':ev[-1]['collected']})
    assert sorted(n['collect_only'] for n in natives)==[False,True]
    headers={}
    for name in ('probes.reference.log','probes.log'):
        lines=(folder/name).read_text().splitlines()
        header={prefix[:-2]:next(l[len(prefix):] for l in lines if l.startswith(prefix)) for prefix in ('rootdir: ','configfile: ')}
        assert header=={'rootdir':invocation['cwd'],'configfile':'pyproject.toml'}
        headers[name]=header
    local[side]={'invocation':invocation,'selected_reported_ids':count,'outcome_counts':dict(collections.Counter(outcomes.values())),
                 'outcomes':outcomes,'headers':headers,'raw_exit':1,'capture':capture,'native_reporters':natives,
                 'failed_reports':[e for e in reports if e['outcome']=='failed']}
oldmap,newmap=local['base']['outcomes'],local['candidate']['outcomes']
assert set(oldmap)<=set(newmap)
additions=sorted(set(newmap)-set(oldmap))
assert len(additions)==4 and all('test_external_evidence_preserves_repository_root_and_config_in_both_passes[' in x and newmap[x]=='PASSED' for x in additions)
changes=[{'nodeid':i,'base':oldmap[i],'candidate':newmap[i]} for i in oldmap if oldmap[i]!=newmap[i]]
assert changes==[{'nodeid':'tests/core/rendering/test_local_schema.py::test_installed_probe_refuses_a_nonisolated_interpreter','base':'FAILED','candidate':'PASSED'}]
assert {i for i,o in oldmap.items() if o=='SKIPPED'}=={i for i,o in newmap.items() if o=='SKIPPED'}
assert len([i for i,o in newmap.items() if o=='SKIPPED'])==19
newlog=(HERE/'focused-candidate/probes.log').read_text()
for line in ['schema refusal probe: parent isolated=1; child exit=1','probe child isolated=0','RuntimeError: schema validation requires an isolated installed interpreter']:
    assert line in newlog
comparator=read(HERE/'comparator-probes/invocation.json')
assert comparator['raw_returncode']==0
assert 'Ran 30 tests' in (HERE/'comparator-probes/output.log').read_text()
assert (HERE/'comparator-probes/output.log').read_text().rstrip().endswith('OK')
hosted=read(HOSTED/'root-independent-verification-all.json')
assert hosted['total_ids']==2067 and hosted['completed_calls']==1818 and not hosted['g2_losses']
clusters=read(HOSTED/'setup-error-classification.json')
assert clusters['total_setup_error_ids']==248
history=read(HOSTED/'g1-available-outcome-reconciliation-all.json')
summary={
    'packet':'R14-P39-13','tasks':['AT1.9','AT1.54'],'status':'Frozen landing submission for Lead review; hosted outcomes remain red and further dispatch belongs to Lead.',
    'tested_merge':MERGE,'tested_tree':git('rev-parse',MERGE+'^{tree}'),'ordered_parents':[OLD,BASE],
    'destination':BASE,'no_rebase':True,'packet_files_preserved_from_hosted_head':packet_hashes,
    'hosted':hosted,'hosted_custody':read(HOSTED/'receipt-all-shards.json'),
    'setup_classification':{k:v for k,v in clusters.items() if k!='clusters'},
    'setup_clusters':[{k:v for k,v in c.items() if k not in ('representative_raw_diagnostic','diagnostic_sha256_by_id')} for c in clusters['clusters']],
    'local':local,'local_comparison':{'missing':[],'new_failures':[],'changes':changes,'added_ids':additions},
    'new_comparator_tests':{'count':30,'raw_exit':0,'invocation':comparator},
    'historical_comparison':{'basis':history['scope'],'unchanged':history['unchanged'],'changes':[{k:v for k,v in c.items() if k!='detail'} for c in history['changes']], 'no_available_g1_outcome_count':len(history['no_available_g1_outcome'])},
    'limits':[
        'Two workflow expectation tests fail identically on68e7 and the merge, with raw exit1; neither changed or hidden.',
        'Hosted integration proves old086 against32bd; local captured proof covers the new68 merge. No new-head hosted result or ceiling qualification is claimed.',
        'G1 shard3 is unavailable and not reconstructed.',
        'Shard3 full Actions setup/job log unavailable; complete child reference/execution logs and native evidence retained. Its independently observed dependency checkout tuple is unknown.',
        'Local capture journal sees the Agent checkout only; Runtime2537fed2 is independently recorded in invocation metadata and installed from runtime-sync. This is explicitly local proof, not a complete hosted dependency-tuple witness.',
        'Plan39 comparator activation/required-check gap#984 and structure issue#964 remain outside this packet.',
    ]}

# Raw selection, per-ID reports and logs are retained. The large full-repository
# collection arrays remain in the original hashed hosted artifacts. Nothing is
# presented as an unmodified complete JSONL when its collection event is omitted.
members={}
def add(name,path): members[name]=path.read_bytes()
for side in ('base','candidate'):
    folder=HERE/('focused-'+side)
    for f in sorted(folder.rglob('*')):
        if f.is_file(): add('local/'+side+'/'+str(f.relative_to(folder)),f)
for f in sorted((HERE/'comparator-probes').iterdir()): add('local/comparator/'+f.name,f)
for name in ['receipt-all-shards.json','reference-reconciliation-all-shards.json','root-independent-verification-all.json',
             'root-outcomes-all.json','failure-index-all-shards.json','setup-error-classification.json','setup-error-classification.md',
             'g1-available-outcome-reconciliation-all.json']:
    add('hosted/'+name,HOSTED/name)
for n in range(1,5):
    folder=HOSTED/f'shard-{n}'
    for name in ['integration.log','integration.reference.log','reference-selected-ids.json','receipt.json']:
        add(f'hosted/shard-{n}/'+name,folder/name)
    event_lines=[]
    for line in (folder/'integration.jsonl').read_text().splitlines():
        if json.loads(line)['type']!='collection': event_lines.append(line)
    members[f'hosted/shard-{n}/native-reports-without-collection-array.jsonl']=('\n'.join(event_lines)+'\n').encode()
for name in ('decision.json','run.json','jobs.json','artifacts.json','dev_sha.md','tasks.md','run_contract.md'):
    add('authority/'+name,HERE/name)
add('builders/classify_setup.py',HERE/'classify_setup.py')
add('builders/run_focused.py',HERE/'run_focused.py')
add('builders/build_landing_proof.py',Path(__file__))
manifest={name:{'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(members.items())}
members['raw-member-manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
archive=OUT/'landing-raw.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as z:
        with tarfile.open(fileobj=z,mode='w') as tar:
            for name,data in sorted(members.items()):
                info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive,'r:gz') as tar:
    assert set(tar.getnames())==set(members)
    for name,meta in manifest.items():
        data=tar.extractfile(name).read();assert len(data)==meta['bytes'] and hashlib.sha256(data).hexdigest()==meta['sha256']
summary['raw_archive']={'name':archive.name,'bytes':archive.stat().st_size,'members':len(members),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'member_hashes':manifest}
(OUT/'landing-proof.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'setup-error-classification.md').write_text((HOSTED/'setup-error-classification.md').read_text())
print(json.dumps({'archive':summary['raw_archive'] | {'member_hashes':'stored'},'local_counts':{s:local[s]['outcome_counts'] for s in local},'changes':changes,'additions':additions},indent=2))
