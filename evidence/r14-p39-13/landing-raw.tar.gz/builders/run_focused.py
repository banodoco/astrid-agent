"""Retain a local paired proof through the unchanged new Actions capture shell."""
import datetime
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys

root = Path(__file__).resolve().parents[2]
side = sys.argv[1]
checkout = root / ('landing-baseline' if side == 'base' else 'astrid-agent')
directory = Path(__file__).resolve().parent / ('focused-' + side)
directory.mkdir(parents=True, exist_ok=False)
python = root / 'proof-env/bin/python'
files = [
    'tests/reshape/test_identity_gate.py',
    'tests/scripts/test_ci_test_evidence.py',
    'tests/test_release_branch_workflows.py',
    'tests/scripts/test_gate_integrity.py',
    'tests/scripts/test_gate_base.py',
    'tests/reshape/test_structure_ceiling.py',
    'tests/core/rendering/test_local_schema.py',
    'tests/test_skip_guard.py',
]
command = [str(python), '-P', '-m', 'ci.run_pytest', '-p', 'ceiling_pytest',
           '-v', '-rA', '--junitxml=' + str(directory / 'probes.xml'), *files]
script = directory / 'command.sh'
script.write_text(shlex.join(command) + '\n')
environment = dict(os.environ)
for key in ('CEILING_REPORTER_ACTIVE', 'CEILING_STEP_DIR'):
    environment.pop(key, None)
overrides = {
    'PYTHONPATH': str(checkout / 'scripts') + os.pathsep + str(root / 'runtime-sync'),
    'ASTRID_RUNTIME_CHECKOUT': str(root / 'runtime-sync'),
    'RUNNER_TEMP': str(directory / 'runner-temp'),
    'GITHUB_WORKSPACE': str(checkout),
    'GITHUB_REPOSITORY': 'banodoco/astrid-agent',
    'GITHUB_JOB': 'local-packet-focused-' + side,
    'GITHUB_RUN_ID': 'local-r14-p39-13-68e7',
    'GITHUB_RUN_ATTEMPT': '1',
    'ASTRID_CI_MATRIX': '0',
}
environment.update(overrides)
outer = [str(python), '-I', str(checkout / 'scripts/ci/ceiling_capture.py'),
         '--step', 'packet-focused', '--matrix', '0', '--shell', 'bash', str(script)]
receipt = {'kind': 'LOCAL, not a hosted run', 'side': side, 'cwd': str(checkout),
           'argv': outer, 'captured_inner_argv': command, 'environment_overrides': overrides,
           'inherited_pytest_addopts': environment.get('PYTEST_ADDOPTS', ''),
           'source_sha': subprocess.check_output(['git', '-C', str(checkout), 'rev-parse', 'HEAD'], text=True).strip(),
           'source_tree': subprocess.check_output(['git', '-C', str(checkout), 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
           'runtime_sha': subprocess.check_output(['git', '-C', str(root / 'runtime-sync'), 'rev-parse', 'HEAD'], text=True).strip(),
           'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
(directory / 'invocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
with (directory / 'outer.log').open('wb') as output:
    result = subprocess.run(outer, cwd=checkout, env=environment, stdout=output,
                            stderr=subprocess.STDOUT, check=False)
receipt.update(raw_returncode=result.returncode,
               finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(directory / 'invocation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'side': side, 'raw_returncode': result.returncode,
                  'source_sha': receipt['source_sha'], 'log': str(directory / 'outer.log')}), flush=True)
raise SystemExit(result.returncode)
