$ErrorActionPreference = 'stop'
python -u scripts/ci_windows_journey.py install --installer-shell powershell.exe
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
