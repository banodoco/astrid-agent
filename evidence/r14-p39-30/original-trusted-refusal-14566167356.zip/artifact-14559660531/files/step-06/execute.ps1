$ErrorActionPreference = 'stop'
$agentRef = git rev-parse HEAD
$runtimeRef = git -C journey-runtime rev-parse HEAD
$appRef = git -C journey-app rev-parse HEAD
@(
  "## Effective checked-out refs"
  "- Agent: $agentRef"
  "- Runtime: $runtimeRef"
  "- App: $appRef"
) | Add-Content -Path $env:GITHUB_STEP_SUMMARY

if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
