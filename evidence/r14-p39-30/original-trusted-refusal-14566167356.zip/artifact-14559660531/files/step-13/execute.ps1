$ErrorActionPreference = 'stop'
python -u scripts/ci_windows_journey.py down
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
