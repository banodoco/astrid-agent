$ErrorActionPreference = 'stop'
python -m pip install py-spy==0.4.2
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
