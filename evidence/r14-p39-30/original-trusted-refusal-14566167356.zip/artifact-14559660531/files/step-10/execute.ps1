$ErrorActionPreference = 'stop'
python -u scripts/ci_windows_journey.py health
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
