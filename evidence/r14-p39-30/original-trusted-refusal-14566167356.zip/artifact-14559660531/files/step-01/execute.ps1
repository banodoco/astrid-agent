$ErrorActionPreference = 'stop'
$appRef = if ([string]::IsNullOrWhiteSpace($env:INPUT_APP_REF)) { "main" } else { $env:INPUT_APP_REF.Trim() }
if (-not [string]::IsNullOrWhiteSpace($env:INPUT_APP_REF) -and $appRef -notmatch '^[0-9a-fA-F]{40}$') {
  throw "app_ref must be a full 40-character commit SHA (or empty for main)"
}
"ref=$appRef" >> $env:GITHUB_OUTPUT

if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
