$ErrorActionPreference = 'stop'
python -u scripts/ci_windows_journey.py host
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
