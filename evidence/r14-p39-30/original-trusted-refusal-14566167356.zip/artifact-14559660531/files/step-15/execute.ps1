$ErrorActionPreference = 'stop'
python -u scripts/ci_windows_journey.py collect
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
