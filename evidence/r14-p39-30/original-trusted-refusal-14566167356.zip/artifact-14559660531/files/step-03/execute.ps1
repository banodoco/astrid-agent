$ErrorActionPreference = 'stop'
$lock = Get-Content runtime.lock.json -Raw | ConvertFrom-Json
$runtimeRef = $lock.source_commit
if ($runtimeRef -notmatch '^[0-9a-f]{40}$') {
  throw "runtime.lock.json source_commit is not a full commit SHA"
}
"ref=$runtimeRef" >> $env:GITHUB_OUTPUT

if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
