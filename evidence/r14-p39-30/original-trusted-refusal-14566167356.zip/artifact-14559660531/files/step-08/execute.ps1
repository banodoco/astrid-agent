$ErrorActionPreference = 'stop'
python -u scripts/ci_windows_journey.py install --installer-shell pwsh.exe
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
