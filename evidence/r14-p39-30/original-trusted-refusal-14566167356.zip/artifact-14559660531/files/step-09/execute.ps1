$ErrorActionPreference = 'stop'
python -u scripts/ci_windows_journey.py start
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
