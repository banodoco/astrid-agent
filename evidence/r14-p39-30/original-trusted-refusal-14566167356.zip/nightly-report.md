## Plan 39 merge failure ceiling: FAIL

Candidate: `banodoco/astrid-agent@e84bbd52725cba1da7ac655771f840cb7af25fc2`

D4 consumer: Lead posts new red to banodoco/astrid-dev#971 (decision 6998123631).

- errors: aggregate collection did not complete
- unknown: unqualified workflow CI / run 44580875391: status=in_progress, conclusion=None
- unknown: ('Chat service', 'windows-launchers'): Bun terminal summary missing/truncated
- unknown: ('Windows task host journey', 'Windows task host journey (powershell.exe)'): unresolved installed/dependency custody: App installer ref defaults to mutable main; installed Agent/Runtime are selected App manifest revisions, not sibling checkouts. An installed tuple receipt and reviewed expected pins are required.
- unknown: ('Windows task host journey', 'Windows task host journey (pwsh.exe)'): unresolved installed/dependency custody: App installer ref defaults to mutable main; installed Agent/Runtime are selected App manifest revisions, not sibling checkouts. An installed tuple receipt and reviewed expected pins are required.
Covered failures: 0; retirements: 0.
