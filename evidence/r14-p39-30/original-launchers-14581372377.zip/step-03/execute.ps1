$ErrorActionPreference = 'stop'
bun test --reporter=junit --reporter-outfile="$env:CEILING_STEP_DIR/bun-results.xml" ./astrid/chat/discoveryProbe.test.ts ./astrid/chat/astridAcpLauncher.windows.test.ts ./astrid/chat/acpProcessHost.test.ts
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
