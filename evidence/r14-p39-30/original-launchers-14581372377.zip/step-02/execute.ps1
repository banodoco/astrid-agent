$ErrorActionPreference = 'stop'
npm ci --ignore-scripts
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
