$ErrorActionPreference = 'stop'
$tokens = $null
$errors = $null
foreach ($script in Get-ChildItem scripts/diagnostics/windows_acp_*.ps1) {
  [System.Management.Automation.Language.Parser]::ParseFile(
    $script.FullName, [ref]$tokens, [ref]$errors) | Out-Null
  if ($errors.Count) { throw ($errors | Out-String) }
}

if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
