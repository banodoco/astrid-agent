$ErrorActionPreference = 'stop'
bun test --reporter=junit --reporter-outfile="$env:CEILING_STEP_DIR/bun-results.xml" ./astrid/chat/astrid-agent-models.test.ts -t "model discovery allows sequential OMP startup"
if (Test-Path -LiteralPath variable:\LASTEXITCODE) { exit $LASTEXITCODE }
