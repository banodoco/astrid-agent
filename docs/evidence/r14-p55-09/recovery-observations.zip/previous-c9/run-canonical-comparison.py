from __future__ import annotations

import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/scratch/ca43cabc591b/proof/previous-c9')
OUT = ROOT / 'comparison'
PRODUCT_ROOT = Path('/workspace/scratch/ca43cabc591b/astrid-agent')
DEV = '/workspace/scratch/984232aa1788/astrid-dev'
DEV_SHA = '4223b30a2b56c7eb59da3a47b200516372bdca5a'
BASE_SHA = '91cb4cb499306b2f09686de0fb67b803bcb89077'
HEAD_SHA = 'c9f7940bf10f08c0d04ddecee3fef6798b867176'
OUT.mkdir(exist_ok=True)

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

sorter = subprocess.check_output(['git', '-C', DEV, 'show', DEV_SHA + ':env/baseline-diff.py'])
sorter_path = OUT / 'baseline-diff.py'
sorter_path.write_bytes(sorter)
sorter_blob = subprocess.check_output(['git', '-C', DEV, 'rev-parse', DEV_SHA + ':env/baseline-diff.py'], text=True).strip()
jobs = {'linux': 135084332309, 'macos': 135084332835, 'windows': 135084333007, 'native': 135084333040}
receipts = []
results = []

for platform, job in jobs.items():
    source_path = ROOT / f'job-{job}.log'
    raw = source_path.read_bytes()
    source_lines = raw.decode('utf-8').splitlines()
    lines = [re.sub(r'^\S+Z ', '', re.sub(r'\x1b\[[0-9;]*m', '', line)) for line in source_lines]
    current_label = None
    active = None
    sections = {}
    for index, line in enumerate(lines):
        match = re.search(r'generated xml file: .*?proof[\\/]([^\\/]+)\.xml', line)
        if match:
            current_label = match.group(1)
        if re.fullmatch(r'=+ short test summary info =+', line.strip()):
            assert current_label is not None, (job, index, 'summary has no XML label')
            assert active is None, (job, index, 'nested summary')
            active = {'label': current_label, 'start': index, 'lines': [line]}
            continue
        if active is not None:
            active['lines'].append(line)
            if re.match(r'^=+ .*\d+ (?:failed|passed|error|skipped)', line):
                label = active['label']
                assert label not in sections, (job, label, 'duplicate final summary')
                active['end'] = index
                sections[label] = active
                active = None
    assert active is None, (job, 'incomplete summary')
    groups = [('base-managed', 'head-managed'), ('base-contention', 'head-contention')] if platform == 'native' else [('base', 'head'), ('base-vibe', 'head-vibe')]
    saved = {}
    for label in [x for pair in groups for x in pair]:
        section = sections[label]
        data = ('\n'.join(section['lines']) + '\n').encode('utf-8')
        path = OUT / f'{platform}-{label}-final-summary.log'
        path.write_bytes(data)
        saved[label] = path
        receipts.append({
            'platform': platform, 'job_id': job, 'label': label,
            'source_log': str(source_path), 'source_log_sha256': digest(raw),
            'source_start_line': section['start'] + 1, 'source_end_line': section['end'] + 1,
            'transform': 'Remove GitHub timestamp prefix and ANSI colour sequences only; retain exact complete final pytest summary after its generated XML marker.',
            'summary_path': str(path), 'summary_sha256': digest(data),
        })
    base_paths = [str(saved[base]) for base, _ in groups]
    head_paths = [str(saved[head]) for _, head in groups]
    destination = OUT / platform
    command = [sys.executable, '-I', str(sorter_path), '--baseline', '91cb4cb4=' + ','.join(base_paths), '--candidate', ','.join(head_paths), '--out', str(destination)]
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    run = subprocess.run(command, cwd=PRODUCT_ROOT, capture_output=True, text=True)
    end = datetime.datetime.now(datetime.timezone.utc).isoformat()
    (OUT / f'{platform}-sorter.stdout').write_text(run.stdout)
    (OUT / f'{platform}-sorter.stderr').write_text(run.stderr)
    (OUT / f'{platform}-sorter.exit').write_text(str(run.returncode) + '\n')
    assert run.returncode in (0, 1), (platform, run.returncode, run.stderr)
    buckets = {name: (destination / (name + '.txt')).read_text().splitlines() for name in ('regression', 'no-baseline', 'preexisting', 'fixed', 'missing')}
    receipt = {'platform': platform, 'job_id': job, 'argv': command, 'cwd': str(PRODUCT_ROOT), 'started_at': start, 'finished_at': end, 'raw_exit': run.returncode, 'base_sha': BASE_SHA, 'head_sha': HEAD_SHA, 'buckets': buckets, 'summary': (destination / 'summary.md').read_text()}
    (OUT / f'{platform}-command.json').write_text(json.dumps(receipt, indent=2) + '\n')
    results.append(receipt)

manifest = {'sorter': {'repo': 'banodoco/astrid-dev', 'commit': DEV_SHA, 'path': 'env/baseline-diff.py', 'git_blob': sorter_blob, 'sha256': digest(sorter)}, 'run_id': 44384238876, 'base_sha': BASE_SHA, 'head_sha': HEAD_SHA, 'extractions': receipts, 'results': results}
(OUT / 'receipts.json').write_text(json.dumps(manifest, indent=2) + '\n')
for result in results:
    print(json.dumps({'platform': result['platform'], 'exit': result['raw_exit'], 'counts': {k: len(v) for k, v in result['buckets'].items()}, 'regressions': result['buckets']['regression'], 'fixed': result['buckets']['fixed'], 'summary': result['summary']}))
