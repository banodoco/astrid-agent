| Side | Tests run |
|---|---|
| base | 575 |
| candidate | 575 |

| Bucket | Count |
|---|---|
| regression | 1 |
| no-baseline | 0 |
| preexisting | 146 |
| fixed | 0 |
| missing | 0 |
