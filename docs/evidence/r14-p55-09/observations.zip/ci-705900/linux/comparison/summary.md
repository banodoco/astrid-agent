| Side | Tests run |
|---|---|
| base | 625 |
| candidate | 625 |

| Bucket | Count |
|---|---|
| regression | 4 |
| no-baseline | 0 |
| preexisting | 12 |
| fixed | 0 |
| missing | 0 |
