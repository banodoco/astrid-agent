| Side | Tests run |
|---|---|
| 493616c1 | 43 |
| candidate | 43 |

| Bucket | Count |
|---|---|
| regression | 0 |
| no-baseline | 0 |
| preexisting | 2 |
| fixed | 0 |
| missing | 0 |
