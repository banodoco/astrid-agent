| Side | Tests run |
|---|---|
| 493616c1 | 582 |
| candidate | 582 |

| Bucket | Count |
|---|---|
| regression | 0 |
| no-baseline | 0 |
| preexisting | 10 |
| fixed | 0 |
| missing | 0 |
