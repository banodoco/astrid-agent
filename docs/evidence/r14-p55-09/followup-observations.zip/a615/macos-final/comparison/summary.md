| Side | Tests run |
|---|---|
| base | 582 |
| candidate | 582 |

| Bucket | Count |
|---|---|
| regression | 0 |
| no-baseline | 0 |
| preexisting | 32 |
| fixed | 0 |
| missing | 0 |
