| Side | Tests run |
|---|---|
| base | 43 |
| candidate | 43 |

| Bucket | Count |
|---|---|
| regression | 4 |
| no-baseline | 0 |
| preexisting | 2 |
| fixed | 0 |
| missing | 0 |
