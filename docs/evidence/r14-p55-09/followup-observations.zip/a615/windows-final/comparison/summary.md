| Side | Tests run |
|---|---|
| base | 575 |
| candidate | 575 |

| Bucket | Count |
|---|---|
| regression | 0 |
| no-baseline | 0 |
| preexisting | 146 |
| fixed | 1 |
| missing | 0 |
