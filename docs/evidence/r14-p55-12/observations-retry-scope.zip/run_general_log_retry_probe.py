"""Record the same scratch diagnostic against a selected source pair."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


base = Path("/workspace/scratch/8c30ce2383b9")
label = sys.argv[1]
agent, runtime, expected_agent, expected_runtime = {
    "base": (base / "agent-base", base / "runtime-base",
             "91cb4cb499306b2f09686de0fb67b803bcb89077", "f3dc970af71e7d413871b4a8e45e4ba0fbfabf5e"),
    "current": (base / "astrid-agent", base / "astrid-runtime",
                "98bc60dcd8306a5a3e740653d7b308693d668425", "2a1626a265bb3cabf3db82b03eebeeec04209ccd"),
}[label]
probe = base / "proof/test_general_log_retry_probe.py"
stem = base / ("proof/general-log-retry-" + label)
command = [str(base / "test-env/bin/python"), "-m", "pytest", "-q", "-rA", "-m", "integration",
           "-c", str(agent / "pyproject.toml"),
           str(probe) + "::test_ordinary_action_durable_logs_survive_owner_retry",
           "--basetemp=" + str(stem) + "-tmp", "--junitxml=" + str(stem) + ".xml"]
explicit_environment = {
    "ASTRID_RUNTIME_CHECKOUT": str(runtime),
    "PYTHONPATH": os.pathsep.join(map(str, (agent, runtime / "packages/python", runtime))),
    "LS6_PROBE_EVIDENCE_PATH": str(stem) + "-selected-evidence.json",
}
environment = os.environ.copy()
environment.update(explicit_environment)
paths = [probe, Path(__file__), agent / "pyproject.toml", agent / "tests/conftest.py",
         agent / "tests/helpers/runtime.py", agent / "astrid/core/execution/generic_host.py",
         agent / "astrid/core/_shared/result_manifest.py", agent / "astrid_runtime_client/generated.py",
         agent / "runtime.lock.json", runtime / "runtime_protocol/store.py",
         runtime / "runtime_protocol/service.py", runtime / "runtime_protocol/server.py",
         runtime / "runtime_protocol/daemon.py", runtime / "packages/python/astrid_runtime_client/generated.py",
         base / "astrid-agent/tests/core/execution/test_ls6_thumbnail_recovery.py"]


def sources():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in paths}


def identities():
    result = {}
    for repo in (agent, runtime):
        result[str(repo)] = {
            "revision": subprocess.check_output(["git", "rev-parse", "HEAD", "HEAD^{tree}"], cwd=repo, text=True).splitlines(),
            "status": subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=repo, text=True).splitlines(),
            "tracked_diff_sha256": hashlib.sha256(subprocess.check_output(["git", "diff", "--binary", "HEAD"], cwd=repo)).hexdigest(),
        }
    return result


metadata = {"command": command, "cwd": str(agent), "environment": explicit_environment,
            "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "identity_before": identities(), "sources_before": sources()}
assert metadata["identity_before"][str(agent)]["revision"][0] == expected_agent
assert metadata["identity_before"][str(runtime)]["revision"][0] == expected_runtime
assert metadata["sources_before"][str(paths[-1])] == "25cbc33f4e0527279f6e1598df9b8d4873ecb4f43f98e53b907b33c69d9514ac"
print(json.dumps({"label": label, "command": command, "identity": metadata["identity_before"],
                  "probe_sha256": metadata["sources_before"][str(probe)]}), flush=True)
with Path(str(stem) + ".log").open("w", encoding="utf-8") as stream:
    completed = subprocess.run(command, cwd=agent, env=environment, stdout=stream, stderr=subprocess.STDOUT)
metadata.update(exit_code=completed.returncode,
                finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                identity_after=identities(), sources_after=sources())
metadata["sources_unchanged"] = metadata["sources_before"] == metadata["sources_after"]
Path(str(stem) + ".json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"label": label, "exit_code": completed.returncode,
                  "sources_unchanged": metadata["sources_unchanged"], "metadata": str(stem) + ".json"}), flush=True)
print("\n".join(Path(str(stem) + ".log").read_text().splitlines()[-16:]), flush=True)
raise SystemExit(completed.returncode)
