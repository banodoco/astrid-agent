"""Temporary LS-6 diagnosis: ordinary durable logs across owner retry.

Run unchanged against each prescribed Agent/Runtime pair. This probe uses the
selected Agent checkout's canonical real_runtime and process-owner fixtures;
it changes no repository fixture, test, or product code.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from pathlib import Path

import pytest

import astrid
import astrid_runtime_client
from astrid.core.execution import generic_host
from astrid.core.execution.generic_host import GenericPackHost, HostError, RuntimeProtocolClient
from astrid.pack_api import VERSION as PACK_API_VERSION
from astrid_runtime_client import WorkspaceClient
from tests.conftest import owned_process_groups, real_runtime  # noqa: F401


pytestmark = pytest.mark.integration
CAPABILITY = "ls6_general_retry.echo"
OUTPUT = b"ordinary action retry result\n"


def _write_pack(root: Path):
    control = root / "control"
    control.mkdir()
    mode = control / "mode"
    mode.write_text("fail", encoding="utf-8")
    calls = control / "calls.jsonl"
    pack = root / "ls6_general_retry"
    pack.mkdir()
    script = pack / "run.py"
    script.write_text(
        "import argparse, sys\nfrom pathlib import Path\n"
        "from datetime import datetime, timezone\n"
        "from astrid.pack_api import build_manifest, write_manifest\n"
        "parser=argparse.ArgumentParser()\nparser.add_argument('--out', type=Path, required=True)\n"
        "args=parser.parse_args()\n"
        f"mode=Path({str(mode)!r}).read_text(encoding='utf-8')\n"
        f"with Path({str(calls)!r}).open('a',encoding='utf-8') as stream: stream.write(mode+'\\n')\n"
        "print('ordinary retry stdout', flush=True)\n"
        "print('ordinary retry stderr', file=sys.stderr, flush=True)\n"
        "if mode == 'fail': raise SystemExit(23)\n"
        "args.out.mkdir(parents=True,exist_ok=True)\n"
        f"(args.out/'answer.txt').write_bytes({OUTPUT!r})\n"
        "write_manifest(args.out/'manifest.json', build_manifest(kind='ordinary-retry-probe', inputs={},"
        " outputs=[{'name':'answer','path':'answer.txt','ordinal':0,'role':'result','media_type':'text/plain'}],"
        " created=datetime.now(timezone.utc).isoformat()))\n",
        encoding="utf-8",
    )
    (pack / "pack.yaml").write_text(json.dumps({
        "schema_version": 3, "id": "ls6_general_retry", "name": "Ordinary log retry probe", "version": "1.0.0",
        "pack_api": "%d.%d" % PACK_API_VERSION, "status": "experimental", "domain": "integration",
        "stability": "experimental", "support": "community", "visibility": "visible",
        "description": "A CPU command without a generation or thumbnail effect.",
        "permissions": [{"id": "subprocess", "reason": "Runs the CPU fixture."},
                        {"id": "project_files", "reason": "Writes a declared text result."}],
        "actions": {"echo": {
            "name": "Ordinary action", "description": "Fail once, then emit a text file with stable job logs.",
            "version": "1.0", "cache": {"mode": "none"}, "inputs": [],
            "outputs": [{"name": "answer", "type": "file", "mode": "create_or_replace",
                         "path_template": "{out}/answer.txt", "artifact_type": "text/plain"}],
            "isolation": {"mode": "subprocess", "network": False},
            "metadata": {"adapter_family": "cpu", "output_result_manifest": True, "runtime_file": "run.py"},
            "invocation": {"kind": "command", "command": {"argv": [
                "{python_exec}", str(script), "--out", "{out}"]}},
            "resources": [{"kind": "implementation", "path": "run.py"}],
        }},
    }), encoding="utf-8")
    matrix = root / "capability-matrix.json"
    matrix.write_text(json.dumps({"schema_version": 1, "capabilities": [{
        "id": CAPABILITY, "disposition": "required", "evidence_reason": "Ordinary log retry diagnostic",
        "adapter_family": "cpu", "resource_keys": [], "required_env": [], "required_binaries": [],
        "required_packages": [], "estimated_scratch_bytes": 2 * 1024 * 1024,
        "estimated_output_bytes": 512 * 1024,
    }]}), encoding="utf-8")
    return pack, matrix, mode, calls


def _save_selected_evidence(root: Path, task_id, observations):
    """Export selected ownership rows after daemon shutdown; never credentials."""
    import runtime_protocol

    evidence = {
        "probe_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "module_origins": {"astrid": astrid.__file__, "generic_host": generic_host.__file__,
                           "astrid_runtime_client": astrid_runtime_client.__file__,
                           "runtime_protocol": runtime_protocol.__file__},
        "observations": observations, "task_id": task_id, "requests": [],
        "calls": (root / "control/calls.jsonl").read_text().splitlines()
                 if (root / "control/calls.jsonl").exists() else [],
    }
    for request_path in sorted(root.glob("attempts/*/*-request.json")):
        request = json.loads(request_path.read_text())
        body = request.get("body", {})
        evidence["requests"].append({
            "file": str(request_path), "file_sha256": hashlib.sha256(request_path.read_bytes()).hexdigest(),
            "operation": request.get("operation"), "attempt_id": request.get("identifier"),
            "fence": body.get("fence"), "runtime_epoch": body.get("runtime_epoch"),
            "effect": body.get("effect"),
            "outputs": [{key: output.get(key) for key in (
                "name", "kind", "role", "digest", "size", "filename", "media_type", "output_port",
                "group_key", "variant_key", "ordinal", "durability", "producer", "provenance")}
                for output in body.get("outputs", [])],
        })
    database = root / "realm/realm.sqlite3"
    if database.exists() and task_id is not None:
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True)
        connection.row_factory = sqlite3.Row
        try:
            evidence["task"] = dict(connection.execute(
                "SELECT id,capability,status,attempt,attempt_id,lease_fence,expected_effect_json FROM tasks WHERE id=?",
                (task_id,),
            ).fetchone())
            evidence["attempts"] = [dict(row) for row in connection.execute(
                "SELECT id,task_id,fence,executor_id,runtime_epoch,settled FROM attempts WHERE task_id=? ORDER BY fence",
                (task_id,),
            )]
            evidence["log_associations"] = [dict(row) for row in connection.execute(
                "SELECT association_id,task_id,attempt_id,project_id,output_port,group_key,generation_id,variant_key,"
                "object_digest,manifest_digest,size,filename,media_type,ordinal,role,producer_json,provenance_json,"
                "durability FROM managed_output_associations WHERE task_id=? AND role='log' ORDER BY variant_key",
                (task_id,),
            )]
            evidence["task_count"] = connection.execute("SELECT COUNT(*) FROM tasks").fetchone()[0]
            evidence["generation_count"] = connection.execute("SELECT COUNT(*) FROM generations").fetchone()[0]
        finally:
            connection.close()
    Path(os.environ["LS6_PROBE_EVIDENCE_PATH"]).write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")


def test_ordinary_action_durable_logs_survive_owner_retry(tmp_path, monkeypatch, real_runtime):
    monkeypatch.delenv("ASTRID_PACKS_PATH", raising=False)
    pack, matrix, mode, calls = _write_pack(tmp_path)
    daemon = real_runtime()
    host = GenericPackHost(
        pack_roots=[pack], capability_matrix=matrix,
        client=RuntimeProtocolClient(daemon.endpoint, daemon.worker_token),
        executor_id="astrid-pack-host", attempt_base=tmp_path / "attempts",
    )
    observations = {}
    task_id = None
    try:
        host.register()
        record = host.capabilities[CAPABILITY]
        assert record.ready, record.preflight
        api = WorkspaceClient(daemon.endpoint, daemon.token)
        project = api.create_project("Ordinary log retry", slug="ordinary-log-retry", idempotency_key="probe-project")
        task = api.admit_task(capability_id=CAPABILITY, capability_digest=record.capability_digest,
                              input_object_ids=[], project_id=project.project_id, idempotency_key="probe-task",
                              storage_estimate={"scratch_bytes": 2 * 1024 * 1024, "output_bytes": 512 * 1024})
        task_id = task.task_id
        assert api.get_task(task_id).expected_effect is None
        with pytest.raises(HostError, match="exited 23"):
            host.run(once=True)
        failed = api.get_task(task_id)
        assert failed.state == "failed" and failed.attempt_id and failed.lease_fence
        logs, cursor = api.list_managed_outputs(task_id)
        assert cursor is None
        assert {row.variant_key for row in logs if row.role == "log"} == {"job.stdout", "job.stderr"}
        assert all(row.durability == "durable" for row in logs if row.role == "log")
        observations["failed_attempt"] = {"attempt_id": failed.attempt_id, "fence": failed.lease_fence,
                                           "state": failed.state, "durable_job_logs_observed": True}
        mode.write_text("success", encoding="utf-8")
        retried = api.retry_task(task_id, expected_version=failed.version, idempotency_key="probe-owner-retry")
        assert retried.task_id == task_id
        observations["owner_retry_admitted"] = True
        # Strict success expectation: record and re-raise the actual product
        # rejection; no acceptance of a failed retry or guard bypass.
        try:
            result = host.run(once=True)
        except BaseException as exc:
            chain = []
            current = exc
            while current is not None:
                chain.append({"type": type(current).__name__, "message": str(current),
                              "code": getattr(current, "code", None), "details": getattr(current, "details", None)})
                current = current.__cause__
            observations["retry_exception_chain"] = chain
            raise
        assert [row.state for row in result] == ["succeeded"]
        completed = api.get_task(task_id)
        assert completed.state == "succeeded" and completed.attempt_id != failed.attempt_id
        assert completed.lease_fence > failed.lease_fence
        assert api.get_object("sha256:" + hashlib.sha256(OUTPUT).hexdigest()).data == OUTPUT
        assert calls.read_text().splitlines() == ["fail", "success"]
        generations, cursor = api.list_generations(project.project_id)
        assert generations == [] and cursor is None
        tasks, cursor = api.list_project_tasks(project.project_id)
        assert len(tasks) == 1 and cursor is None
        observations["retry_succeeded"] = True
    finally:
        try:
            host.shutdown()
        finally:
            daemon.stop()
            _save_selected_evidence(tmp_path, task_id, observations)
