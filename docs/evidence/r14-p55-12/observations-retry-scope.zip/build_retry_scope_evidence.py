"""Build additive R14-P55-12 retry evidence in scratch only."""
from __future__ import annotations

import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
CI_STEM = 'ci-p55-product-heads-20261118-213317'
RECOVERY_SHA = '25cbc33f4e0527279f6e1598df9b8d4873ecb4f43f98e53b907b33c69d9514ac'
BOUNDARY_SHA = '3633faaa2a0cecbb9fc32ca01253db1b6b6baa76ed6da797c4f1746af46f9f36'
SCOPE_SHA = '066f43bc656311d373f1090f18b18fc8988f1dc2cb34de264089978b43c86ba1'
GUARD_SHA = '6a155b6817f74ae7540f8975c2dcf00358e13a544fb0da3e8a22151d3af25f2f'
HARNESS_SHA = '4d6d67f4006d6351d5fce79ab488abae2c060c5f6bd6ce8d9ff403a73aede1e6'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(name):
    return json.loads((PROOF / name).read_text())


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=ROOT / repo, text=True).strip()


def cases(name):
    values = {}
    for case in ET.parse(PROOF / name).getroot().iter('testcase'):
        identity = case.get('classname') + '::' + case.get('name')
        assert identity not in values, (name, identity)
        values[identity] = ('failed' if case.find('failure') is not None else
                            'error' if case.find('error') is not None else
                            'skipped' if case.find('skipped') is not None else 'passed')
    return values


def require_counts(name, expected):
    values = cases(name)
    assert dict(Counter(values.values())) == expected, (name, Counter(values.values()))
    return values


def function_bytes(source, name):
    nodes = [node for node in ast.walk(ast.parse(source))
             if isinstance(node, ast.FunctionDef) and node.name == name]
    assert len(nodes) == 1
    node = nodes[0]
    return ''.join(source.splitlines(keepends=True)[node.lineno - 1:node.end_lineno]).encode()


def regular_top_level(path):
    return (path.parent == PROOF and not path.is_symlink()
            and stat.S_ISREG(path.stat(follow_symlinks=False).st_mode))


def main():
    archive = PROOF / 'observations-retry-scope.zip'
    index_path = PROOF / 'retry-scope.json'
    summary_path = PROOF / 'retry-scope-build-summary.json'
    assert not any(path.exists() for path in (archive, index_path, summary_path))

    publication = read_json('retry-scope-product-publication.json')
    product = publication['products']
    sources = {
        'astrid-agent': {
            'published': product['agent']['published_pin_commit'],
            'local': product['agent']['local_pin_commit'], 'tree': product['agent']['pin_tree'],
            'published_product_commit': product['agent']['published_product_commit'],
            'local_product_commit': product['agent']['local_product_commit'],
            'product_tree': product['agent']['product_tree'],
        },
        'astrid-runtime': {
            'published': product['runtime']['published_commit'],
            'local': product['runtime']['local_commit'], 'tree': product['runtime']['tree'],
        },
        'VibeComfy': {
            'published': product['vibe']['published_commit'],
            'local': product['vibe']['local_commit'], 'tree': product['vibe']['tree'],
            'product_unchanged_in_retry_resume': True,
        },
    }
    for repo, identity in sources.items():
        assert git(repo, 'rev-parse', 'HEAD') == identity['local']
        assert git(repo, 'rev-parse', 'HEAD^{tree}') == identity['tree']
        assert git(repo, 'status', '--porcelain') == ''

    protected = {
        'astrid-agent/tests/core/execution/test_ls6_thumbnail_recovery.py': RECOVERY_SHA,
        'astrid-runtime/tests/test_thumbnail_attach_log_boundary.py': BOUNDARY_SHA,
        'astrid-runtime/tests/test_thumbnail_attempt_log_scope.py': SCOPE_SHA,
        'astrid-agent/tests/ls6_output_counters.py': HARNESS_SHA,
    }
    for relative, expected in protected.items():
        assert digest((ROOT / relative).read_bytes()) == expected
    guard = function_bytes((ROOT / 'astrid-runtime/runtime_protocol/store.py').read_text(),
                           '_associate_managed_outputs')
    assert len(guard) == 8798 and digest(guard) == GUARD_SHA
    for name in ['retry-scoped-before-associate_managed_outputs.py',
                 'retry-scoped-after-associate_managed_outputs.py',
                 *[f'runtime-final-ready-1-{suite}-association-guard.py'
                   for suite in ('stream', 'thumbnail', 'canonical_logs')]]:
        assert (PROOF / name).read_bytes() == guard

    audit = read_json('ls6-final-scoped-log-ownership-audit.json')
    assert audit['result'] == 'clean' and not audit['new_issues']
    assert audit['existing_test_modification_count'] == 3
    assert all(row['exactly_one_authorized_substitution_only'] for row in audit['existing_test_modifications'])
    assert audit['immutable_managed_output_guard']['byte_identical_to_prescribed_base']
    assert audit['schema_guard']['byte_identical']
    assert audit['schema_guard']['equality_chain_retained']
    assert audit['schema_guard']['no_observed_job_assertion_retained']
    assert audit['vibe_frozen_product']['all_non_evidence_paths_byte_identical']
    assert not audit['generated_projections']['artifact_hash_mismatches']
    assert not audit['isolated_runtime_pin_proposal']['consumer_producer_declared_hash_mismatches']

    runtime_plan = read_json('runtime-final-regression-plan.json')
    runtime_summary = read_json('runtime-final-ready-1-summary.json')
    assert runtime_summary['regression_counts'] == {'passed': 144, 'failure': 0, 'error': 0, 'skipped': 0}
    suites = []
    identities = {'astrid-runtime': set(), 'astrid-agent': set()}
    reference_files = set()

    def add_suite(repo, label, name, count, reference):
        values = require_counts(name, {'passed': count})
        prior = cases(reference)
        assert values.keys() == prior.keys(), (name, reference)
        assert not identities[repo].intersection(values), (repo, label)
        identities[repo].update(values)
        reference_files.add(reference)
        suites.append({'repo': repo, 'selection': label, 'junit': name, 'passed': count,
                       'failed': 0, 'errors': 0, 'skipped': 0, 'exact_id_reference': reference,
                       'exact_ids_unchanged': True,
                       'ordered_ids_sha256': digest(json.dumps(list(values)).encode())})

    for label, count in [('stream', 31), ('thumbnail', 93), ('canonical_logs', 20)]:
        reference = Path(runtime_plan['suites'][label]['prior_junit']).name
        add_suite('astrid-runtime', label, f'runtime-final-ready-1-{label}.xml', count, reference)
        record = runtime_summary['suites'][label]
        assert all(record[key] for key in ('same_exact_node_ids', 'sources_unchanged',
                                          'identity_unchanged', 'guard_unchanged'))
    add_suite('astrid-runtime', 'attempt_scoped_thumbnail_logs',
              'runtime-thumbnail-attempt-scope-head-1.xml', 7,
              'runtime-thumbnail-attempt-scope-before-3.xml')
    add_suite('astrid-agent', 'protected_thumbnail_recovery', 'retry-scoped-after.xml', 2,
              'retry-scoped-before.xml')
    add_suite('astrid-agent', 'caller_and_receipt_pipeline', 'retry-scoped-final-caller.xml', 35,
              'agent-caller-frozen.xml')
    assert {repo: len(rows) for repo, rows in identities.items()} == {'astrid-runtime': 151, 'astrid-agent': 37}
    assert sum(len(rows) for rows in identities.values()) == 188
    require_counts('retry-scoped-before.xml', {'passed': 1, 'failed': 1})
    require_counts('runtime-thumbnail-attempt-scope-before-1.xml', {'error': 7})
    require_counts('runtime-thumbnail-attempt-scope-before-2.xml', {'passed': 4, 'failed': 3})
    require_counts('runtime-thumbnail-attempt-scope-before-3.xml', {'passed': 5, 'failed': 2})

    comparison = read_json('retry-scoped-final-comparison.json')
    caller = read_json('retry-scoped-final-caller.json')
    counter_run = read_json('retry-scoped-final-counter-run.json')
    assert caller['exit_code'] == counter_run['exit_code'] == 0
    assert caller['code_unchanged_during_run'] and counter_run['code_unchanged_during_run']
    assert comparison['final_caller']['comparison']['ordered_ids_identical']
    counter_names = ['ls6-full-path-base-1.json', 'ls6-full-path-head-1.json',
                     'retry-scoped-final-counter.json']
    counters = [read_json(name) for name in counter_names]
    assert all(value['status'] == 'completed' and value['code_unchanged']
               and value['harness']['sha256'] == HARNESS_SHA for value in counters)
    measurements = []
    for size in (37, 9 * 1024 * 1024 + 13):
        rows = [next(row for row in value['measurements'] if row['bytes'] == size) for value in counters]
        assert len({row['sha256'] for row in rows}) == 1
        for row in rows:
            assert row['fetch_count'] == 1 and row['runtime_primary_open_count'] == 1
            assert row['independent_caller_file'] and row['cas_unchanged_after_caller_mutation']
            assert row['settlement_state'] == 'succeeded' and row['task_status'] == 'completed'
            for phase in ('producer', 'runtime_pre_delivery', 'runtime_transmit', 'caller'):
                assert not row[phase]['coverage_gaps']
                assert row[phase]['bytes_hashed'] == size * row[phase]['completed_streams']
        assert rows[0]['producer']['completed_streams'] == 7
        assert rows[0]['caller']['completed_streams'] == 5
        assert rows[2]['producer']['completed_streams'] == rows[2]['caller']['completed_streams'] == 1
        for phase in ('producer', 'runtime_pre_delivery', 'runtime_transmit', 'caller'):
            assert rows[1][phase] == rows[2][phase]
        measurements.append({'bytes': size, 'sha256': rows[0]['sha256'], 'fetch_count_each': 1,
                             'phases': {phase: {'prescribed_base': rows[0][phase],
                                               'final_pinned': rows[2][phase]}
                                        for phase in ('producer', 'runtime_pre_delivery', 'runtime_transmit', 'caller')},
                             'matches_prior_candidate': True, 'independent_caller_file': True,
                             'cas_unchanged_after_caller_mutation': True})

    probe_files = ['test_general_log_retry_probe.py', 'run_general_log_retry_probe.py']
    probe_sources = read_json('general-log-retry-base.json')['sources_before']
    for name in probe_files:
        assert digest((PROOF / name).read_bytes()) == probe_sources[str(PROOF / name)]
    general_observations = []
    for label in ('base', 'current', 'final-current-1'):
        stem = f'general-log-retry-{label}'
        require_counts(stem + '.xml', {'failed': 1})
        record = read_json(stem + '.json')
        assert record['exit_code'] == 1
        assert 'managed output association conflicts with existing immutable output' in (PROOF / (stem + '.log')).read_text()
        general_observations.append({'selection': label, 'junit': stem + '.xml', 'failed': 1,
                                     'skipped': 0, 'result': 'known HTTP 409 immutable association conflict'})

    pin = read_json('runtime-retry-pin-proposal.json')
    assert pin['generated_consumer_bytes_unchanged'] and len(pin['verified_artifacts']) == 16
    runtime_lock = json.loads((ROOT / 'astrid-agent/runtime.lock.json').read_text())
    assert runtime_lock['source_commit'] == product['runtime']['published_commit']
    ci = read_json(CI_STEM + '.json')
    assert ci['scope']['no_green_ci_claim'] and ci['scope']['no_final_head_ci_claim']
    expected_ci_heads = {'banodoco/' + repo: data['published'] for repo, data in sources.items()}
    for source in ci['sources']:
        assert source['sha'] == expected_ci_heads[source['repo']]

    previous_dir = ROOT / 'astrid-agent/docs/evidence/r14-p55-12'
    previous_index = json.loads((previous_dir / 'approved-resume.json').read_text())
    historical = {path: digest(path.read_bytes()) for repo in sources
                  for path in (ROOT / repo / 'docs/evidence/r14-p55-12').iterdir()
                  if path.is_file()}
    patterns = [
        'general-log-retry-*', 'retry-scoped-*', 'runtime-thumbnail-attempt-scope-*',
        'runtime-final-ready-1-*', 'runtime-final-regression-*', 'recovery-approved-*',
        'schema-approved-*', 'ci-p55-product-heads-20261118-213317*',
    ]
    files = {path for pattern in patterns for path in PROOF.glob(pattern)
             if path.is_file() and regular_top_level(path)}
    explicit = {
        'build_retry_scope_evidence.py', 'run_general_log_retry_probe.py', 'test_general_log_retry_probe.py',
        'run_runtime_final_regressions.py', 'association-guard-hash-extraction-reconciliation.json',
        'ls6-final-scoped-log-ownership-audit.json', 'schema-adapter-approved-audit.json',
        'runtime-retry-pin-proposal.json', 'retry-scope-product-publication.json',
        'retry-scope-disk-restoration.json', 'ls6-full-path-base-1.json', 'ls6-full-path-base-1.log',
        'ls6-full-path-head-1.json', 'ls6-full-path-head-1.log', 'agent-caller-frozen.xml',
        'agent-caller-frozen.log', 'runtime-coherent-review.json',
        'runtime-thumbnail-final-preservation-1.json', 'runtime-thumbnail-final-preservation-1.log',
        'runtime-thumbnail-final-preservation-1.xml', 'runtime-thumbnail-log-final-comparison-1.json',
        'runtime-thumbnail-log-final-head-1.log', 'runtime-thumbnail-log-final-head-1.xml',
        'runtime-ts-projection-regeneration.json', 'runtime-ts-projection-generate.log',
        'ci-p55-20261118-snapshot.json', 'ci-p55-20261118-source-checks.json',
    } | reference_files
    for name in explicit:
        path = PROOF / name
        assert path.exists() and regular_top_level(path), name
        files.add(path)
    assert len([path for path in files if path.name.startswith(CI_STEM) and path.name.endswith('.selected.log')]) == 4
    assert all(path.suffix not in {'.db', '.sqlite', '.sqlite3', '.token', '.zip'} for path in files)
    snapshots = {path.name: path.read_bytes() for path in sorted(files)}
    assert len(snapshots) == len(files)

    index = {
        'schema_version': 1, 'packet': 'R14-P55-12', 'row': 'LS-6 remainder', 'session': 'r14-P55-12-1',
        'status': 'READY FOR LEAD REVIEW: scoped thumbnail retry completes; 188 selected packet test IDs pass; isolated pins remain proposals pending Lead acceptance.',
        'authority': publication['authority'],
        'progress_report': 'https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6992400203',
        'supersedes': {
            'index': 'approved-resume.json', 'sha256': digest((previous_dir / 'approved-resume.json').read_bytes()),
            'previous_status': previous_index['status'],
            'previous_archive': previous_index['archive']['path'],
            'previous_archive_sha256': previous_index['archive']['sha256'],
            'resolution': 'The unchanged protected retry test now passes with a fresh attempt-scoped log selector; prior BLOCKED observations remain preserved and are superseded for this packet status.',
        },
        'source_commits_before_evidence': sources,
        'source_publication_mapping': 'retry-scope-product-publication.json',
        'product_change': {
            'agent': 'Only generation.thumbnail_backfill log descriptors receive thumbnail-attempt:<trusted attempt_id> in the shared success/failure log upload helper; canonical names, ports, variants and custody remain unchanged.',
            'runtime': 'Private validators receive the existing fenced attempt_id at both settlement validation sites; canonical logs accept legacy default or the exact current-attempt group. All other thumbnail checks and the immutable association guard remain unchanged.',
            'vibe': 'Product source is unchanged from the earlier frozen proof; this retry resume adds no Vibe product change.',
        },
        'final_packet_verification': {
            'passed': 188, 'failed': 0, 'errors': 0, 'skipped': 0,
            'runtime_unique_ids': 151, 'agent_unique_ids': 37, 'suites': suites,
            'count_scope': 'Selected packet tests only. Counters, historical failures and the separate known generic retry probe are reported separately and are not counted as passing tests.',
        },
        'protected_recovery': {
            'before': cases('retry-scoped-before.xml'), 'after': cases('retry-scoped-after.xml'),
            'test_file_sha256': RECOVERY_SHA, 'immutable_guard_sha256': GUARD_SHA,
            'immutable_guard_bytes': 8798, 'immutable_guard_matches_prescribed_base': True,
            'completed_assertions': comparison['recovery']['passed_assertions'],
            'nonfatal_stderr_observation': comparison['recovery']['after']['nonfatal_stderr_observation'],
            'comparison': 'retry-scoped-final-comparison.json',
        },
        'scope_boundary_proof': {
            'test_file_sha256': SCOPE_SHA, 'protected_existing_boundary_file_sha256': BOUNDARY_SHA,
            'before_3': {'passed': 5, 'failed': 2}, 'head': {'passed': 7, 'failed': 0},
            'comparison': 'runtime-thumbnail-attempt-scope-comparison-1.json',
            'preserved_authoring_history': [
                'Before-1: seven unchanged-fixture setup errors at the real free-space reserve; no reserve override or test change.',
                'Before-2: four pass and three fail; two retry helpers stopped at the newly authored incorrect HTTP403 expectation.',
                'Parent authorized new-helper correction to exact HTTP401 plus unauthorized code, scope-denial message and tasks:write detail, matching the existing auth contract. Both source versions are archived.',
                'Corrected before-3 and head use identical source. Both current-scope positives fail before and pass after; all five refusals pass in both runs.',
            ],
            'retry_preservation': 'Actual owner retry retains task identity, changes attempt and increases fence; old log association rows remain exactly unchanged; current custody and idempotent replay are asserted.',
        },
        'full_path_counters': {
            'harness_sha256': HARNESS_SHA, 'harness_path': 'tests/ls6_output_counters.py',
            'measurements': measurements, 'same_harness_before_and_after': True,
            'source_identity_stable': True, 'comparison': 'retry-scoped-final-comparison.json',
            'instrumentation': counters[-1]['instrumentation'],
        },
        'known_separate_failure': {
            'issue': 'https://github.com/banodoco/astrid-dev/issues/926',
            'lead_filing': 'https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6992136770',
            'initial_report': publication['general_issue_filing'],
            'status': 'Still failed on prescribed base, pre-fix candidate and final candidate; outside this thumbnail-scoped fix.',
            'observations': general_observations,
            'probe_sha256': digest((PROOF / probe_files[0]).read_bytes()),
            'launcher_sha256': digest((PROOF / probe_files[1]).read_bytes()),
            'probe_and_launcher_unchanged': True,
            'error': 'HTTP409: managed output association conflicts with existing immutable output; attempt_id/provenance_json differ on ordinary-action retry.',
            'guard_action': 'The general immutable guard, ordinary-action output policy and failed probe expectation remain unchanged.',
        },
        'authorized_schema_commit': previous_index['authorized_schema_commit'],
        'pins': {
            'runtime': {'source_commit': pin['source_commit'], 'published_proposal_commit': product['agent']['published_pin_commit'],
                        'status': 'isolated proposal pending Lead acceptance', 'evidence': 'runtime-retry-pin-proposal.json',
                        'verified_consumer_artifacts': 16, 'generated_consumer_bytes_unchanged': True},
            'vibe_proposal_unchanged': {
                'authority_repository': 'banodoco/astrid-agent',
                'authority_commit': '2fdf06a903b0fecaf9f70f1453e993119dccfd5e',
                'authority_path': 'astrid/packs/vibecomfy/pins.json',
                'json_pointer': '/sources/vibecomfy/revision',
                'status': 'existing proposal; acceptance remains Lead-owned',
            },
        },
        'scope_audit': {
            'artifact': 'ls6-final-scoped-log-ownership-audit.json',
            'existing_test_changes': ['strict producer hash count 3 to 1', 'approved strict census 51 to 52', 'approved schema digest literal'],
            'all_other_existing_assertions_retained': True, 'schema_equality_and_no_observed_job_guard_retained': True,
            'no_tests_deleted_skipped_xfailed_or_deselected': True,
            'no_tasks_workflow_or_outside_packet_changes': True,
            'runtime_artifact_hashes_verified': 86, 'vibe_product_unchanged': True,
        },
        'hosted_ci_snapshot': {
            'artifact': CI_STEM + '.json', 'observed_start_utc': ci['observed_start_utc'],
            'observed_end_utc': ci['observed_end_utc'],
            'sources': [{'repository': row['repo'], 'published_source_commit': row['sha'],
                         'returned_workflows': row['returned_run_count'], 'status_counts': row['status_counts']}
                        for row in ci['sources']],
            'failed_vibe_jobs': 4,
            'observation': 'Vibe failures recur at dependency installation (runpod-lifecycle unavailable) and root-clean allowlist; compared Makefile/pyproject/uv.lock input blobs equal the prescribed base and earlier snapshot.',
            'limits': ci['scope']['limits'], 'no_green_ci_claim': True,
            'not_later_evidence_head_ci': True, 'regression_attribution': 'unclassified; no paired hosted baseline',
        },
        'limits': [
            'Ready for Lead review and ordinary PR handling; pins are proposals pending Lead acceptance, and no merge or release qualification is asserted.',
            'Schema commit f108349eccafb3e7588d9fa5dbe94d2d6b990015 remains explicitly named; release/14/main landing is Lead-ordered with Plan59 #838.',
            'Protected recovery uses CPU fixture generation and a substituted external decoder with real authenticated Runtime HTTP, installed action, native custody, SDK following and settlement; no GPU or real-decoder timing claim.',
            'Completed Python SHA streams and bytes are counted independently by phase; no native/subprocess hashing, live-model inference or latency claim.',
            'General ordinary-action retry remains a visible failing probe under #926; it is not skipped or included in the 188 passing packet IDs.',
            'Queued and skipped hosted workflows are NO-RESULT. The source-bound snapshot does not establish green CI or exhaust all workflow pages/events.',
            'Only top-level regular evidence files are archived; no basetemp directories, full realm databases or credential files are included.',
        ],
    }
    assert index['authorized_schema_commit']['published'] == 'f108349eccafb3e7588d9fa5dbe94d2d6b990015'
    current_vibe_pin = json.loads((ROOT / 'astrid-agent/astrid/packs/vibecomfy/pins.json').read_text())['sources']['vibecomfy']['revision']

    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
        for name, data in snapshots.items():
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
            info.create_system = 3
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            bundle.writestr(info, data, compresslevel=9)
    with zipfile.ZipFile(archive) as bundle:
        assert bundle.testzip() is None
        assert bundle.namelist() == list(snapshots)
        for member in bundle.infolist():
            data = snapshots[member.filename]
            assert member.file_size == len(data)
            assert digest(bundle.read(member.filename)) == digest(data)
    index['archive'] = {
        'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()),
        'every_member_hash_verified': True,
        'files': [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in snapshots.items()],
    }
    raw = (json.dumps(index, indent=2, sort_keys=True) + '\n').encode()
    assert current_vibe_pin.encode() not in raw, 'Index must reference Vibe pin authority without copying its current literal'
    with index_path.open('xb') as handle:
        handle.write(raw)
    assert json.loads(index_path.read_text())['final_packet_verification']['passed'] == 188
    for name, data in snapshots.items():
        assert (PROOF / name).read_bytes() == data, ('input changed during build', name)
    for path, expected in historical.items():
        assert digest(path.read_bytes()) == expected, ('historical evidence changed', path)
    for repo, identity in sources.items():
        assert git(repo, 'rev-parse', 'HEAD') == identity['local']
        assert git(repo, 'status', '--porcelain') == ''
    summary = {'archive': archive.name, 'archive_bytes': archive.stat().st_size,
               'archive_sha256': index['archive']['sha256'], 'members': len(snapshots),
               'index': index_path.name, 'index_bytes': len(raw), 'index_sha256': digest(raw),
               'builder_sha256': digest(Path(__file__).read_bytes()),
               'packet_passed': 188, 'runtime_passed': 151, 'agent_passed': 37,
               'every_member_verified': True, 'current_vibe_pin_literal_absent_from_index': True,
               'historical_evidence_unchanged': True, 'repository_sources_unchanged_and_clean': True,
               'known_general_409_preserved': True, 'outputs_only_in_proof': True}
    with summary_path.open('x') as handle:
        json.dump(summary, handle, indent=2, sort_keys=True)
        handle.write('\n')
    print(json.dumps(summary, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
