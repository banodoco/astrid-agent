"""Run one frozen prior Runtime selection after the root product-ready signal.

This launcher never edits repository files, deletes prior proof, changes
thresholds, or suppresses a selected test. Invocation requires the exact
Runtime commit/tree and store.py bytes supplied when the product is ready.
"""
from __future__ import annotations

import argparse
import ast
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET


BASE = Path("/workspace/scratch/8c30ce2383b9")
PROOF = BASE / "proof"
PLAN = PROOF / "runtime-final-regression-plan.json"
PLAN_SHA256 = "557cadf8be988b84e71c330a9c89529f78644ece9ff7a5edc54c57c8d15ce518"


def sha(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def write_new(path, value):
    with path.open("x", encoding="utf-8") as stream:
        stream.write(json.dumps(value, indent=2) + "\n")


def git_identity(repo):
    diff = subprocess.check_output(["git", "diff", "--binary", "HEAD"], cwd=repo)
    return {
        "revision": subprocess.check_output(["git", "rev-parse", "HEAD", "HEAD^{tree}"], cwd=repo, text=True).splitlines(),
        "status": subprocess.check_output(["git", "status", "--porcelain=v1"], cwd=repo, text=True).splitlines(),
        "tracked_diff_sha256": hashlib.sha256(diff).hexdigest(),
    }, diff


def capture_guard(repo):
    source = (repo / "runtime_protocol/store.py").read_text(encoding="utf-8")
    node = next(node for node in ast.walk(ast.parse(source))
                if isinstance(node, ast.FunctionDef) and node.name == "_associate_managed_outputs")
    full = "".join(source.splitlines(keepends=True)[node.lineno - 1:node.end_lineno]).encode()
    segment = ast.get_source_segment(source, node).encode()
    return {"file": "runtime_protocol/store.py", "function": "RealmStore._associate_managed_outputs",
            "first_line": node.lineno, "last_line": node.end_lineno, "bytes": len(full),
            "sha256": hashlib.sha256(full).hexdigest(),
            "ast_segment_sha256": hashlib.sha256(segment).hexdigest()}, full


def source_paths(repo, selected):
    tracked = subprocess.check_output(["git", "ls-files", "-z"], cwd=repo).decode().split("\0")
    prefixes = ("runtime_protocol/", "packages/python/", "generators/", "protocol/", "schema/", "schemas/")
    files = {name for name in tracked if name and (name.startswith(prefixes)
             or name in selected or name in {"pyproject.toml", "tests/conftest.py"}
             or name.startswith("tests/helpers/"))}
    files.update(selected)
    return [repo / name for name in sorted(files)]


def junit(path):
    if not path.is_file():
        return {}, "JUnit file was not produced"
    values = {}
    for case in ET.parse(path).getroot().iter("testcase"):
        nodeid = case.attrib.get("classname", "").replace(".", "/") + ".py::" + case.attrib["name"]
        outcome, message = "passed", ""
        for tag in ("failure", "error", "skipped"):
            detail = case.find(tag)
            if detail is not None:
                outcome, message = tag, detail.get("message", "")
                break
        if nodeid in values:
            return values, "Duplicate JUnit node ID: " + nodeid
        values[nodeid] = {"outcome": outcome, "message": message}
    return values, None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("suite", choices=("stream", "thumbnail", "canonical_logs"))
    parser.add_argument("--run-label", required=True)
    parser.add_argument("--expected-commit", required=True)
    parser.add_argument("--expected-tree", required=True)
    parser.add_argument("--expected-store-sha256", required=True)
    args = parser.parse_args()
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]*", args.run_label):
        parser.error("run-label must use lowercase letters, digits and hyphens")
    if sha(PLAN) != PLAN_SHA256:
        raise RuntimeError("Frozen selector plan changed")
    plan = json.loads(PLAN.read_text())
    selection = plan["suites"][args.suite]
    repo = Path(plan["repo"])
    stem = PROOF / (args.run_label + "-" + args.suite)
    collisions = list(PROOF.glob(stem.name + "*"))
    if collisions:
        raise RuntimeError("Refusing to overwrite existing proof: " + str(collisions))
    command = [plan["python"], "-m", "pytest", "-q", "-rA", *selection["nodeids"],
               "--basetemp=" + str(stem) + "-tmp", "--junitxml=" + str(stem) + ".xml"]
    environment = os.environ.copy()
    environment.update(selection["environment"])
    paths = source_paths(repo, selection["protected_test_files"])
    paths += [PLAN, Path(__file__), Path(plan["protected_recovery_test"]["path"])]
    snapshot = lambda: {str(path): sha(path) for path in paths}
    identity, diff = git_identity(repo)
    guard, guard_bytes = capture_guard(repo)
    metadata = {
        "suite": args.suite, "started_utc": stamp(), "command": command, "cwd": str(repo),
        "environment": selection["environment"], "plan": str(PLAN), "plan_sha256": PLAN_SHA256,
        "expected_identity": {"commit": args.expected_commit, "tree": args.expected_tree,
                              "store_sha256": args.expected_store_sha256},
        "prior_junit": selection["prior_junit"], "prior_junit_sha256": selection["prior_junit_sha256"],
        "expected_count": selection["expected_count"], "identity_before": identity,
        "sources_before": snapshot(), "immutable_association_guard_before": guard,
        "free_bytes_before": shutil.disk_usage(PROOF).free,
    }
    write_new(Path(str(stem) + ".before.json"), metadata)
    checks = {
        "expected_commit": identity["revision"][0] == args.expected_commit,
        "expected_tree": identity["revision"][1] == args.expected_tree,
        "expected_store_bytes": sha(repo / "runtime_protocol/store.py") == args.expected_store_sha256,
        "prior_junit_unchanged": sha(Path(selection["prior_junit"])) == selection["prior_junit_sha256"],
        "protected_tests_unchanged": all(sha(repo / name) == value["sha256"]
                                         for name, value in selection["protected_test_files"].items()),
        "protected_recovery_unchanged": sha(Path(plan["protected_recovery_test"]["path"]))
                                         == plan["protected_recovery_test"]["sha256"],
        "immutable_association_guard_unchanged": guard["sha256"] == plan["immutable_association_guard_full_lines_sha256"],
    }
    metadata["preflight_identity_checks"] = checks
    if not all(checks.values()):
        metadata.update(executed=False, status="NO-RESULT", finished_utc=stamp())
        write_new(Path(str(stem) + ".json"), metadata)
        print(json.dumps({"suite": args.suite, "status": "NO-RESULT", "checks": checks}), flush=True)
        return 2
    Path(str(stem) + "-association-guard.py").write_bytes(guard_bytes)
    if diff:
        Path(str(stem) + "-runtime-worktree.patch").write_bytes(diff)
    print(json.dumps({"suite": args.suite, "selected_ids": len(selection["nodeids"]),
                      "identity": identity, "free_bytes": metadata["free_bytes_before"],
                      "log": str(stem) + ".log"}), flush=True)
    with Path(str(stem) + ".log").open("x", encoding="utf-8") as stream:
        result = subprocess.run(command, cwd=repo, env=environment, stdout=stream, stderr=subprocess.STDOUT)
    current_identity, _ = git_identity(repo)
    current_guard, _ = capture_guard(repo)
    outcomes, parse_error = junit(Path(str(stem) + ".xml"))
    expected = set(selection["nodeids"])
    observed = set(outcomes)
    metadata.update(executed=True, exit_code=result.returncode, finished_utc=stamp(),
                    identity_after=current_identity, sources_after=snapshot(),
                    immutable_association_guard_after=current_guard,
                    free_bytes_after=shutil.disk_usage(PROOF).free, node_statuses=outcomes,
                    junit_error=parse_error, missing_ids=sorted(expected - observed),
                    unexpected_ids=sorted(observed - expected))
    metadata["sources_unchanged"] = metadata["sources_before"] == metadata["sources_after"]
    metadata["identity_unchanged"] = identity == current_identity
    metadata["guard_unchanged"] = guard["sha256"] == current_guard["sha256"]
    metadata["same_exact_node_ids"] = expected == observed
    metadata["counts"] = {state: sum(row["outcome"] == state for row in outcomes.values())
                          for state in ("passed", "failure", "error", "skipped")}
    metadata["status_changes"] = {nodeid: {"before": selection["prior_statuses"][nodeid], **row}
                                  for nodeid, row in outcomes.items()
                                  if nodeid in expected and row["outcome"] != selection["prior_statuses"][nodeid]}
    metadata["artifacts"] = {str(path): {"sha256": sha(path), "bytes": path.stat().st_size}
                             for path in (Path(str(stem) + ".log"), Path(str(stem) + ".xml")) if path.is_file()}
    valid = (result.returncode == 0 and parse_error is None and metadata["same_exact_node_ids"]
             and metadata["sources_unchanged"] and metadata["identity_unchanged"] and metadata["guard_unchanged"]
             and metadata["counts"]["passed"] == selection["expected_count"])
    metadata["verified_pass"] = valid
    write_new(Path(str(stem) + ".json"), metadata)
    print(json.dumps({key: metadata[key] for key in (
        "suite", "exit_code", "counts", "same_exact_node_ids", "sources_unchanged",
        "identity_unchanged", "guard_unchanged", "verified_pass", "status_changes")}), flush=True)
    print("\n".join(Path(str(stem) + ".log").read_text().splitlines()[-12:]), flush=True)
    return 0 if valid else result.returncode or 3


if __name__ == "__main__":
    raise SystemExit(main())
