"""Run the immutable, paired seventeen-case Vibe item-3 proof."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
SIDE = sys.argv[1]
assert SIDE in {'before', 'head'}
REPO = ROOT / ('vibe-rework-before' if SIDE == 'before' else 'VibeComfy')
EXPECTED = ('6a40663382dbefeaf482313a42765a123786c65c' if SIDE == 'before'
            else '3150d77a39c7ee2e5a85e2f6fabcded63af2d081')
STEM = PROOF / ('rework-vibe-final-' + SIDE)
PATHS = [
    'tests/test_descriptorless_output_receipts.py',
    'tests/test_output_receipts.py',
    'tests/test_runtime_run.py',
    'vibecomfy/runtime/output_receipts.py',
    'vibecomfy/runtime/session.py',
    'vibecomfy/runtime/run.py',
    'tests/conftest.py',
    'pyproject.toml',
]
SELECTORS = [
    'tests/test_descriptorless_output_receipts.py',
    'tests/test_output_receipts.py',
    'tests/test_runtime_run.py::test_managed_generation_result_is_deterministic_and_preserves_video_output',
    'tests/test_runtime_run.py::test_managed_generation_result_keeps_producer_evidence_namespaced_and_identity_stable',
    'tests/test_runtime_run.py::test_managed_generation_result_refuses_unavailable_and_failed_verification_evidence',
    'tests/test_runtime_run.py::test_external_server_shared_output_is_custodied_for_managed_result',
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    return {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=REPO, text=True).strip(),
        'status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True),
        'sha256': {path: sha(REPO / path) for path in PATHS},
    }


before = snapshot()
assert before['head'] == EXPECTED
assert before['sha256'][PATHS[0]] == '30d644c678b0f633ceac4b500423969dff8e2227ad6690ebca9a828a26e22b99'
assert before['status'] == ('?? tests/test_descriptorless_output_receipts.py\n' if SIDE == 'before' else '')
command = [
    str(ROOT / 'test-env/bin/python'), '-m', 'pytest', '-q', '-rA', *SELECTORS,
    '--basetemp=' + str(PROOF / ('rework-vibe-final-' + SIDE + '-tmp')),
    '--junitxml=' + str(STEM.with_suffix('.xml')),
]
env = os.environ.copy()
env['PYTHONPATH'] = str(REPO)
started = time.time()
with STEM.with_suffix('.log').open('wb') as log:
    result = subprocess.run(command, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT)
after = snapshot()
cases = []
if STEM.with_suffix('.xml').exists():
    for case in ET.parse(STEM.with_suffix('.xml')).getroot().iter('testcase'):
        problem = next((child for child in case if child.tag in {'failure', 'error', 'skipped'}), None)
        cases.append({
            'nodeid': case.attrib.get('classname', '').replace('.', '/') + '.py::' + case.attrib.get('name', ''),
            'status': problem.tag if problem is not None else 'passed',
            'message': problem.attrib.get('message') if problem is not None else None,
        })
report = {
    'side': SIDE, 'review_item': 3, 'command': command, 'cwd': str(REPO),
    'environment_overrides': {'PYTHONPATH': str(REPO)}, 'python': platform.python_version(),
    'started_unix': started, 'elapsed_seconds': time.time() - started,
    'exit_code': result.returncode, 'before': before, 'after': after,
    'source_stable': before == after, 'cases': cases,
    'counts': {status: sum(case['status'] == status for case in cases)
               for status in ('passed', 'failure', 'error', 'skipped')},
    'artifacts': {path.name: sha(path) for path in (STEM.with_suffix('.log'), STEM.with_suffix('.xml')) if path.exists()},
    'environment_freeze_sha256': sha(PROOF / 'rework-vibe-final-environment.txt'),
    'launcher_sha256': sha(Path(__file__)),
    'test_overlay': {'path': PATHS[0], 'source_commit': '3150d77a39c7ee2e5a85e2f6fabcded63af2d081',
                     'sha256': before['sha256'][PATHS[0]]} if SIDE == 'before' else None,
}
STEM.with_suffix('.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'side': SIDE, 'exit_code': result.returncode, 'counts': report['counts'],
                  'source_stable': report['source_stable'], 'report': str(STEM.with_suffix('.json'))}, indent=2))
print(STEM.with_suffix('.log').read_text()[-6000:])
