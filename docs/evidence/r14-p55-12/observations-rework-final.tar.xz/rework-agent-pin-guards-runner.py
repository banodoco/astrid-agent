from __future__ import annotations

import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
PYTHON = ROOT / 'test-env/bin/python'
label = sys.argv[1]
configurations = {
    'before': {
        'agent': ('agent-focused41-before', '8243ef8f97ee2022fba0d95d54deb8a89aa2e5a9'),
        'runtime': ('runtime-retry-pinned', '4323ef03f75334bc38c13d8fcb43b46368774d72'),
        'vibe': ('vibe-pinned', '08b770d9493a1d1c567b2c4d2166c2b1d794784b'),
    },
    'after': {
        'agent': ('agent-pin-guard-after', '68c7911e581e85bc70c357806260e88300247ed0'),
        'runtime': ('astrid-runtime', '62333bd797e84b21cb3995e4bcf580ed0bdcf9f0'),
        'vibe': ('VibeComfy', '3150d77a39c7ee2e5a85e2f6fabcded63af2d081'),
    },
}
configuration = configurations[label]
repos = {name: ROOT / value[0] for name, value in configuration.items()}
prefix = PROOF / ('rework-agent-pin-guards-' + label)
if prefix.with_suffix('.json').exists() or prefix.with_suffix('.log').exists():
    raise SystemExit('Refusing to overwrite a guard observation')
expected_tests = {
    'tests/test_vendor_lock.py': 'e9e48aa545e00662f52a97cde5d688a09a960d33f5be43dfdfbbc09af86f59f0',
    'tests/test_windows_path_budget.py': 'f6e50a48529b1760f738c3bad5f243e70c393c5206c7e3673a77bba8a5f01ca7',
}
expected_failures = {
    'tests.test_vendor_lock::test_one_root_lock_covers_all_known_runtime_paths': '1e6d899efa77a2d6ec247c38250f9748330bb587',
    'tests.test_windows_path_budget::test_installed_runtime_pinned_source_witness_fits_fresh_version_staging': '6855dfa8df65cf8ae4c002b57134d6505493c17c',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def snapshot():
    result = {}
    for name, repo in repos.items():
        paths = git(repo, 'ls-files', '-z').decode().strip('\0').split('\0')
        hashes = {}
        for path in paths:
            if not path or path.startswith('docs/evidence/'):
                continue
            file = repo / path
            hashes[path] = sha(file.read_bytes()) if file.is_file() else None
        result[name] = {
            'root': str(repo),
            'head': git(repo, 'rev-parse', 'HEAD').decode().strip(),
            'tree': git(repo, 'rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': git(repo, 'status', '--short').decode(),
            'tracked_diff_sha256': sha(git(repo, 'diff', '--binary', 'HEAD')),
            'source_sha256': hashes,
            'source_exclusion': 'docs/evidence/** historical evidence only',
        }
    return result


before = snapshot()
for name, state in before.items():
    if state['head'] != configuration[name][1] or state['status']:
        raise SystemExit('Unexpected or unclean selected checkout: ' + name)
for name, expected in expected_tests.items():
    if before['agent']['source_sha256'][name] != expected:
        raise SystemExit('Selected test changed: ' + name)
free_before = shutil.disk_usage(ROOT).free
if free_before < 1024 ** 3:
    raise SystemExit('One GiB reserve unavailable')
agent = repos['agent']
lock = json.loads((agent / 'runtime.lock.json').read_text())
if lock['source_commit'] != configuration['runtime'][1]:
    raise SystemExit('Agent declared Runtime pin does not match checkout')
environment = {
    'PYTHONPATH': ':'.join(str(repos[k]) for k in ['agent', 'runtime', 'vibe']),
    'ASTRID_RUNTIME_CHECKOUT': str(repos['runtime']),
    'ASTRID_VIBECOMFY_CHECKOUT': str(repos['vibe']),
    'PYTHONDONTWRITEBYTECODE': '1',
}
env = os.environ.copy()
env.update(environment)
imports_code = '''import json
import astrid_runtime_client.generated as sdk
import runtime_protocol
import vibecomfy
from astrid.core.generation.vibecomfy_dependency import VIBECOMFY_ENGINE_REVISION
print(json.dumps({'sdk': sdk.__file__, 'runtime_protocol': runtime_protocol.__file__, 'vibecomfy': vibecomfy.__file__, 'declared_vibe_revision': VIBECOMFY_ENGINE_REVISION}))
'''
imports = json.loads(subprocess.check_output([str(PYTHON), '-c', imports_code], cwd=agent, env=env, text=True))
if Path(imports['sdk']).resolve() != (agent / 'astrid_runtime_client/generated.py').resolve():
    raise SystemExit('Agent vendored SDK is not the selected SDK')
if not Path(imports['runtime_protocol']).resolve().is_relative_to(repos['runtime']):
    raise SystemExit('Runtime import came from wrong checkout')
if not Path(imports['vibecomfy']).resolve().is_relative_to(repos['vibe']):
    raise SystemExit('Vibe import came from wrong checkout')
if imports['declared_vibe_revision'] != configuration['vibe'][1]:
    raise SystemExit('Agent declared Vibe pin does not match checkout')
command = [str(PYTHON), '-m', 'pytest', '-q', '-rA', '-m', 'integration or not integration',
           'tests/test_vendor_lock.py',
           'tests/test_windows_path_budget.py::test_installed_runtime_pinned_source_witness_fits_fresh_version_staging',
           f'--basetemp={prefix}-tmp', f'--junitxml={prefix}.xml']
metadata = {
    'kind': 'visible pin-proposal guard comparison; not accepted final pin qualification',
    'label': label, 'command': command, 'cwd': str(agent), 'environment': environment,
    'selection': 'Entire unchanged tests/test_vendor_lock.py and exact installed Runtime Windows witness selector',
    'marker_override': 'Tautological integration or not integration retains all selected cases; no marker deselection',
    'started_utc': utc(), 'before': before, 'imports': imports,
    'runtime_pin': lock['source_commit'], 'vibe_pin': imports['declared_vibe_revision'],
    'frozen_test_sha256': expected_tests, 'expected_static_literal_failures': expected_failures,
    'free_bytes_before': free_before, 'runner_sha256': sha(Path(__file__).read_bytes()),
}
prefix.with_suffix('.before.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
print(json.dumps({'event': 'starting', 'label': label, 'selected_agent_commit': configuration['agent'][1], 'runtime_pin': metadata['runtime_pin'], 'vibe_pin': metadata['vibe_pin'], 'imports': imports}, sort_keys=True), flush=True)
start = time.monotonic()
with prefix.with_suffix('.log').open('w') as log:
    result = subprocess.run(command, cwd=agent, env=env, stdout=log, stderr=subprocess.STDOUT)
metadata['exit_code'] = result.returncode
metadata['elapsed_seconds'] = time.monotonic() - start
metadata['finished_utc'] = utc()
metadata['after'] = snapshot()
metadata['source_stable'] = metadata['before'] == metadata['after']
records = []
for case in ET.parse(prefix.with_suffix('.xml')).findall('.//testcase'):
    failure = case.find('failure')
    error = case.find('error')
    skipped = case.find('skipped')
    detail = failure if failure is not None else error if error is not None else skipped
    records.append({
        'id': case.attrib['classname'] + '::' + case.attrib['name'],
        'status': 'failure' if failure is not None else 'error' if error is not None else 'skipped' if skipped is not None else 'passed',
        'message': detail.attrib.get('message', '') if detail is not None else '',
    })
metadata['cases'] = records
metadata['counts'] = dict(collections.Counter(case['status'] for case in records))
metadata['case_count'] = len(records)
metadata['failure_classification'] = []
for record in records:
    if record['status'] == 'passed':
        continue
    expected = expected_failures.get(record['id'])
    correct = record['status'] == 'failure' and expected is not None and expected in record['message'] and metadata['runtime_pin'] in record['message']
    metadata['failure_classification'].append({
        **record, 'expected_literal': expected, 'actual_declared_runtime_pin': metadata['runtime_pin'],
        'matches_expected_stale_literal_failure': correct,
        'normalized_message': record['message'].replace(metadata['runtime_pin'], '<declared Runtime pin>'),
    })
metadata['unexpected_nonpassing'] = [r for r in metadata['failure_classification'] if not r['matches_expected_stale_literal_failure']]
metadata['expected_failure_ids_exact'] = {r['id'] for r in metadata['failure_classification']} == set(expected_failures)
metadata['free_bytes_after'] = shutil.disk_usage(ROOT).free
metadata['artifacts'] = {extension: {'path': str(prefix.with_suffix(extension)), 'sha256': sha(prefix.with_suffix(extension).read_bytes())} for extension in ['.log', '.xml']}
metadata['expected_observation_confirmed'] = (len(records) == 17 and metadata['counts'] == {'failure': 2, 'passed': 15} and result.returncode == 1 and metadata['source_stable'] and not metadata['unexpected_nonpassing'] and metadata['expected_failure_ids_exact'] and metadata['free_bytes_after'] >= 1024 ** 3)
metadata['limits'] = ['This is proposal review evidence while Lead approval is pending.', 'Both known failing assertions execute and remain failures. Statements after their failing literal assertions are not reached.', 'No test/source/pin/workflow is edited and no selected case is deselected or marked xfail.']
prefix.with_suffix('.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
for line in prefix.with_suffix('.log').read_text().splitlines():
    if line.startswith(('FAILED ', 'ERROR ')) or (' failed' in line and ' passed' in line):
        print(line)
print(json.dumps({'event': 'completed', 'label': label, 'counts': metadata['counts'], 'case_count': len(records), 'source_stable': metadata['source_stable'], 'unexpected_nonpassing': metadata['unexpected_nonpassing'], 'expected_observation_confirmed': metadata['expected_observation_confirmed'], 'metadata': str(prefix.with_suffix('.json'))}, sort_keys=True), flush=True)
raise SystemExit(0 if metadata['expected_observation_confirmed'] else 2)
