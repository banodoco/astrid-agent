from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
REPO = ROOT / 'agent-focused41-before'
API = json.loads((PROOF / 'rework-agent-hosted-8243-meter-api.json').read_text())
CURRENT = '8243ef8f97ee2022fba0d95d54deb8a89aa2e5a9'
PRIOR = '419fb512a719cf1d1dfe71791e9668bc5089db5a'
BASE = '493616c1cfc7a83f18894dc81773571e977f26ef'
EXPECTED = '08b770d9493a1d1c567b2c4d2166c2b1d794784b'
OBSERVED = 'dba38f8644c46f652376f2cd5112ea161e40f09b'


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def file_record(path: Path) -> dict:
    data = path.read_bytes()
    return {'file': str(path), 'bytes': len(data), 'sha256': digest(data)}


def inspect_artifact(label: str, artifact_id: int, expected_sha: str) -> dict:
    archive = PROOF / f'rework-agent-hosted-{label}.zip'
    assert digest(archive.read_bytes()) == expected_sha
    destination = PROOF / f'rework-agent-hosted-{label}'
    with zipfile.ZipFile(archive) as source:
        selected = [name for name in source.namelist()
                    if name.startswith('plan55-meter-proof/') and not name.endswith('/')]
        extracted = []
        for name in selected:
            relative = Path(name).relative_to('plan55-meter-proof')
            assert '..' not in relative.parts
            path = destination / relative
            write_new(path, source.read(name))
            extracted.append(file_record(path))
    pair = json.loads((destination / 'summary.json').read_text())
    historical = json.loads((destination / 'historical-control/summary.json').read_text())
    sources = json.loads((destination / 'sources.json').read_text())
    junit = ET.parse(destination / 'historical-control/latency.xml')
    failures, errors = [], []
    for case in junit.iter('testcase'):
        node_id = case.get('classname') + '::' + case.get('name')
        for element in case.findall('failure'):
            message = element.get('message', '')
            match = re.search(r'ASTRID_VIBECOMFY_CHECKOUT must resolve to VibeComfy revision [a-f0-9]+', message)
            failures.append({'id': node_id, 'message': message,
                             'signature': match.group(0) if match else None})
        for element in case.findall('error'):
            errors.append({'id': node_id, 'message': element.get('message', '')})
    assert pair['status'] == historical['status'] == 'NO-RESULT'
    assert pair['base'] == BASE
    assert pair['candidate'] == sources['agent']
    assert pair['historical_harness_source'] == BASE
    assert sources['vibecomfy'] == OBSERVED
    assert len(failures) == 10
    assert all(item['signature'] == f'ASTRID_VIBECOMFY_CHECKOUT must resolve to VibeComfy revision {EXPECTED}'
               for item in failures)
    return {
        'artifact_id': artifact_id, 'archive': file_record(archive),
        'extracted_meter_files': extracted, 'sources': sources,
        'suite_attributes': [suite.attrib for suite in junit.iter('testsuite')],
        'pair_summary': pair, 'historical_control_summary': historical,
        'failures': failures, 'teardown_errors': errors,
        'candidate_pair_measured': False,
    }


specs = [
    ('8243-meter-ubuntu', 14488917052, 'a067b18dd1b05a93c3d2d0de8325408c61580b064905a2ff4a9b14e2bc223d72'),
    ('8243-meter-windows', 14488756495, 'd5ec46d6ab22d88535d3fcd513ee6f6ac39a962a1bea069f9c666b3a845c7885'),
    ('419-meter-ubuntu', 14486831852, '8335fc380797e829598201bd7a6694af97d80302972ba217767eaa376f7f5365'),
    ('419-meter-windows', 14486912426, '34bfb462e35db66f6077b3113033320a097fdfdd11285a6935df1a0910faee8f'),
]
observations = {label: inspect_artifact(label, artifact_id, sha) for label, artifact_id, sha in specs}
comparison = {}
for platform in ('ubuntu', 'windows'):
    current = observations[f'8243-meter-{platform}']
    prior = observations[f'419-meter-{platform}']
    comparison[platform] = {
        'same_failure_ids': [f['id'] for f in current['failures']] == [f['id'] for f in prior['failures']],
        'same_failure_signatures': [f['signature'] for f in current['failures']] == [f['signature'] for f in prior['failures']],
        'same_exact_teardown_ids_and_messages': current['teardown_errors'] == prior['teardown_errors'],
        'runtime_same': current['sources']['runtime'] == prior['sources']['runtime'],
        'vibecomfy_same': current['sources']['vibecomfy'] == prior['sources']['vibecomfy'],
        'accepted_historical_harness_same': current['pair_summary']['historical_harness_source'] == prior['pair_summary']['historical_harness_source'],
    }
    assert all(comparison[platform].values())

source_paths = [
    '.github/workflows/plan55-native-flush.yml',
    'tests/local_speed_paired_run.py',
    'astrid/core/generation/vibecomfy_dependency.py',
    'astrid/packs/vibecomfy/pins.json',
]
source_capture = {}
for commit in (CURRENT, PRIOR):
    files = []
    for relative in source_paths:
        raw = subprocess.check_output(['git', 'show', f'{commit}:{relative}'], cwd=REPO)
        lines = raw.decode().splitlines()
        matches = [(number + 1, line) for number, line in enumerate(lines)
                   if any(word in line for word in (
                       'must resolve to VibeComfy revision', EXPECTED, OBSERVED,
                       'historical-control', 'historical_harness_source',
                       'summary["candidate"]', 'historical_control = measure',
                       'actual = measure', 'paired = measure'))]
        files.append({'path': relative, 'bytes': len(raw), 'sha256': digest(raw),
                      'selected_lines': [{'line': line, 'text': text} for line, text in matches]})
    source_capture[commit] = {'tree': subprocess.check_output(
        ['git', 'rev-parse', f'{commit}^{{tree}}'], cwd=REPO, text=True).strip(), 'files': files}

for current, prior in zip(source_capture[CURRENT]['files'], source_capture[PRIOR]['files']):
    comparison.setdefault('source_files', []).append({
        'path': current['path'], 'byte_identical': current['sha256'] == prior['sha256']})

jobs = [{key: job.get(key) for key in ('id', 'name', 'status', 'conclusion', 'html_url', 'started_at', 'completed_at')}
        | {'failed_steps': [step for step in job['steps'] if step.get('conclusion') == 'failure']}
        for job in API['jobs']]
other_runs = [{key: run.get(key) for key in ('id', 'name', 'status', 'conclusion', 'html_url', 'run_attempt', 'updated_at')}
              | {'classification': 'observed only; not investigated in this meter-only task',
                 'qualified_result': 'NO-RESULT' if run.get('status') != 'completed' or run.get('conclusion') == 'skipped' else None}
              for run in API['head_runs'] if run['id'] != 44434248062]
report = {
    'scope': 'Read-only classification of Agent8243 standing-meter run44434248062; no CI or repository mutation.',
    'retrieved_at': API['retrieved_at'],
    'source_head': CURRENT, 'comparator_head': PRIOR,
    'run_id': 44434248062, 'comparator_run_id': 44430362783,
    'run_url': 'https://github.com/banodoco/astrid-agent/actions/runs/44434248062',
    'conclusion': 'failure', 'qualified_meter_result': 'NO-RESULT',
    'primary_classification': 'Exact VibeComfy checkout identity refusal during historical-control warmup; workflow pin and product pack pin differ.',
    'expected_vibecomfy_product_pin': EXPECTED,
    'observed_vibecomfy_workflow_checkout': OBSERVED,
    'control_source_explanation': 'Historical-control uses candidate product bytes with the accepted-base493 harness overlaid. It does not use493 product bytes. The calibrated reference/base-validation/candidate stages are not reached.',
    'policy_explanation': 'Meter policy from accepted base succeeds; exact dependency source byte check succeeds. Failure is step18 Compare exact base and candidate on the same runner.',
    'windows_teardown_classification': 'Ten PytestUnhandledThreadExceptionWarning teardown errors retained. Exact IDs and messages match prior419. Underlying thread-exception cause is not established by these artifacts and is not relabeled as a pin refusal.',
    'product_failure_assessment': 'No new candidate product regression established by this meter snapshot. The source identity refusal and Windows teardown signatures also occur on prior419. No green-CI, performance, counter, or budget claim follows.',
    'jobs': jobs, 'same_head_other_runs_snapshot': other_runs,
    'paired_comparison': comparison, 'sources': source_capture,
    'observations': observations,
    'prior_c98_limit': 'Run44404943048 used an older direct-baseline workflow and failed at step16 Run repeated SDK and CLI baseline separately from counters. It is not treated as the same paired-run comparator; prior419 provides the direct same-step/signature comparison.',
    'raw_job_logs': [file_record(PROOF / name) for name in (
        'rework-agent-hosted-8243-meter-ubuntu-job.log',
        'rework-agent-hosted-8243-meter-windows-job.log',
        'rework-agent-hosted-419-meter-ubuntu-job.log')],
    'api_snapshot': file_record(PROOF / 'rework-agent-hosted-8243-meter-api.json'),
    'prohibited_actions_performed': [],
}
path = PROOF / 'rework-agent-hosted-8243-meter-classification.json'
write_new(path, (json.dumps(report, indent=2) + '\n').encode())
print(json.dumps({'report': file_record(path), 'paired_comparison': comparison, 'jobs': jobs}, indent=2))
