from __future__ import annotations

import ast
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
PLAN = PROOF / 'rework-agent-focused41-plan.json'
BASELINE = PROOF / 'rework-agent-focused41-before-1.json'
PREFIX = PROOF / 'rework-agent-focused41-after-1'
PYTHON = ROOT / 'test-env/bin/python'
plan = json.loads(PLAN.read_text())
baseline = json.loads(BASELINE.read_text())
repos = {'agent': ROOT / 'agent-pin-guard-after', 'runtime': ROOT / 'astrid-runtime', 'vibe': ROOT / 'VibeComfy'}
expected_heads = {'agent': '68c7911e581e85bc70c357806260e88300247ed0', 'runtime': '62333bd797e84b21cb3995e4bcf580ed0bdcf9f0', 'vibe': '3150d77a39c7ee2e5a85e2f6fabcded63af2d081'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo)


def snapshot():
    result = {}
    for name, repo in repos.items():
        paths = git(repo, 'ls-files', '-z').decode().strip('\0').split('\0')
        hashes = {}
        for path in paths:
            if not path or path.startswith('docs/evidence/'):
                continue
            source = repo / path
            hashes[path] = sha(source.read_bytes()) if source.is_file() else None
        result[name] = {'path': str(repo), 'head': git(repo, 'rev-parse', 'HEAD').decode().strip(), 'tree': git(repo, 'rev-parse', 'HEAD^{tree}').decode().strip(), 'status': git(repo, 'status', '--short').decode(), 'tracked_diff_sha256': sha(git(repo, 'diff', '--binary', 'HEAD')), 'source_sha256': hashes, 'source_exclusion': 'docs/evidence/** historical evidence only'}
    source = (repos['runtime'] / 'runtime_protocol/store.py').read_bytes()
    function = next(n for n in ast.walk(ast.parse(source.decode())) if isinstance(n, ast.FunctionDef) and n.name == '_associate_managed_outputs')
    guard = b''.join(source.splitlines(keepends=True)[function.lineno - 1:function.end_lineno])
    return {'repositories': result, 'immutable_association_guard': {'bytes': len(guard), 'sha256': sha(guard)}, 'frozen_plan_sha256': sha(PLAN.read_bytes())}


if PREFIX.with_suffix('.json').exists() or PREFIX.with_suffix('.log').exists():
    raise SystemExit('Refusing to repeat or overwrite the final41 observation')
if sha(PLAN.read_bytes()) != baseline['plan_sha256']:
    raise SystemExit('Frozen selection plan changed since baseline')
if [c['id'] for c in baseline['cases']] != plan['expected_junit_ids']:
    raise SystemExit('Baseline is not the frozen exact ordered41 selection')
if baseline['counts'] != {'passed': 39, 'failure': 2, 'error': 0, 'skipped': 0} or not baseline['source_stable']:
    raise SystemExit('Unexpected baseline observation')
before = snapshot()
for name, state in before['repositories'].items():
    if state['head'] != expected_heads[name] or state['status']:
        raise SystemExit('Selected checkout identity changed or is unclean: ' + name)
agent_hashes = before['repositories']['agent']['source_sha256']
product_pin_paths = {'runtime.lock.json', 'astrid/resources/runtime.lock.json', 'astrid_runtime_client/generated.py'}
for path, expected in plan['frozen_source_sha256'].items():
    if path not in product_pin_paths and agent_hashes[path] != expected:
        raise SystemExit('Frozen selected test/helper/config source changed: ' + path)
if before['immutable_association_guard']['sha256'] != '6a155b6817f74ae7540f8975c2dcf00358e13a544fb0da3e8a22151d3af25f2f':
    raise SystemExit('Immutable association guard changed')
free_before = shutil.disk_usage(ROOT).free
if free_before < 1024 ** 3:
    raise SystemExit('One GiB reserve unavailable')
for relative in ['runtime.lock.json', 'astrid/resources/runtime.lock.json']:
    if json.loads((repos['agent'] / relative).read_text())['source_commit'] != expected_heads['runtime']:
        raise SystemExit('Declared Runtime pin mismatch: ' + relative)
environment = {'PYTHONPATH': ':'.join(str(repos[k]) for k in ['agent', 'runtime', 'vibe']), 'ASTRID_RUNTIME_CHECKOUT': str(repos['runtime']), 'ASTRID_VIBECOMFY_CHECKOUT': str(repos['vibe']), 'PYTHONDONTWRITEBYTECODE': '1'}
env = os.environ.copy()
env.update(environment)
imports_code = '''import json, sys
import astrid
import astrid_runtime_client.generated as client
import runtime_protocol.service as runtime
import vibecomfy.runtime.output_receipts as vibe
from astrid.core.generation.vibecomfy_dependency import VIBECOMFY_ENGINE_REVISION
print(json.dumps({'modules': {'astrid': astrid.__file__, 'astrid_runtime_client.generated': client.__file__, 'runtime_protocol.service': runtime.__file__, 'vibecomfy.runtime.output_receipts': vibe.__file__}, 'python': sys.version, 'declared_vibe_revision': VIBECOMFY_ENGINE_REVISION}))
'''
imports = json.loads(subprocess.check_output([str(PYTHON), '-c', imports_code], cwd=repos['agent'], env=env, text=True))
for module, key in [('astrid', 'agent'), ('astrid_runtime_client.generated', 'agent'), ('runtime_protocol.service', 'runtime'), ('vibecomfy.runtime.output_receipts', 'vibe')]:
    if not Path(imports['modules'][module]).resolve().is_relative_to(repos[key]):
        raise SystemExit('Import came from wrong checkout: ' + module)
if imports['declared_vibe_revision'] != expected_heads['vibe']:
    raise SystemExit('Declared Vibe pin mismatch')
command = [str(PYTHON), '-m', 'pytest', '-q', '-rA', '-m', 'integration or not integration', *plan['selectors'], f'--basetemp={PREFIX}-tmp', f'--junitxml={PREFIX}.xml']
metadata = {'label': 'proposed pinned Agent focused41 AFTER, local paired verification', 'qualification': 'Pins remain proposals for Lead integration acceptance', 'plan': str(PLAN), 'plan_sha256': sha(PLAN.read_bytes()), 'baseline': str(BASELINE), 'baseline_sha256': sha(BASELINE.read_bytes()), 'cwd': str(repos['agent']), 'command_argv': command, 'environment_overrides': environment, 'started_utc': utc(), 'before': before, 'imports': imports, 'expected_junit_ids': plan['expected_junit_ids'], 'expected_after': {'passed': 41, 'failure': 0, 'error': 0, 'skipped': 0}, 'test_helper_config_bytes_match_frozen_baseline': True, 'proposed_product_pin_artifact_changes': {path: {'before': plan['frozen_source_sha256'][path], 'after': agent_hashes[path]} for path in sorted(product_pin_paths)}, 'free_bytes_before': free_before, 'runner_sha256': sha(Path(__file__).read_bytes()), 'concurrency': 'Separate basetemp; another root-owned counter helper may read the same frozen checkout sources.'}
PREFIX.with_suffix('.before.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
print(json.dumps({'event': 'starting', 'heads': expected_heads, 'selection': plan['selection_counts'], 'imports': imports, 'free_bytes': free_before}, sort_keys=True), flush=True)
start = time.monotonic()
with PREFIX.with_suffix('.log').open('w') as log:
    child = subprocess.Popen(command, cwd=repos['agent'], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in child.stdout:
        log.write(line)
        log.flush()
        if line.startswith(('FAILED ', 'ERROR ')) or ' passed' in line or ' failed' in line or '[100%]' in line:
            print(line, end='', flush=True)
    returncode = child.wait()
metadata['exit_code'] = returncode
metadata['elapsed_seconds'] = time.monotonic() - start
metadata['finished_utc'] = utc()
metadata['after'] = snapshot()
metadata['source_stable'] = metadata['before'] == metadata['after']
cases = []
for case in ET.parse(PREFIX.with_suffix('.xml')).findall('.//testcase'):
    failure = case.find('failure')
    error = case.find('error')
    skipped = case.find('skipped')
    detail = failure if failure is not None else error if error is not None else skipped
    cases.append({'id': case.attrib['classname'] + '::' + case.attrib['name'], 'outcome': 'failure' if failure is not None else 'error' if error is not None else 'skipped' if skipped is not None else 'passed', 'message': detail.attrib.get('message', '') if detail is not None else None})
metadata['cases'] = cases
counts = collections.Counter(case['outcome'] for case in cases)
metadata['counts'] = {outcome: counts[outcome] for outcome in ['passed', 'failure', 'error', 'skipped']}
metadata['ids_exact_order'] = [case['id'] for case in cases] == plan['expected_junit_ids']
metadata['unexpected_nonpassing'] = [case for case in cases if case['outcome'] != 'passed']
metadata['free_bytes_after'] = shutil.disk_usage(ROOT).free
metadata['artifacts'] = {ext: {'path': str(PREFIX.with_suffix(ext)), 'sha256': sha(PREFIX.with_suffix(ext).read_bytes())} for ext in ['.log', '.xml']}
metadata['verified_expected_result'] = (returncode == 0 and metadata['counts'] == metadata['expected_after'] and metadata['ids_exact_order'] and metadata['source_stable'] and metadata['free_bytes_after'] >= 1024 ** 3)
PREFIX.with_suffix('.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
print(json.dumps({'event': 'completed', 'exit_code': returncode, 'counts': metadata['counts'], 'ids_exact_order': metadata['ids_exact_order'], 'source_stable': metadata['source_stable'], 'unexpected_nonpassing': metadata['unexpected_nonpassing'], 'verified_expected_result': metadata['verified_expected_result'], 'metadata': str(PREFIX.with_suffix('.json'))}, sort_keys=True), flush=True)
raise SystemExit(0 if metadata['verified_expected_result'] else 2)
