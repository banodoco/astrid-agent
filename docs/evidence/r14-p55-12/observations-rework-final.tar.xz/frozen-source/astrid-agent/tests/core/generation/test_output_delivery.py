"""BUG-15: exact public argv must deliver Runtime bytes to the caller.

ComfyUI wire responses are the checked-in S-45 live captures. Inference and
Runtime settlement are CPU fakes; the CLI, SDK preparation, bundle compiler,
result reconstruction, CAS reads, verification and local export are real.
"""
from __future__ import annotations

import hashlib
import io
import json
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace
from urllib.parse import urlsplit

import pytest
from PIL import Image

from astrid import console
from astrid.core.generation import cli, preflight
from astrid.core.generation.backends.comfy_target import ComfyTarget, ComfyTargetClient
from astrid.sdk.results import InvocationResult

FIXTURE = Path(__file__).parents[2] / 'fixtures/comfyui/live-423cbd20'
TASK_ID = '200fed415f794e54aa01274b7eee6599'
PROMPT = 'A small red fox beside a blue ceramic teacup, clean studio light'


def sha(data):
    return hashlib.sha256(data).hexdigest()


@pytest.fixture
def runtime(monkeypatch, tmp_path):
    def captured(name):
        return json.loads((FIXTURE / name).read_text())
    object_info = {**captured('used-nodes.json'), **captured('qwen-delivery-nodes.json')}
    history = captured('history.json')
    prompt_id, historical = next(iter(history.items()))
    dims = historical['outputs']['13']['images'][0]['metadata']
    image = io.BytesIO()
    Image.new('RGB', (dims['width'], dims['height']), (128, 32, 16)).save(image, format='PNG')
    state = SimpleNamespace(image=image.getvalue(), calls=[], objects={}, reads=[],
                            closed=False, admissions=0, rows=[], corrupt=None)

    class Response(io.BytesIO):
        status = 200

    def opener(request, timeout):
        path = urlsplit(request.full_url).path
        state.calls.append(path)
        if path == '/view':
            return Response(state.image)
        payload = {'/object_info': object_info,
                   '/system_stats': captured('system-stats.json'),
                   '/history/' + prompt_id: history,
                   '/prompt': {'prompt_id': prompt_id, 'node_errors': {}}}[path]
        return Response(json.dumps(payload).encode())

    comfy = ComfyTargetClient(ComfyTarget('http://127.0.0.1:8188', 'managed'), opener=opener)
    monkeypatch.setattr(preflight, 'select_generation_target', lambda *args, **kwargs: comfy)
    # The CPU installation has no running ComfyUI schema registry. Supply the
    # captured server schema at its authoring-provider seam; validation stays on.
    import vibecomfy.schema

    from astrid.core.generation.backends.comfy_schema import TargetSchemaProvider
    schema = TargetSchemaProvider.from_object_info(object_info, server_url=comfy.http_origin)
    monkeypatch.setattr(vibecomfy.schema, 'get_authoring_schema_provider', lambda **kwargs: schema)
    import vibecomfy.schema.provider
    monkeypatch.setattr(vibecomfy.schema.provider, 'get_authoring_schema_provider', lambda **kwargs: schema)

    def store(data):
        digest = 'sha256:' + sha(data)
        state.objects[digest] = data
        return digest

    def import_file(*, project, path):
        assert project == 'gpu-shakedown'
        data = path.read_bytes()
        digest = store(data)
        retained = tmp_path / 'runtime' / sha(data) / path.name
        retained.parent.mkdir(parents=True, exist_ok=True)
        retained.write_bytes(data)
        return SimpleNamespace(ok=True, data={'object_id': digest, 'filename': path.name})

    def read_bytes(digest):
        assert not state.closed, 'delivery must finish before the Runtime connection closes'
        state.reads.append(digest)
        if state.corrupt == digest:
            return b'corrupted transport bytes'
        return state.objects[digest]

    def invoke_result(capability, **kwargs):
        from vibecomfy.security.provenance import Provenance
        from vibecomfy.workflow_bundle import load_bundle

        assert capability == 'vibecomfy.run'
        state.admissions += 1
        assert kwargs['project'] == 'gpu-shakedown'
        source = kwargs['inputs']['python']
        path = tmp_path / 'runtime' / source['sha256'] / source['filename']
        companion = kwargs['inputs']['companion']
        path.with_suffix('.vibe.json').write_bytes(state.objects[companion['digest']])
        workflow = load_bundle(path, trust=Provenance.USER_CONFIRMED, schema_provider=schema).workflow
        api = workflow.compile('api')
        nodes = {node['class_type']: node['inputs'] for node in api.values()}
        assert nodes['EmptyLatentImage']['width'] == 512
        assert nodes['EmptyLatentImage']['height'] == 512
        assert nodes['RandomNoise']['noise_seed'] == 19
        assert nodes['TextEncodeQwenImage21']['prompt'] == PROMPT
        comfy.submit_prompt({'prompt': api})
        output = comfy.history(prompt_id)[prompt_id]['outputs']['13']['images'][0]
        downloaded = tmp_path / 'fake-worker.png'
        comfy.download_output(output, downloaded)
        digest = store(downloaded.read_bytes())
        producer = {'producer_output_id': 'vibecomfy:image:0', 'output_port': 'image',
                    'ordinal': 0, 'path': 'outputs/Qwen_image_2.1.png',
                    'sha256': digest.removeprefix('sha256:'), 'bytes': len(state.image),
                    'media_type': 'image/png'}
        manifest_ref = store(json.dumps({'kind': 'managed-generation-result.v1',
                                         'schema_version': 1, 'outputs': [producer]}).encode())
        row = {'association_id': 'managed-output-image', 'project_id': 'gpu-shakedown',
               'run_id': 'run-1', 'task_id': TASK_ID, 'attempt_id': 'attempt-1',
               'generation_id': 'generation-fixture', 'output_port': 'vibecomfy_run',
               'selector': {'group_key': 'main', 'variant_key': 'original'},
               'ordinal': 0, 'role': 'result', 'filename': 'Qwen_image_2.1.png',
               'media_type': 'image/png', 'size': len(state.image), 'digest': digest,
               'object_id': digest, 'durability': 'durable', 'manifest_ref': manifest_ref}
        thumbnail = {**row, 'association_id': 'thumbnail', 'role': 'thumbnail'}
        state.rows = [row, thumbnail]
        state.manifest_ref = manifest_ref
        if state.corrupt == 'image':
            state.corrupt = digest
        elif state.corrupt == 'manifest':
            state.corrupt = manifest_ref
        # Worker spool is gone before the SDK sees the settled associations.
        downloaded.unlink()
        state.task = {'task_id': TASK_ID, 'state': 'COMPLETED',
                      'result': {'manifest_ref': manifest_ref}}
        return InvocationResult(capability, 'executor', 'command', True,
            kernel_task_id=TASK_ID, raw_result={'task': state.task, 'managed_outputs': state.rows})

    from astrid.sdk.remote import RemoteMedia
    transport = SimpleNamespace(get_object=lambda digest: {'data': read_bytes(digest)},
        list_project_objects=lambda project, **kwargs: ([
            {'object_id': digest, 'digest': digest, 'size': len(data),
             'filename': 'manifest.json' if data.startswith(b'{') else 'Qwen_image_2.1.png',
             'media_type': 'application/json' if data.startswith(b'{') else 'image/png'}
            for digest, data in state.objects.items()], None))
    media = RemoteMedia(transport)
    media.import_file = import_file
    state.client = SimpleNamespace(invoke_result=invoke_result, media=media)

    @contextmanager
    def connection():
        try:
            yield state.client
        finally:
            state.closed = True

    monkeypatch.setattr(cli, '_open_client', connection)
    from astrid.core.pack.discovery import pack_discovery_scope
    with pack_discovery_scope():
        yield state


def argv(out=None, *, placement='managed'):
    args = ['generate', 'image', '--entry', 'qwen-image-2.1-turbo', '--mode', 't2i',
            '--placement', placement, '--width', '512', '--height', '512', '--seed', '19',
            '--project', 'gpu-shakedown', '--consent', 'user_env', '--json', PROMPT]
    if out is not None:
        args += ['--out', str(out)]
    return args


@pytest.mark.parametrize('target', ['managed', 'auto', 'http://127.0.0.1:8188'])
@pytest.mark.parametrize('destination', ['file', 'directory', 'default'])
def test_exact_cli_delivers_verified_caller_local_image(runtime, tmp_path, monkeypatch, capsys,
                                                       target, destination):
    monkeypatch.chdir(tmp_path)
    out = {'file': tmp_path / 'out/R4-512.png', 'directory': tmp_path / 'export',
           'default': None}[destination]
    assert console.main(argv(out, placement=target)) == 0
    payload = json.loads(capsys.readouterr().out)
    expected = (out if destination == 'file' else
                (out or tmp_path / 'outputs' / TASK_ID) / 'Qwen_image_2.1.png')
    assert payload['image_paths'] == [str(expected)]
    assert payload['run_dir'] == str(expected.parent)
    assert expected.is_file()
    assert sha(expected.read_bytes()) == runtime.rows[0]['digest'].removeprefix('sha256:')
    with Image.open(expected) as image:
        assert image.size == (512, 512)
    assert runtime.task['state'] == 'COMPLETED'
    assert runtime.rows[0]['generation_id']
    assert runtime.reads == [runtime.manifest_ref, runtime.rows[0]['object_id']]
    assert runtime.admissions == 1 and runtime.closed
    assert '/view' in runtime.calls


@pytest.mark.parametrize('corrupt', ['image', 'manifest'])
def test_corruption_fails_cli_without_replacing_requested_file(runtime, tmp_path, capsys, corrupt):
    runtime.corrupt = corrupt
    out = tmp_path / 'R4-512.png'
    out.write_bytes(b'previous caller file')
    assert console.main(argv(out)) == 2
    payload = json.loads(capsys.readouterr().out)
    assert payload['issues'][0]['code'] == 'output_delivery_failed'
    assert payload['task_id'] == TASK_ID
    assert 'identity' in payload['issues'][0]['message']
    assert out.read_bytes() == b'previous caller file'
    assert runtime.closed


def test_no_wait_returns_admission_without_local_delivery(runtime, tmp_path, capsys):
    out = tmp_path / 'R4-512.png'
    assert console.main([*argv(out), '--no-wait']) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload['kernel_task_id'] == TASK_ID
    assert not runtime.reads and not out.exists()


def settled_media(*, filenames=('one.png', 'two.png')):
    """A settled Runtime whose public media facade and integrity checks are real."""
    from astrid.sdk.remote import RemoteMedia

    objects, metadata, outputs, rows = {}, [], [], []
    for index, filename in enumerate(filenames):
        data = f'output {index}'.encode()
        digest = 'sha256:' + sha(data)
        objects[digest] = data
        row = {'object_id': digest, 'digest': digest, 'size': len(data),
               'filename': filename, 'media_type': 'image/png', 'role': 'result',
               'project_id': 'project-1'}
        rows.append(row)
        metadata.append(row)
        outputs.append({'sha256': sha(data), 'bytes': len(data), 'path': filename})
    manifest = json.dumps({'outputs': outputs}).encode()
    reference = 'sha256:' + sha(manifest)
    objects[reference] = manifest
    metadata.append({'object_id': reference, 'size': len(manifest),
                     'filename': 'manifest.json', 'media_type': 'application/json'})
    transport = SimpleNamespace(get_object=lambda digest: {'data': objects[digest]},
        list_project_objects=lambda project, **kwargs: (metadata, None))
    payload = {'task_id': 'task-1', 'manifest_ref': reference,
               'manifest': {'outputs': rows}, 'image_paths': [], 'run_dir': None}
    return SimpleNamespace(payload=payload, rows=rows, objects=objects,
                           client=SimpleNamespace(media=RemoteMedia(transport)))


@pytest.mark.parametrize('file_output', [True, False])
def test_each_output_is_delivered_with_collision_safe_names(tmp_path, file_output):
    from astrid.core.generation.delivery import deliver_generation

    runtime = settled_media(filenames=('../../same.png', '../../same.png'))
    out = tmp_path / ('result.png' if file_output else 'export')
    payload = deliver_generation(runtime.payload, client=runtime.client, out=out)
    paths = [Path(path) for path in payload['image_paths']]
    assert paths == ([out, tmp_path / 'result-2.png'] if file_output else
                     [out / 'same.png', out / '2-same.png'])
    assert [path.read_bytes() for path in paths] == [b'output 0', b'output 1']
    assert not list(Path(payload['run_dir']).glob('.astrid-delivery-*'))


@pytest.mark.parametrize('failure', ['corrupt-second', 'missing-second', 'unsealed-output', 'wrong-size'])
def test_partial_delivery_never_reports_success_or_replaces_prior_file(tmp_path, failure):
    from astrid.core.generation.delivery import deliver_generation

    runtime = settled_media()
    second = runtime.rows[1]['object_id']
    if failure == 'corrupt-second':
        runtime.objects[second] = b'corrupted'
    elif failure == 'missing-second':
        del runtime.objects[second]
    elif failure == 'unsealed-output':
        runtime.rows[1]['digest'] = 'sha256:' + 'a' * 64
    else:
        runtime.rows[1]['size'] += 1
    out = tmp_path / 'result.png'
    out.write_bytes(b'previous caller file')
    with pytest.raises(ValueError, match='local output delivery failed') as caught:
        deliver_generation(runtime.payload, client=runtime.client, out=out)
    assert caught.value.code == 'output_delivery_failed'
    assert caught.value.task_id == 'task-1'
    assert out.read_bytes() == b'previous caller file'
    assert not (tmp_path / 'result-2.png').exists()
    assert not list(tmp_path.glob('.astrid-delivery-*'))


def test_manifest_only_completion_resolves_cas_without_worker_paths(tmp_path):
    from astrid.core.generation.delivery import deliver_generation

    runtime = settled_media(filenames=('one.png',))
    runtime.payload['manifest']['outputs'] = []
    payload = deliver_generation(runtime.payload, client=runtime.client,
                                 out=tmp_path / 'result.png', project='project-1')
    assert Path(payload['image_paths'][0]).read_bytes() == b'output 0'


def test_legacy_provider_uses_the_shared_local_export_path(tmp_path):
    from astrid.core.generation.backends.base import GenerationResult
    from astrid.core.generation.delivery import deliver_generation

    source = tmp_path / 'provider.png'
    source.write_bytes(b'provider output')
    out = tmp_path / 'export/image.png'
    result = GenerationResult(image_paths=[source])
    payload = deliver_generation(result, client=None, out=out)
    assert payload['image_paths'] == [str(out)]
    assert out.read_bytes() == source.read_bytes()


def test_failed_generation_is_preserved_for_the_cli_failure_handler(tmp_path):
    from astrid.core.generation.delivery import deliver_generation

    result = SimpleNamespace(ok=False)
    assert deliver_generation(result, client=None, out=tmp_path / 'image.png') is result


def test_output_hash_passes_across_download_host_runtime_and_delivery(tmp_path, monkeypatch):
    """Count the still-distinct custody checks; Runtime, not a child, validates upload bytes."""
    from astrid.core._shared.result_manifest import harvest_staged_outputs
    from astrid.core.execution.generic_host import GenericPackHost, RuntimeProtocolClient
    from astrid.core.generation.delivery import deliver_generation
    from runtime_protocol.service import RuntimeService
    from runtime_protocol.store import RealmStore

    runtime = settled_media(filenames=('one.png',))
    data = b'output 0'
    digest = 'sha256:' + sha(data)
    root = tmp_path / 'attempt'
    output_root = root / 'outputs'
    output_root.mkdir(parents=True)
    path = output_root / 'one.png'
    counts = []
    original = hashlib.sha256

    class Counted:
        def __init__(self, initial=b'', *args, **kwargs):
            self.value = original(initial, *args, **kwargs)
            if initial == data:
                counts.append('hash')
        def update(self, block):
            if block == data:
                counts.append('hash')
            return self.value.update(block)
        def __getattr__(self, key):
            return getattr(self.value, key)

    class Response(io.BytesIO):
        status = 200
        headers = {'Content-Length': str(len(data))}

    monkeypatch.setattr(hashlib, 'sha256', Counted)
    client = ComfyTargetClient(ComfyTarget('http://127.0.0.1:8188', 'attached'),
                               opener=lambda *_args, **_kwargs: Response(data))
    client.download_output({'filename': 'one.png', 'subfolder': '', 'type': 'output'}, path)
    assert len(counts) == 1
    declared = SimpleNamespace(name='result', path_template='one.png', artifact_type='image/png')
    record = SimpleNamespace(definition=SimpleNamespace(outputs=(declared,), metadata={}))
    (output_root / 'manifest.json').write_text(json.dumps({'outputs': [{
        'name': 'result', 'path': 'one.png', 'content_hash': digest, 'bytes': len(data),
    }]}))
    harvested = harvest_staged_outputs(output_root, declared_outputs=(declared,))
    assert len(counts) == 2
    host = object.__new__(GenericPackHost)
    host.client = object.__new__(RuntimeProtocolClient)
    typed = host._typed_outputs(record, harvested, root, defer_content_check_to_runtime=True)
    outputs = host._upload_outputs(typed, project_id=None)
    assert len(counts) == 2  # no host reread/re-hash after harvest
    assert outputs[0]['digest'] == digest

    realm = tmp_path / 'realm'
    RealmStore.initialize(realm).close()
    service = RuntimeService(realm)
    try:
        before = len(counts)
        service._stage_outputs('attempt-1', outputs)
        assert len(counts) > before  # Runtime verifies the exact inline bytes
    finally:
        service.close()
    before = len(counts)
    result = deliver_generation(runtime.payload, client=runtime.client, out=tmp_path / 'delivered.png')
    assert Path(result['image_paths'][0]).read_bytes() == data
    # SDK response verification and view hash, plus the mutable-path check.
    assert len(counts) - before == 1
