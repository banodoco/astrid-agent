from __future__ import annotations

import ast
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
PLAN = PROOF / 'rework-runtime-focused159-plan.json'
plan = json.loads(PLAN.read_text())
label = sys.argv[1]
if label not in ('before', 'after'):
    raise SystemExit('Use before or after')
spec = plan['proposed_paired_runs'][label]
repo = Path(spec['cwd'])
metadata_path = Path(spec['metadata'])
if metadata_path.exists() or Path(spec['stdout_stderr_log']).exists():
    raise SystemExit('Refusing to overwrite an existing observation')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=repo)


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def snapshot():
    paths = set(git('ls-files', '-z').decode().strip('\0').split('\0'))
    paths.update(plan['new8']['source_sha256'])
    hashes = {}
    for relative in sorted(paths):
        if not relative or relative.startswith('docs/evidence/'):
            continue
        path = repo / relative
        hashes[relative] = digest(path.read_bytes()) if path.is_file() else None
    source = (repo / 'runtime_protocol/store.py').read_bytes()
    fn = next(n for n in ast.walk(ast.parse(source.decode()))
              if isinstance(n, ast.FunctionDef) and n.name == '_associate_managed_outputs')
    guard = b''.join(source.splitlines(keepends=True)[fn.lineno - 1:fn.end_lineno])
    return {
        'head': git('rev-parse', 'HEAD').decode().strip(),
        'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
        'status': git('status', '--short').decode(),
        'tracked_diff_sha256': digest(git('diff', '--binary', 'HEAD')),
        'source_sha256': hashes,
        'source_snapshot_exclusions': ['docs/evidence/** (historical proof only)', 'untracked cache/generated test data; two new selected test files explicitly included'],
        'immutable_guard': {'bytes': len(guard), 'sha256': digest(guard)},
        'free_bytes': shutil.disk_usage(ROOT).free,
    }


before = snapshot()
if before['free_bytes'] < 1024 ** 3:
    raise SystemExit('One GiB reserve is unavailable')
if before['immutable_guard']['sha256'] != plan['immutable_association_guard']['sha256']:
    raise SystemExit('Immutable association guard changed')
for relative, expected in plan['selected_test_source_audit'].items():
    if before['source_sha256'][relative] != expected['sha256']:
        raise SystemExit('Selected test bytes changed: ' + relative)
if label == 'before':
    if before['head'] != plan['pre_rework_base'] or git('diff', 'HEAD'):
        raise SystemExit('Baseline product differs from exact a09')
else:
    if before['head'] != '4b8314bf292e88380572d2acc4c0a23ec57f7b4a':
        raise SystemExit('Candidate HEAD changed before agreed run')
    modified = set(git('diff', '--name-only', 'HEAD').decode().splitlines())
    expected_modified = {'runtime_protocol/store.py', 'runtime_protocol/service.py', 'runtime_protocol/thumbnail_intents.py'}
    if modified != expected_modified:
        raise SystemExit('Candidate diff is not the coordinated three-file patch: ' + repr(modified))

environment = os.environ.copy()
environment.update(spec['environment_overrides'])
metadata = {
    'kind': 'paired focused Runtime 159 observation',
    'label': label,
    'plan': str(PLAN),
    'plan_sha256': digest(PLAN.read_bytes()),
    'runner': str(Path(__file__).resolve()),
    'runner_sha256': digest(Path(__file__).read_bytes()),
    'started_utc': utc(),
    'cwd': str(repo),
    'command_argv': spec['command_argv'],
    'environment_overrides': spec['environment_overrides'],
    'python': subprocess.check_output([spec['command_argv'][0], '--version'], text=True).strip(),
    'dependency_freeze_path': str(PROOF / 'rework-environment-pip-freeze.txt'),
    'dependency_freeze_sha256': digest((PROOF / 'rework-environment-pip-freeze.txt').read_bytes()),
    'source_identity_semantics': 'Detached a09 product with only the exact two new test files overlaid' if label == 'before' else 'Current 4b8314bf HEAD plus uncommitted three-file product diff; source SHA256 and diff identify the candidate, not immutable HEAD alone',
    'before': before,
    'expected_selectors': plan['combined']['selectors'],
}
metadata_path.with_suffix('.before.json').write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
(PROOF / f'rework-runtime-focused159-{label}.product.diff').write_bytes(git('diff', '--binary', 'HEAD'))
print(json.dumps({'event': 'starting', 'label': label, 'head': before['head'], 'tracked_diff_sha256': before['tracked_diff_sha256'], 'selected': len(plan['combined']['selectors']), 'free_bytes': before['free_bytes']}, sort_keys=True), flush=True)
start = time.monotonic()
with Path(spec['stdout_stderr_log']).open('w') as log:
    child = subprocess.Popen(spec['command_argv'], cwd=repo, env=environment,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    for line in child.stdout:
        log.write(line)
        log.flush()
        if '[ ' in line or 'collected ' in line or line.startswith(('FAILED ', 'ERROR ')) or ' passed' in line or ' failed' in line:
            print(line, end='', flush=True)
    returncode = child.wait()
metadata['exit_code'] = returncode
metadata['elapsed_seconds'] = time.monotonic() - start
metadata['finished_utc'] = utc()
metadata['after'] = snapshot()
xml_path = Path(next(a.split('=', 1)[1] for a in spec['command_argv'] if a.startswith('--junitxml=')))
records = []
for case in ET.parse(xml_path).findall('.//testcase'):
    failure = case.find('failure')
    error = case.find('error')
    skipped = case.find('skipped')
    status = 'failure' if failure is not None else 'error' if error is not None else 'skipped' if skipped is not None else 'passed'
    detail = failure if failure is not None else error if error is not None else skipped
    records.append({'id': case.attrib['classname'].replace('.', '/') + '.py::' + case.attrib['name'], 'status': status, 'message': detail.attrib.get('message', '') if detail is not None else ''})
metadata['cases'] = records
metadata['counts'] = dict(collections.Counter(case['status'] for case in records))
actual_ids = [r['id'] for r in records]
expected_ids = plan['combined']['selectors']
metadata['missing_ids'] = sorted(set(expected_ids) - set(actual_ids))
metadata['unexpected_ids'] = sorted(set(actual_ids) - set(expected_ids))
metadata['duplicate_ids'] = sorted(k for k, v in collections.Counter(actual_ids).items() if v != 1)
metadata['same_exact_ordered159'] = actual_ids == expected_ids
metadata['sources_stable'] = metadata['before']['source_sha256'] == metadata['after']['source_sha256']
metadata['identity_stable'] = all(metadata['before'][k] == metadata['after'][k] for k in ['head', 'tree', 'status', 'tracked_diff_sha256', 'immutable_guard'])
prior_failures = {c['id'] for c in plan['new8']['before_cases'] if c['status'] == 'failure'}
metadata['unexpected_nonpass'] = [r for r in records if r['status'] != 'passed' and (label == 'after' or r['id'] not in prior_failures or r['status'] != 'failure')]
metadata['baseline_known_failure_ids'] = sorted(prior_failures) if label == 'before' else []
metadata['baseline_observed_failure_set_matches'] = ({r['id'] for r in records if r['status'] == 'failure'} == prior_failures) if label == 'before' else None
metadata['artifacts'] = {'log': {'path': spec['stdout_stderr_log'], 'sha256': digest(Path(spec['stdout_stderr_log']).read_bytes())}, 'junit': {'path': str(xml_path), 'sha256': digest(xml_path.read_bytes())}}
metadata['verified_expected_result'] = (metadata['same_exact_ordered159'] and metadata['sources_stable'] and metadata['identity_stable'] and not metadata['unexpected_nonpass'] and metadata['after']['free_bytes'] >= 1024 ** 3 and ((label == 'before' and metadata['counts'] == {'passed': 152, 'failure': 7} and returncode == 1) or (label == 'after' and metadata['counts'] == {'passed': 159} and returncode == 0)))
metadata_path.write_text(json.dumps(metadata, indent=2, sort_keys=True) + '\n')
print(json.dumps({'event': 'completed', 'label': label, 'exit_code': returncode, 'counts': metadata['counts'], 'same_exact_ordered159': metadata['same_exact_ordered159'], 'sources_stable': metadata['sources_stable'], 'identity_stable': metadata['identity_stable'], 'unexpected_nonpass': metadata['unexpected_nonpass'], 'verified_expected_result': metadata['verified_expected_result'], 'metadata': str(metadata_path), 'free_bytes_after': metadata['after']['free_bytes']}, sort_keys=True), flush=True)
raise SystemExit(0 if metadata['verified_expected_result'] else 2)
