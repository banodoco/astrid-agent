"""Package the scoped P55-12 rework proof without changing test outcomes."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import tarfile

ROOT = Path(__file__).resolve().parent.parent
PROOF = ROOT / "proof"
REPOS = ("astrid-agent", "astrid-runtime", "VibeComfy")
DEST = Path("docs/evidence/r14-p55-12")
ARCHIVE = "observations-rework-final.tar.xz"
INDEX = "rework-final.json"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def artifact(name):
    path = PROOF / name
    data = path.read_bytes()
    return {"member": name, "bytes": len(data), "sha256": digest(data)}


def result(name, passed, failed=0):
    path = PROOF / name
    cases = ET.parse(path).findall(".//testcase")
    counts = {"passed": 0, "failed": 0, "errors": 0, "skipped": 0}
    for case in cases:
        key = ("failed" if case.find("failure") is not None else
               "errors" if case.find("error") is not None else
               "skipped" if case.find("skipped") is not None else "passed")
        counts[key] += 1
    assert counts == {"passed": passed, "failed": failed, "errors": 0, "skipped": 0}, (name, counts)
    assert len({(c.get("classname"), c.get("name")) for c in cases}) == len(cases)
    return {"counts": counts, "junit": artifact(name)}


core = {
    "agent": {
        "before": result("rework-agent-focused41-before-1.xml", 39, 2),
        "after": result("rework-agent-focused41-after-1.xml", 41),
        "comparison": artifact("rework-agent-focused41-comparison.json"),
        "scope": "35 caller cases, two unchanged installed recoveries, image without ffmpeg, three umask cases",
    },
    "runtime": {
        "before": result("rework-runtime-focused159-before.xml", 152, 7),
        "after": result("rework-runtime-focused159-after.xml", 159),
        "comparison": artifact("rework-runtime-focused159-comparison.json"),
        "immutable_commit_mapping": artifact("rework-runtime-focused159-commit-mapping.json"),
        "scope": "31 stream, 93 settlement/security, 20 canonical-output boundary, seven attempt-log, eight variant cases",
    },
    "vibe": {
        "before": result("rework-vibe-final-before.xml", 13, 4),
        "after": result("rework-vibe-final-head.xml", 17),
        "comparison": artifact("rework-vibe-final-comparison.json"),
        "scope": "equal-byte distinct-path collection/fetch/custody/copy plus refusal and existing receipt cases",
    },
}
counter = json.loads((PROOF / "rework-counter-final-comparison.json").read_text())
assert counter["all_strict_after_checks_passed"] is True

checks = {
    "vibe_pin": result("rework-final-vibe-pin14.xml", 14),
    "runtime_pin_guards_before": result("rework-agent-pin-guards-before.xml", 15, 2),
    "runtime_pin_guards_after": result("rework-agent-pin-guards-after.xml", 15, 2),
    "runtime_pin_guard_comparison": artifact("rework-agent-pin-guards-comparison.json"),
    "schema_equality_and_no_observed_job": result("rework-schema-equality-623.xml", 1),
    "producer_and_consumer_manifest_check": artifact("rework-runtime-pin-generation.json"),
}
known = {
    "legacy_installed_variant_journey": {
        "issue": "https://github.com/banodoco/astrid-dev/issues/958",
        "result": result("rework-installed-variants-68.xml", 0, 1),
        "stop": "First ordinary generation.create_with_variant settlement returns HTTP 422; edit and recovery assertions are not reached.",
    },
    "legacy_creative_effects": {
        "issue": "https://github.com/banodoco/astrid-dev/issues/958",
        "result": result("rework-legacy-logs-623.xml", 0, 2),
        "comparison": artifact("rework-legacy-logs-623.json"),
        "boundary": "Direct service ValidationError (status 422) for create_with_variant and variant.append with canonical durable logs.",
    },
    "ordinary_non_thumbnail_retry": {
        "issue": "https://github.com/banodoco/astrid-dev/issues/926",
        "result": result("rework-general-log-retry-68.xml", 0, 1),
        "boundary": "Owner retry of an ordinary action with durable logs still reaches HTTP 409 at the immutable association guard.",
    },
    "installed_comparison": artifact("rework-installed-diagnostics-comparison.json"),
    "scope_decision": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6996446701",
    "owner": "R14-FIX-12, astrid-dev #959; no #926/#958 repair in this packet",
    "stale_runtime_literals": {
        "comparison": artifact("rework-agent-pin-guards-comparison.json"),
        "detail": "The vendor-lock and Windows path-witness fixed literals fail on both previous and proposed pins. Later assertions in those two cases are not reached; no assertion changed.",
    },
}

files = {}
for path in sorted(PROOF.glob("rework-*")):
    if (path.is_file() and path.suffix != ".zip"
            and path.name != "rework-final-package-summary.json"
            and not path.name.startswith("rework-runtime-hosted-transfer-")):
        files[path.name] = path
    elif path.is_dir() and ("comparison" in path.name or path.name.endswith("-sources") or path.name == "rework-agent-hosted-extracted"):
        for child in sorted(path.rglob("*")):
            if child.is_file():
                files[child.relative_to(PROOF).as_posix()] = child
for name in ("run_focused.py", "build_rework_final_evidence.py", "test_general_log_retry_probe.py",
             "test_legacy_creative_log_settlement.py", "run_runtime_rework_proof.py"):
    files["launchers-and-probes/" + name] = PROOF / name
for name in ("general-log-retry-base.log", "general-log-retry-base.xml", "ls6-full-path-base-1.json"):
    files["recovered-retry-scope/" + name] = PROOF / "recovered-retry-scope" / name
sources = {
    "astrid-agent": [
        "tests/core/execution/test_ls6_thumbnail_recovery.py",
        "tests/core/execution/test_ls6_image_thumbnail_readiness.py",
        "tests/core/execution/test_ls6_variant_thumbnail_recovery.py",
        "tests/core/generation/test_ls6_export_permissions.py",
        "tests/core/generation/test_output_delivery.py",
        "tests/ls6_output_counters.py", "tests/_local_speed_hashes.py",
    ],
    "astrid-runtime": ["tests/test_thumbnail_variant_recovery.py", "tests/test_thumbnail_intent_upgrade.py"],
    "VibeComfy": ["tests/test_descriptorless_output_receipts.py"],
}
for repo, paths in sources.items():
    for name in paths:
        files["frozen-source/" + repo + "/" + name] = ROOT / repo / name
assert all(path.is_file() for path in files.values())
archive_path = PROOF / ARCHIVE
inventory = []
with tarfile.open(archive_path, "w:xz", preset=6) as z:
    for name, path in sorted(files.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        z.addfile(info, io.BytesIO(data))
        inventory.append({"path": name, "bytes": len(data), "sha256": digest(data)})
with tarfile.open(archive_path, "r:xz") as z:
    assert z.getnames() == [item["path"] for item in inventory]
    for item in inventory:
        assert digest(z.extractfile(item["path"]).read()) == item["sha256"]

index = {
    "schema_version": 1,
    "packet": "R14-P55-12", "session": "r14-P55-12-1", "row": "Plan55 LS-6 remainder",
    "status": "paired proof complete; submitted pin proposals require Lead integration acceptance",
    "authority": {
        "packet_at_dev": "1eff8700a11aa0986ac0a9cd62d1e63417040701",
        "rework": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6995577860",
        "accepted_proof_boundary": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6996446701",
        "standing_rulings": "Known failures remain executed; dependency-identity guards remain intact.",
    },
    "required_agent_source_merge": {
        "commit": "419fb512a719cf1d1dfe71791e9668bc5089db5a",
        "parents": json.loads((PROOF / "rework-final-scope-audit.json").read_text())["required_source_merge"]["parents"],
        "audit": artifact("rework-final-scope-audit.json"),
    },
    "tested_product_sources": {
        "agent": {"commit": "68c7911e581e85bc70c357806260e88300247ed0", "tree": "d4a50b40528e64b3e11c22746833775a52712132"},
        "runtime": {"commit": "62333bd797e84b21cb3995e4bcf580ed0bdcf9f0", "tree": "b2202d0e885efc6b1fc8cac8e7ad0fc0d5ea1f17"},
        "vibe": {
            "selected_by_agent_pin_commit": "80fda01f579642d035accc4ababb0015586de87c",
            "canonical_pin_path": "astrid/packs/vibecomfy/pins.json",
            "tree": "8f059c72f4385acdf0ace2c04f0ea8d3af643c62",
            "exact_identity_in_archive": "rework-vibe-final-comparison.json and rework-counter-final-comparison.json",
        },
    },
    "separate_pin_proposals": {
        "vibe": "80fda01f579642d035accc4ababb0015586de87c",
        "runtime": "68c7911e581e85bc70c357806260e88300247ed0",
        "approval_status_at_proof": "pending Lead; local paired testing authorized by rework decision",
    },
    "core_focused_tests": core, "core_after_passed": 217,
    "additional_checks": checks,
    "full_path_counters": artifact("rework-counter-final-comparison.json"),
    "counter_observer_audit": artifact("rework-counter-observer-audit.json"),
    "retained_failures": known,
    "hosted_observations": {
        "vibe_ci_and_parity": artifact("rework-vibe-hosted-summary.json"),
        "vibe_strict_ready": artifact("rework-vibe-strict-summary.json"),
        "agent_meter": artifact("rework-agent-hosted-8243-meter-classification.json"),
        "agent_other_packet_workflows": artifact("rework-agent-crosspacket-classification.json"),
        "windows_AT15_recurrence": artifact("rework-windows-AT15-routing.json"),
        "runtime_checkpoint_ci": artifact("rework-runtime-hosted-summary.json"),
        "prior_runs_terminal": artifact("rework-final-prior-run-census.json"),
        "source_boundary": "Hosted observations identify the previous publication heads; they are not full CI qualification of the later corrected product commits.",
        "qualification": "Setup/root-gate/pin-identity failures and skipped targets are NO-RESULT, not green CI or a meter qualification.",
    },
    "scope_preservation": artifact("rework-final-scope-audit.json"),
    "schema_baseline": {
        "approved_commit": "f108349eccafb3e7588d9fa5dbe94d2d6b990015",
        "digest": "sha256:a313b20d28be310e53fe0abe8e2f06a5dde1894a2c4b348fcf0e25ec57dce348",
        "checks": "Equality chain and no-observed_job assertion preserved and passing; TypeScript contract metadata regenerated by the existing generator.",
        "sequencing": "Lead owns ordering with Plan59 #838 at release/14/main.",
    },
    "archive": {"path": str(DEST / ARCHIVE), "bytes": archive_path.stat().st_size,
                "sha256": digest(archive_path.read_bytes()), "members": len(inventory), "inventory": inventory},
    "prior_evidence": {
        "checkpoint_archive": {"path": str(DEST / "observations-rework-checkpoint.zip"), "sha256": "83215cfbd222f8bbe24d76ff4b73ae3b3f7f04b9a6fad8d44a123c83166e8880"},
        "retry_archive": {"path": str(DEST / "observations-retry-scope.zip"), "sha256": "367e42797578d1b6ab616c344f328fefc3b6c0e25928e50fdc591d79d4399eb9"},
        "historical_hold": "Earlier checkpoint/plan wording remains historical; the later proof-boundary ruling and additive after plans supersede it.",
    },
    "limits": [
        "Focused Linux CPU proof; fixed Comfy bytes with real custody, HTTP, settlement and caller delivery. No GPU, latency or full-release qualification.",
        "The counter records Python hash streams; native/subprocess hashing and cached constructor aliases are outside observer coverage.",
        "Original and incoming observer identities are recorded separately; all three harness snapshots are unbounded.",
        "Preserved variants qualify at the service boundary under Lead6996446701; FIX-12 completes the unchanged installed journey on combined heads.",
        "#948 and #926 remain outside packet scope. No tasks.md edit, destination merge, rebase, workflow cancellation or dispatch.",
        "Large original hosted meter ZIPs remain in the workspace; the archive includes decoded diagnostic bytes, inventories, SHA256s and source URLs.",
    ],
}
payload = (json.dumps(index, indent=2, sort_keys=True) + "\n").encode()
pin = json.loads((ROOT / "astrid-agent/astrid/packs/vibecomfy/pins.json").read_text())["sources"]["vibecomfy"]["revision"]
assert pin.encode() not in payload, "Keep the Vibe pin authority in canonical pin manifests"
for repo in REPOS:
    dest = ROOT / repo / DEST
    (dest / ARCHIVE).write_bytes(archive_path.read_bytes())
    (dest / INDEX).write_bytes(payload)
summary = {"archive": {"sha256": index["archive"]["sha256"], "bytes": index["archive"]["bytes"], "members": len(inventory)},
           "index": {"sha256": digest(payload), "bytes": len(payload)}, "core_after_passed": 217}
(PROOF / "rework-final-package-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
