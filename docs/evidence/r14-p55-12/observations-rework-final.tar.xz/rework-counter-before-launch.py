"""Execute only the fresh original-packet BEFORE counter observation."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
PLAN_PATH = PROOF / 'rework-counter-final-plan.json'
PLAN = json.loads(PLAN_PATH.read_text())
BEFORE = PLAN['before']
ROOTS = {name: Path(path) for name, path in BEFORE['roots'].items()}
HARNESS = Path(PLAN['harness']['path'])
LOG = Path(BEFORE['raw_log'])
OUTPUT = PROOF / 'rework-counter-before-1.json'
METADATA = Path(BEFORE['run_metadata'])
FREEZE = PROOF / 'rework-counter-before-1-environment.txt'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return {
        'root': str(path),
        'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=path, text=True).splitlines(),
        'status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=path, text=True).splitlines(),
        'tracked_diff_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=path)).hexdigest(),
    }


assert sha(HARNESS) == PLAN['harness']['sha256']
assert not any(path.exists() for path in (LOG, OUTPUT, METADATA, FREEZE))
identities = {name: identity(path) for name, path in ROOTS.items()}
for name, value in identities.items():
    assert value['revision'][0] == BEFORE['expected_commits'][name]
    assert value['status'] == []
environment = os.environ.copy()
environment.update(BEFORE['environment'])
Path(environment['TMPDIR']).mkdir(exist_ok=False)
with FREEZE.open('x') as stream:
    subprocess.run([sys.executable, '-m', 'pip', 'freeze'], stdout=stream, check=True)
report = {
    'phase': 'fresh original-packet BEFORE observation only',
    'plan': {'path': str(PLAN_PATH), 'sha256': sha(PLAN_PATH)},
    'launcher': {'path': str(Path(__file__)), 'sha256': sha(Path(__file__))},
    'command': BEFORE['command'], 'cwd': BEFORE['cwd'],
    'environment': BEFORE['environment'], 'environment_freeze_sha256': sha(FREEZE),
    'started_utc': datetime.now(timezone.utc).isoformat(),
    'identity_before': identities, 'harness_sha256_before': sha(HARNESS),
    'disk_free_bytes_before': shutil.disk_usage(ROOT).free,
}
with LOG.open('xb') as stream:
    result = subprocess.run(BEFORE['command'], cwd=BEFORE['cwd'], env=environment,
                            stdout=stream, stderr=subprocess.STDOUT)
report.update({
    'exit_code': result.returncode, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'identity_after': {name: identity(path) for name, path in ROOTS.items()},
    'harness_sha256_after': sha(HARNESS), 'disk_free_bytes_after': shutil.disk_usage(ROOT).free,
})
report['code_unchanged_during_run'] = report['identity_before'] == report['identity_after']
report['harness_unchanged_during_run'] = report['harness_sha256_before'] == report['harness_sha256_after']
if OUTPUT.exists():
    observation = json.loads(OUTPUT.read_text())
    report['harness_status'] = observation['status']
    report['harness_code_unchanged'] = observation['code_unchanged']
    report['measurements'] = [{key: row[key] for key in (
        'bytes', 'sha256', 'fetch_count', 'producer', 'runtime_pre_delivery', 'runtime_transmit', 'caller',
        'cas_unchanged_after_caller_mutation', 'independent_caller_file', 'settlement_state',
        'task_status', 'runtime_primary_open_count', 'thumbnail_intent_count',
    )} for row in observation['measurements']]
    report['observer_loaded'] = observation['selected_modules'].get('tests._local_speed_hashes')
    if 'error' in observation:
        report['harness_error'] = observation['error']
report['artifacts'] = {str(path): {'sha256': sha(path), 'bytes': path.stat().st_size}
                       for path in (LOG, OUTPUT, FREEZE) if path.exists()}
with METADATA.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report.get(key) for key in (
    'exit_code', 'harness_status', 'harness_error', 'code_unchanged_during_run',
    'harness_unchanged_during_run', 'measurements', 'observer_loaded',
)}, indent=2))
print('metadata=' + str(METADATA))
print('metadata_sha256=' + sha(METADATA))
if result.returncode:
    print(LOG.read_text()[-10000:])
sys.exit(result.returncode)
