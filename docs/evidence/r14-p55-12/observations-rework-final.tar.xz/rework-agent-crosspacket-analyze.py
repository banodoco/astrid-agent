from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
REPO = ROOT / 'agent-focused41-before'
CURRENT = '8243ef8f97ee2022fba0d95d54deb8a89aa2e5a9'
PRIOR = '419fb512a719cf1d1dfe71791e9668bc5089db5a'
BASE = '493616c1cfc7a83f18894dc81773571e977f26ef'
METER = '19103ea6acbc030b3379e840ccc03491e47f1a0e'
api = json.loads((PROOF / 'rework-agent-crosspacket-api.json').read_text())
ls5_api = json.loads((PROOF / 'rework-agent-crosspacket-ls5-api.json').read_text())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def record(path):
    data = path.read_bytes()
    return {'file': str(path), 'bytes': len(data), 'sha256': sha(data)}


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)


def raw_source(commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=REPO)


def clean_line(line):
    return re.sub(r'\x1b\[[0-9;]*m', '', re.sub(r'^\d{4}-\d\d-\d\dT\S+\s', '', line))


def inspect_log(item):
    path = Path(item['path'])
    lines = path.read_bytes().decode().splitlines()
    clean = [clean_line(line) for line in lines]
    outcomes = []
    for number, line in enumerate(clean, 1):
        match = re.match(r'^(PASSED|FAILED|ERROR|SKIPPED|XFAIL|XPASS) ((?:agent/)?tests/.*?)(?: - (.*))?$', line)
        if match:
            outcomes.append({'line': number, 'outcome': match[1], 'id': match[2], 'detail': match[3]})
    checkouts = []
    for index, line in enumerate(clean):
        if 'log -1 --format=%H' in line and index + 1 < len(clean):
            checkouts.append({'line': index + 2, 'commit': clean[index + 1].strip()})
    summaries = [{'line': index + 1, 'text': line}
                 for index, line in enumerate(clean)
                 if re.match(r'^\d+ (?:passed|failed)(?:,| in )', line)]
    return {**item, **record(path), 'observed_test_outcomes': outcomes,
            'pytest_summary_lines': summaries, 'logged_checkout_commits': checkouts,
            'error_lines': [{'line': index + 1, 'text': line} for index, line in enumerate(clean)
                            if line.startswith('AssertionError:') or '##[error]' in line],
            '_clean_lines': clean}


logs = {item['label']: inspect_log(item)
        for item in api['raw_job_logs'] + ls5_api['raw_job_logs']}
expected_id = 'agent/tests/core/execution/test_fail_closed_g28.py::test_stalled_stage_deadline_publishes_before_stage_returns[settlement]'
for label in ('ls7_current', 'ls7_prior419'):
    outcomes = logs[label]['observed_test_outcomes']
    assert len(outcomes) == 167
    assert sum(row['outcome'] == 'PASSED' for row in outcomes) == 166
    assert [row['id'] for row in outcomes if row['outcome'] == 'FAILED'] == [expected_id]
    assert [row['detail'] for row in outcomes if row['outcome'] == 'FAILED'] == ["AssertionError: assert 'running' == 'failed'"]
    assert logs[label]['logged_checkout_commits'][1]['commit'] == 'ac2d29dce0a12e00fac7e4593623401c11ff0dae'

ls7_same_outcomes = [dict(outcome=row['outcome'], id=row['id'], detail=row['detail'])
                     for row in logs['ls7_current']['observed_test_outcomes']] == [
                     dict(outcome=row['outcome'], id=row['id'], detail=row['detail'])
                     for row in logs['ls7_prior419']['observed_test_outcomes']]
assert ls7_same_outcomes

ls8_comparison = {}
for platform in ('macos', 'ubuntu', 'windows'):
    current, prior = logs[f'ls8_current_{platform}'], logs[f'ls8_prior419_{platform}']
    signature = 'AssertionError: dependency identity differs; this pair is not comparable'
    assert signature in current['_clean_lines'] and signature in prior['_clean_lines']
    assert not current['observed_test_outcomes'] and not prior['observed_test_outcomes']
    ls8_comparison[platform] = {'same_exact_setup_signature': True,
                               'signature': signature, 'collected_test_ids': [],
                               'qualified_result': 'NO-RESULT'}

ls5_records = {}
for label in ('ls5_current', 'ls5_prior419'):
    clean = logs[label]['_clean_lines']
    index = next(i for i, line in enumerate(clean) if '"schema": "astrid.ls5-comparison.v1"' in line)
    end = next(i for i in range(index, len(clean)) if clean[i].strip() == '}')
    report = json.loads('\n'.join(clean[index - 1:end + 1]))
    assert report['status'] == 'NO-RESULT'
    assert report['accepted_meter'] == METER
    ls5_records[label] = {'report': report, 'raw_log_lines': [index, end + 1]}
assert ls5_records['ls5_current']['report'] == ls5_records['ls5_prior419']['report']

source_paths = [
    '.github/workflows/ls7-packet.yml', '.github/workflows/ls8-packet.yml',
    '.github/workflows/plan55-ls5.yml', 'runtime.lock.json',
    'tests/core/execution/test_fail_closed_g28.py',
    'astrid/core/execution/generic_host.py', 'tests/ls5_meter_compare.py',
]
source_capture = {}
for commit in (CURRENT, PRIOR, BASE):
    files = []
    for path in source_paths:
        raw = raw_source(commit, path)
        item = {'path': path, 'bytes': len(raw), 'sha256': sha(raw),
                'source_url': f'https://github.com/banodoco/astrid-agent/blob/{commit}/{path}'}
        if path == 'runtime.lock.json':
            item['source_commit'] = json.loads(raw)['source_commit']
        if path.endswith('.yml') or path == 'tests/ls5_meter_compare.py':
            item['relevant_lines'] = [{'line': i + 1, 'text': line}
                for i, line in enumerate(raw.decode().splitlines())
                if any(word in line for word in (
                    'ref:', 'source_commit', 'assert head == base', 'ASTRID_RUNTIME_CHECKOUT',
                    'PYTHONPATH', 'diff", "--exit-code", METER', 'UNCHANGED_METER', 'accepted_meter'))]
        if (commit == CURRENT and path != 'astrid/core/execution/generic_host.py') or (commit == BASE and path == 'runtime.lock.json'):
            target = PROOF / 'rework-agent-crosspacket-sources' / commit / path
            write_new(target, raw)
            item['raw_source_copy'] = record(target)
        files.append(item)
    source_capture[commit] = files

source_parity = [{'path': current['path'], 'current_vs_prior_identical': current['sha256'] == prior['sha256']}
                 for current, prior in zip(source_capture[CURRENT], source_capture[PRIOR])]
assert all(row['current_vs_prior_identical'] for row in source_parity)
current_pin = next(x['source_commit'] for x in source_capture[CURRENT] if x['path'] == 'runtime.lock.json')
prior_pin = next(x['source_commit'] for x in source_capture[PRIOR] if x['path'] == 'runtime.lock.json')
base_pin = next(x['source_commit'] for x in source_capture[BASE] if x['path'] == 'runtime.lock.json')
assert current_pin == prior_pin == '4323ef03f75334bc38c13d8fcb43b46368774d72'
assert base_pin == 'f3dc970af71e7d413871b4a8e45e4ba0fbfabf5e'

patterns = ['tests/_local_speed*', 'tests/local_speed*',
    'tests/integrations/test_local_speed_meter.py', 'tests/integrations/local_speed_sources.py',
    'tests/integrations/_pinned_source.py', 'tests/integrations/test_runpod_slot_path_cpu.py',
    'tests/integrations/runpod_slot_pod.py', 'tests/conftest.py']
guard_changes = {}
for commit in (CURRENT, PRIOR):
    paths = subprocess.check_output(['git', 'diff', '--name-only', METER, commit, '--', *patterns], cwd=REPO, text=True).splitlines()
    guard_changes[commit] = [{'path': path, 'head_sha256': sha(raw_source(commit, path))} for path in paths]
assert guard_changes[CURRENT] == guard_changes[PRIOR]

run_records = api['run_records'] | ls5_api['run_records']
runs = {}
for label, item in run_records.items():
    run = item['run']
    expected = CURRENT if label.endswith('current') else PRIOR
    assert run['head_sha'] == expected
    runs[label] = {
        'id': run['id'], 'url': run['html_url'], 'head_sha': run['head_sha'],
        'workflow_path': run['path'], 'event': run['event'], 'run_attempt': run['run_attempt'],
        'status': run['status'], 'conclusion': run['conclusion'], 'updated_at': run['updated_at'],
        'jobs': [{key: job.get(key) for key in ('id', 'name', 'status', 'conclusion', 'html_url')}
                 | {'steps': job['steps']} for job in item['jobs']['jobs']],
    }
for item in logs.values():
    item.pop('_clean_lines')

report = {
    'scope': 'Read-only LS7 and LS8 failed-job classification plus newly terminal LS5 held-connection comparison. No local test execution, rerun, dispatch, cancellation, ref update, repository edit or existing-evidence edit.',
    'source_head': CURRENT, 'comparator_head': PRIOR, 'destination_base': BASE,
    'retrieved_at': api['retrieved_at'], 'ls5_retrieved_at': ls5_api['retrieved_at'],
    'run_binding_note': 'Each run is bound by top-level run.head_sha and its raw checkout log. Nested pull_requests objects may reflect a later PR head and are not used as the historical source identity.',
    'runs': runs,
    'ls7': {
        'classification': 'Actual test failure already observed on prior419; not a setup or pin refusal. Its origin is not established by this prior-head comparison.',
        'packet_job': 'success on both heads, as reported by GitHub job metadata',
        'unchanged_regressions': {'passed': 166, 'failed': 1, 'errors': 0, 'skipped': 0},
        'failed_id': expected_id,
        'failure': "AssertionError: assert 'running' == 'failed' at tests/core/execution/test_fail_closed_g28.py:213",
        'same_all_167_ids_outcomes_and_order': ls7_same_outcomes,
        'actual_workflow_runtime_checkout': 'ac2d29dce0a12e00fac7e4593623401c11ff0dae',
        'declared_agent_runtime_pin': current_pin,
        'runtime_source_note': 'The LS7 workflow hardcodesac2d29 and prepends its Runtime/packages/python to PYTHONPATH on both heads. This evidence is not relabeled as a run of the Agent declared4323 tuple.',
    },
    'ls8': {
        'classification': 'Explicit dependency-identity guard refusal during setup on all three platforms; test/proof stages not reached.',
        'failed_step': {'number': 5, 'name': 'Install and record exact inputs'},
        'current_and_prior_runtime_pin': current_pin, 'base_runtime_pin': base_pin,
        'qualified_result': 'NO-RESULT', 'platform_comparison': ls8_comparison,
        'skipped_workflow_steps': [
            'Execute unchanged base regressions, including inherited failures',
            'Execute unchanged candidate regressions, including inherited failures',
            'Execute resident pack lifecycle proof'],
        'skip_note': 'These are GitHub workflow steps skipped after setup failure. No test or gate was skipped or changed by this analysis.',
    },
    'ls5': {
        'classification': 'Accepted-meter source-byte identity guard refusal before comparison acquisition; not the LS8 Runtime-pin mismatch.',
        'failed_step': {'number': 18, 'name': 'Acquire the same-pin LS-5 comparison with the unchanged LS-2 meter'},
        'qualified_result': 'NO-RESULT', 'exact_current_and_prior_comparison_reports_equal': True,
        'comparison_reports': ls5_records,
        'windows_websocket_job': 'success on both heads, as reported by GitHub job metadata',
        'guard_changed_files': guard_changes,
        'same_20_guarded_changed_paths_and_current_bytes': True,
        'note': 'Earlier execution steps retain their raw results. Their success does not make the refused LS5 comparison green.',
    },
    'new_failure_assessment': 'No new distinct failure signature relative to419 was observed. LS7 remains an actual unresolved failed test; LS8 and LS5 remain explicit NO-RESULT setup/source guard refusals. This is not proof that original prescribed bases are failure-free or that all candidate product behavior passes.',
    'source_parity_current_vs_prior': source_parity, 'source_capture': source_capture,
    'raw_logs_with_exact_outcomes': logs,
    'api_snapshots': [record(PROOF / 'rework-agent-crosspacket-api.json'), record(PROOF / 'rework-agent-crosspacket-ls5-api.json')],
    'no_product_or_test_mutations': True,
}
destination = PROOF / 'rework-agent-crosspacket-classification.json'
write_new(destination, (json.dumps(report, indent=2) + '\n').encode())
print(json.dumps({'classification': record(destination), 'ls7_same_167_outcomes': ls7_same_outcomes,
                  'ls8_setup_results': ls8_comparison, 'ls5_guard_changed_path_count': len(guard_changes[CURRENT]),
                  'raw_logs': len(logs), 'source_parity': source_parity}, indent=2))
