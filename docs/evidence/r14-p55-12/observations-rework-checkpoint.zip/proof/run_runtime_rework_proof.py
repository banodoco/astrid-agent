"""Capture source-bound Runtime proof without changing tests or product."""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/8c30ce2383b9')
REPO = ROOT / 'astrid-runtime'
STEM = ROOT / 'proof' / sys.argv[1]
SELECTORS = sys.argv[2:]
SOURCE_FILES = [
    'runtime_protocol/store.py', 'runtime_protocol/thumbnail_intents.py',
    'runtime_protocol/service.py', 'tests/test_thumbnail_variant_recovery.py',
    'tests/test_thumbnail_intent_upgrade.py',
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def identity():
    return {
        'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
        'status': git('status', '--short'),
        'source_sha256': {name: sha(REPO / name) for name in SOURCE_FILES},
        'existing_test_diff': git('diff', 'HEAD', '--', 'tests'),
    }


source = (REPO / 'runtime_protocol/store.py').read_bytes()
guard_node = next(
    item for item in ast.walk(ast.parse(source))
    if isinstance(item, ast.FunctionDef) and item.name == '_associate_managed_outputs'
)
guard = b''.join(source.splitlines(keepends=True)[guard_node.lineno - 1:guard_node.end_lineno])
guard_path = Path(str(STEM) + '-association-guard.py')
with guard_path.open('xb') as output:
    output.write(guard)
command = [
    str(ROOT / 'test-env/bin/python'), '-m', 'pytest', '-q', '-rA', *SELECTORS,
    '--basetemp=' + str(STEM) + '-tmp', '--junitxml=' + str(STEM) + '.xml',
]
environment = os.environ.copy()
environment['PYTHONPATH'] = '.:packages/python:tests'
metadata = {
    'cwd': str(REPO), 'command_argv': command,
    'environment_overrides': {'PYTHONPATH': environment['PYTHONPATH']},
    'before': identity(), 'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
    'guard': {'path': str(guard_path), 'sha256': hashlib.sha256(guard).hexdigest(), 'bytes': len(guard)},
}
with Path(str(STEM) + '.before.json').open('x') as output:
    json.dump(metadata, output, indent=2)
    output.write('\n')
started = time.monotonic()
with Path(str(STEM) + '.log').open('x') as log:
    result = subprocess.run(command, cwd=REPO, env=environment, stdout=log, stderr=subprocess.STDOUT)
metadata.update(
    exit_code=result.returncode, elapsed_seconds=time.monotonic() - started, after=identity(),
    finished_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
)
xml = Path(str(STEM) + '.xml')
if xml.exists():
    cases = []
    for item in ET.parse(xml).iter('testcase'):
        failure, error, skipped = item.find('failure'), item.find('error'), item.find('skipped')
        status = 'failure' if failure is not None else 'error' if error is not None else 'skipped' if skipped is not None else 'passed'
        diagnostic = failure if failure is not None else error if error is not None else skipped
        cases.append({
            'classname': item.get('classname'), 'name': item.get('name'), 'status': status,
            'message': diagnostic.get('message') if diagnostic is not None else None,
        })
    metadata['cases'] = cases
    metadata['counts'] = {name: sum(case['status'] == name for case in cases) for name in ['passed', 'failure', 'error', 'skipped']}
metadata['source_stable'] = metadata['before']['source_sha256'] == metadata['after']['source_sha256']
with Path(str(STEM) + '.json').open('x') as output:
    json.dump(metadata, output, indent=2)
    output.write('\n')
print(json.dumps({
    'artifact': str(STEM) + '.json', 'exit_code': result.returncode,
    'counts': metadata.get('counts'), 'cases': metadata.get('cases'),
    'source_stable': metadata['source_stable'], 'guard': metadata['guard'],
}, indent=2))
