    def _associate_managed_outputs(
        self,
        result,
        *,
        task_id,
        attempt_id,
        project_id,
        applied_effect=None,
        created_at=None,
    ):
        """Persist immutable output identity and initial Runtime lifecycle atomically."""
        timestamp = created_at or now()
        manifest_digest = self._validated_manifest_digest(result, project_id=project_id)
        if manifest_digest is None:
            manifest_output = next(
                (output for output in result.get("outputs", [])
                 if isinstance(output, dict) and output.get("role") == "manifest"),
                None,
            )
            if manifest_output is not None:
                manifest_digest = str(manifest_output["digest"]).removeprefix("sha256:")
        associations = []
        publish_overrides = {}
        if isinstance(applied_effect, dict) and applied_effect.get("effect_type") == "generation.publish_v1":
            publish_overrides = applied_effect.get("_association_overrides") or {}
        for output in result.get("outputs", []):
            if not isinstance(output, dict) or output.get("kind") != "object":
                continue
            digest = str(output["digest"]).removeprefix("sha256:")
            output_port = output.get("output_port", output.get("name", "output"))
            group_key = output.get("group_key", "default")
            variant_key = output.get("variant_key", str(output.get("ordinal", 0)))
            ordinal = int(output.get("ordinal", 0))
            publish_key = (output_port, group_key, variant_key, ordinal)
            if isinstance(applied_effect, dict) and applied_effect.get("effect_type") == "generation.publish_v1":
                publish_override = publish_overrides.get(publish_key) or {}
                generation_id = publish_override.get("generation_id")
            elif isinstance(applied_effect, dict):
                publish_override = {}
                generation_id = applied_effect.get("generation_id")
            else:
                # Producer-supplied generation IDs are never authoritative;
                # generic managed outputs stay outside the generation domain.
                publish_override = {}
                generation_id = None
            role = output.get("role") or "output"
            durability = output.get("durability", "durable")
            producer = dict(output.get("producer") or {})
            provenance = dict(output.get("provenance") or {})
            if publish_override.get("selector") is not None:
                # The managed association schema already has an extensible
                # provenance object; retain GEN's selector label there rather
                # than adding a second association column.
                provenance["selector"] = publish_override["selector"]
            task_row = self.conn.execute("SELECT capability FROM tasks WHERE id=?", (str(task_id),)).fetchone()
            attempt_row = self.conn.execute(
                "SELECT executor_id, fence, runtime_epoch FROM attempts WHERE id=?",
                (str(attempt_id),),
            ).fetchone()
            if task_row:
                producer.setdefault("capability_id", task_row["capability"])
            # These fields are Runtime-owned custody facts.  A child may
            # report observations, but it cannot forge the task/attempt that
            # owns the committed association.
            provenance["task_id"] = str(task_id)
            provenance["attempt_id"] = str(attempt_id)
            if task_row:
                provenance["capability_id"] = task_row["capability"]
            if attempt_row:
                provenance["executor_id"] = attempt_row["executor_id"]
                provenance["fence"] = int(attempt_row["fence"])
                provenance["runtime_epoch"] = int(attempt_row["runtime_epoch"])
            else:
                provenance["runtime_epoch"] = self._current_runtime_epoch()
            identity = {
                "task_id": str(task_id), "output_port": output_port,
                "group_key": group_key, "generation_id": generation_id,
                "variant_key": variant_key, "ordinal": ordinal,
            }
            association_id = "managed-output-" + hashlib.sha256(
                canonical_json(identity).encode()
            ).hexdigest()
            immutable = {
                "task_id": str(task_id),
                "attempt_id": str(attempt_id),
                "project_id": project_id,
                "output_port": output_port,
                "group_key": group_key,
                "generation_id": generation_id,
                "variant_key": variant_key,
                "object_digest": digest,
                "manifest_digest": manifest_digest,
                "size": int(output["size"]),
                "filename": output.get("filename", output.get("name", "output")),
                "media_type": output.get("media_type", "application/octet-stream"),
                "ordinal": ordinal,
                "role": role,
                "producer_json": canonical_json(producer),
                "provenance_json": canonical_json(provenance),
                "durability": durability,
                "regeneration_json": canonical_json(output["regeneration"]) if output.get("regeneration") is not None else None,
                "coverage_json": canonical_json(output["coverage"]) if output.get("coverage") is not None else None,
            }
            output_identity = (
                immutable["task_id"], immutable["output_port"], immutable["group_key"],
                immutable["ordinal"], immutable["variant_key"],
            )
            existing = self.conn.execute(
                "SELECT * FROM managed_output_associations "
                "WHERE task_id=? AND output_port=? AND group_key=? AND ordinal=? AND variant_key=?",
                output_identity,
            ).fetchone()
            if existing is None:
                self.conn.execute(
                    "INSERT OR IGNORE INTO managed_output_associations("
                    "association_id, task_id, attempt_id, project_id, output_port, group_key, "
                    "generation_id, variant_key, object_digest, manifest_digest, size, filename, "
                    "media_type, ordinal, role, producer_json, provenance_json, durability, "
                    "regeneration_json, coverage_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        association_id, immutable["task_id"], immutable["attempt_id"], immutable["project_id"],
                        immutable["output_port"], immutable["group_key"], immutable["generation_id"],
                        immutable["variant_key"], immutable["object_digest"], immutable["manifest_digest"],
                        immutable["size"], immutable["filename"], immutable["media_type"], immutable["ordinal"],
                        immutable["role"], immutable["producer_json"], immutable["provenance_json"],
                        immutable["durability"], immutable["regeneration_json"], immutable["coverage_json"], timestamp,
                    ),
                )
                existing = self.conn.execute(
                    "SELECT * FROM managed_output_associations "
                    "WHERE task_id=? AND output_port=? AND group_key=? AND ordinal=? AND variant_key=?",
                    output_identity,
                ).fetchone()
            if existing is None:
                raise ConflictError("managed output association was not recorded")
            changed = [field for field, value in immutable.items() if existing[field] != value]
            if changed:
                raise ConflictError(
                    "managed output association conflicts with existing immutable output",
                    details={"association_id": existing["association_id"], "fields": changed},
                )
            association_id = existing["association_id"]
            lifecycle_state = "temporary" if durability == "temporary" else "available"
            self.conn.execute(
                "INSERT OR IGNORE INTO managed_output_lifecycle(association_id, state, version, expires_at, pinned_at, lease_id, lease_owner, lease_expires_at, updated_at, created_at) VALUES (?, ?, 1, NULL, NULL, NULL, NULL, NULL, ?, ?)",
                (association_id, lifecycle_state, timestamp, timestamp),
            )
            row = self.conn.execute(
                self._managed_output_select() +
                "WHERE a.association_id=?",
                (association_id,),
            ).fetchone()
            associations.append(self._managed_output_value(row))
        return associations
