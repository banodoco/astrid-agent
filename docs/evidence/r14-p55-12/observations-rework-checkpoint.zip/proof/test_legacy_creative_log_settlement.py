"""Diagnostic: ordinary durable logs must not become extra creative outputs."""
from __future__ import annotations

import pytest

from test_generation_thumbnail_settlement import (
    _create_effect, _output, _seed_generation, _service, _settle, _task,
)


@pytest.mark.parametrize("effect_kind", ["create_with_variant", "variant.append"])
def test_legacy_creative_effect_accepts_canonical_durable_logs(tmp_path, effect_kind):
    service, project = _service(tmp_path, "legacy-log-probe")
    try:
        if effect_kind == "create_with_variant":
            source = service.ingest(project["id"], b"admitted source", media_type="image/png",
                idempotency_key="input")["data"]["digest"]
            effect = _create_effect(project["id"])
        else:
            seeded = _seed_generation(service, project, key="seed", with_thumbnail=False)
            source = seeded["source_object_id"]
            effect = {
                "effect_type": "generation.variant.append", "target_id": seeded["generation_id"],
                "expected_version": 1, "payload": {
                    "source_variant_id": seeded["variant_id"], "source_object_id": source,
                    "variant_type": "edit", "output_name": "video", "output_ordinal": 0,
                    "primary_policy": "preserve",
                },
            }
        task, attempt = _task(service, project["id"], effect, key="with-logs", inputs=[source])
        outputs = [_output(b"generated video", name="video", media_type="video/mp4", ordinal=0)]
        for name in ("job.stdout", "job.stderr"):
            log = _output(b"", name=name, media_type="text/plain", output_port="logs",
                group_key="default", variant_key=name, ordinal=0, role="log")
            log.update(filename=name + ".log", durability="durable")
            outputs.append(log)
        settled = _settle(service, attempt, effect, outputs, key="with-logs-settle")
        assert settled["data"]["task_id"] == task["task"]["id"]
        associations = service.managed_outputs(task["task"]["id"])
        assert len(associations) == 3
        assert {row["name"] for row in associations if row["role"] == "log"} == {
            "job.stdout", "job.stderr",
        }
    finally:
        service.close()
