"""Freeze LS-6 rework diagnostics and completed changes while Lead rules on a blocker."""
from __future__ import annotations
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
PROOF = ROOT / "proof"
HEADS = {
    "astrid-agent": "419fb512a719cf1d1dfe71791e9668bc5089db5a",
    "astrid-runtime": "a09a38ef9125c82a3c8ecacc0b8cee9c63ede279",
    "VibeComfy": "6a40663382dbefeaf482313a42765a123786c65c",
}
PRODUCT = {
    "astrid-agent": ["config/astrid-beta-capabilities.json", "astrid/resources/astrid-beta-capabilities.json"],
    "astrid-runtime": ["generators/python_client_template.py", "packages/python/astrid_runtime_client/generated.py", "contract/artifacts.json"],
    "VibeComfy": ["vibecomfy/runtime/output_receipts.py", "vibecomfy/runtime/session.py"],
}
NEW_TESTS = {
    "astrid-agent": ["tests/core/execution/test_ls6_image_thumbnail_readiness.py", "tests/core/generation/test_ls6_export_permissions.py"],
    "astrid-runtime": ["tests/test_thumbnail_variant_recovery.py", "tests/test_thumbnail_intent_upgrade.py"],
    "VibeComfy": ["tests/test_descriptorless_output_receipts.py"],
}
BLOCKED_TEST = "tests/core/execution/test_ls6_variant_thumbnail_recovery.py"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(repo, *args):
    return subprocess.check_output(["git", "-C", str(ROOT / repo), *args])


def function_bytes(raw, name):
    text = raw.decode()
    node, = [node for node in ast.walk(ast.parse(text)) if isinstance(node, ast.FunctionDef) and node.name == name]
    return "".join(text.splitlines(keepends=True)[node.lineno - 1:node.end_lineno]).encode()


audit = {"heads_before_checkpoint": HEADS, "changes": {}, "new_tests": {}, "preservation": {}}
for repo, head in HEADS.items():
    assert git(repo, "rev-parse", "HEAD").decode().strip() == head
    changed = git(repo, "diff", "--name-only", "HEAD").decode().splitlines()
    assert sorted(changed) == sorted(PRODUCT[repo]), (repo, changed)
    assert not git(repo, "diff", "HEAD", "--", "tests")
    assert not git(repo, "diff", "HEAD", "--", ".github", "tasks.md")
    audit["changes"][repo] = {name: digest((ROOT / repo / name).read_bytes()) for name in PRODUCT[repo]}
    audit["new_tests"][repo] = {name: digest((ROOT / repo / name).read_bytes()) for name in NEW_TESTS[repo]}
    (PROOF / f"rework-checkpoint-{repo}-product.patch").write_bytes(git(repo, "diff", "HEAD", "--", *PRODUCT[repo]))

store = (ROOT / "astrid-runtime/runtime_protocol/store.py").read_bytes()
guard = function_bytes(store, "_associate_managed_outputs")
assert len(guard) == 8798 and digest(guard) == "6a155b6817f74ae7540f8975c2dcf00358e13a544fb0da3e8a22151d3af25f2f"
recovery = (ROOT / "astrid-agent/tests/core/execution/test_ls6_thumbnail_recovery.py").read_bytes()
assert digest(recovery) == "25cbc33f4e0527279f6e1598df9b8d4873ecb4f43f98e53b907b33c69d9514ac"
assert not git("astrid-runtime", "diff", "HEAD", "--", "contract/openapi.yaml", "contract/schemas", "runtime_protocol/contract_metadata.py", "packages/typescript/src/contract-metadata.ts")
assert not git("astrid-agent", "diff", "HEAD", "--", "runtime.lock.json", "astrid/resources/runtime.lock.json", "astrid/packs/vibecomfy/pins.json", "astrid/packs/runpod/pins.json")
audit["preservation"] = {"existing_tests_unchanged": True, "pins_unchanged": True,
    "immutable_guard_bytes": len(guard), "immutable_guard_sha256": digest(guard),
    "protected_recovery_file_sha256": digest(recovery),
    "runtime_store_service_intents_unchanged": not bool(git("astrid-runtime", "diff", "HEAD", "--", "runtime_protocol/store.py", "runtime_protocol/service.py", "runtime_protocol/thumbnail_intents.py")),
    "schema_digest": "sha256:a313b20d28be310e53fe0abe8e2f06a5dde1894a2c4b348fcf0e25ec57dce348",
    "schema_inputs_and_generated_metadata_unchanged": True}
audit["unshipped_blocker_probe"] = {"path": BLOCKED_TEST,
    "sha256": digest((ROOT / "astrid-agent" / BLOCKED_TEST).read_bytes()),
    "disposition": "Frozen new diagnostic, executed and failed; exact source retained in archive and local worktree. Pre-existing general defect is outside the authorized five repairs pending Lead disposition; no existing test is removed or deselected."}

topic = "c98d836520b61a99de22025480521a0c4d9e75db"
target = "493616c1cfc7a83f18894dc81773571e977f26ef"
merged = HEADS["astrid-agent"]
base = git("astrid-agent", "merge-base", topic, target).decode().strip()
incoming = git("astrid-agent", "diff", "--name-only", base, target).decode().splitlines()
packet = git("astrid-agent", "diff", "--name-only", base, topic).decode().splitlines()
assert not set(incoming) & set(packet)
for reference, paths in ((target, incoming), (topic, packet)):
    for path in paths:
        assert git("astrid-agent", "ls-tree", merged, "--", path) == git("astrid-agent", "ls-tree", reference, "--", path)
parents = git("astrid-agent", "show", "-s", "--format=%P", merged).decode().strip().split()
assert parents == [topic, target]
audit["agent_plan55_merge"] = {"commit": merged, "parents": parents, "merge_base": base,
    "incoming_paths": incoming, "preserved_packet_paths": packet,
    "incoming_count": len(incoming), "packet_count": len(packet), "all_blobs_and_modes_match": True,
    "status_url": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6996055993",
    "run_preservation_limit": "The pre-merge raw concurrency snapshot was lost during workspace reset; the posted STATUS records the original completed check. Fresh precheckpoint workflow snapshot is archived separately."}
(PROOF / "rework-checkpoint-scope-audit.json").write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")

files = {"proof/" + p.name: p.read_bytes() for p in PROOF.iterdir() if p.is_file() and (p.name.startswith("rework-") or p.name in {"run_focused.py", "run_runtime_rework_proof.py", "test_legacy_creative_log_settlement.py", "build_rework_checkpoint.py"})}
for p in sorted((PROOF / "rework-legacy-logs-comparison").iterdir()):
    files["proof/rework-legacy-logs-comparison/" + p.name] = p.read_bytes()
for repo, names in NEW_TESTS.items():
    for name in names:
        files[f"sources/{repo}/{name}"] = (ROOT / repo / name).read_bytes()
files[f"sources/astrid-agent/{BLOCKED_TEST}"] = (ROOT / "astrid-agent" / BLOCKED_TEST).read_bytes()
files["tools/astrid-dev-1eff8700-baseline-diff.py"] = (ROOT / "astrid-dev/env/baseline-diff.py").read_bytes()
for name, raw in files.items():
    assert not re.search(rb"Bearer [A-Za-z0-9._-]{16,}|(?<![A-Za-z0-9])sk-[A-Za-z0-9]{20,}", raw), name
archive = PROOF / "observations-rework-checkpoint.zip"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, raw in sorted(files.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 19, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, raw)
index = {
    "packet": "R14-P55-12", "row": "LS-6 remainder", "session": "r14-P55-12-1",
    "status": "BLOCKED; WIP checkpoint, not a final rework submission or green qualification",
    "authority": {"source_sync": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6995484295",
        "review": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6995577860",
        "source_sync_status": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6996055993",
        "new_blocker": "https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6996311467"},
    "source_heads_before_checkpoint": HEADS,
    "completed_repairs": {"item3": "4 expected receipt failures +1 refusal pass before; 17 focused passes after, including same frozen5 new cases",
        "item4": "Installed image main and preview with ffmpeg absent: same final new test fails readiness before and passes after; video missing-decoder refusal retained",
        "item5": "Public managed export before:022/027 incorrect0600 and077 correct0600. Diagnostic generated-SDK after:0644/0640/0600; 31 D14+4 generator checks pass. Agent old pin is unchanged; final vendored-pin proof pending"},
    "unfinished": {"items1_2": "7 reproduced relevant failures +1 authority guard pass; Runtime store/service/intent product unchanged; variant-bound private-context design paused",
        "variant_design": "Derive exact variant from Runtime-produced generation_variant result or publish publication group/port/ordinal/variant key, never digest alone. Persist one intent per visual variant/source. Revalidate stored parent intent and immutable source association, then insert a private Runtime-owned outer task binding through internal service/store parameters; caller spec cannot opt in. Both fenced validation stages resolve that trusted binding. Native attach writes variant thumbnail columns and mirrors generation metadata only while that variant is primary, without consuming creative version. Explicit legacy attachment retains version1-to2 semantics. Previous intent shapes can resolve the exact settled selector without changing their IDs. No schema or migration planned.",
        "pins": "Both replacement Agent pins still require isolated proposal commits and Lead acceptance after Runtime/Vibe repairs are complete",
        "final_proof": "Exact-pin paired caller/variant/recovery/receipt verification and resubmission remain open"},
    "checkpoint_verification": {"protected_recovery": "Both existing recovery tests pass unchanged on current Agent correction with its unchanged declared Runtime pin; 2pass, no skip/error", "vibe_pin": "14 existing pin tests pass on unchanged declared pin before new evidence is staged; no pin approval or replacement claimed"},
    "blocker": {"kind": "Pre-existing first-settlement422 from canonical durable logs in legacy create_with_variant/variant.append",
        "installed_case": "rework-agent-variants-before-1: ordinary real host refused before preview recovery; source unchanged and archived",
        "paired_diagnostic": "Exact same two tests fail on Runtime f3dc970a and a09a38ef at identical validator checks; pinned comparator2preexisting,0regression,0missing,0no-baseline; complete source-function hashes match",
        "disposition": "Stopped and reported, no validator or failing-test workaround; distinct from retry409 in #926"},
    "preservation": audit["preservation"],
    "limits": ["CPU focused diagnostics only; no GPU, full-suite or latency qualification", "Old188-case proof and oldcounter observers remain bound to their original sources", "#948 and #926 are outside this packet", "Schema landing at release/14/main remains sequenced by Lead with Plan59 #838", "Known new failures are visible; no existing assertion, skip, guard, workflow or tasks file changed"],
    "archive": {"file": archive.name, "bytes": archive.stat().st_size, "sha256": digest(archive.read_bytes()),
        "members": {name: {"bytes": len(raw), "sha256": digest(raw)} for name, raw in sorted(files.items())}},
}
index_bytes = (json.dumps(index, indent=2, sort_keys=True) + "\n").encode()
for repo in HEADS:
    destination = ROOT / repo / "docs/evidence/r14-p55-12"
    destination.mkdir(parents=True, exist_ok=True)
    (destination / "rework-checkpoint.json").write_bytes(index_bytes)
    (destination / archive.name).write_bytes(archive.read_bytes())
print(json.dumps({"archive_sha256": index["archive"]["sha256"], "archive_bytes": archive.stat().st_size,
    "members": len(files), "index_bytes": len(index_bytes), "index_sha256": digest(index_bytes)}, sort_keys=True))
