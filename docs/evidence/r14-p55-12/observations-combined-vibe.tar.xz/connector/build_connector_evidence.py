"""Bind final proof to actual GitHub-created commits, preserving local history."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/31d84c8ecea8')
PRIOR = Path('/workspace/scratch/8c30ce2383b9')
PROOF = ROOT / 'proof'
AGENT = ROOT / 'agent-connector-proof'


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cases(path):
    result = []
    for case in ET.parse(path).getroot().iter('testcase'):
        problem = next((item for item in case if item.tag in {'failure', 'error', 'skipped'}), None)
        result.append({
            'raw_junit_id': case.attrib.get('classname', '') + '::' + case.attrib.get('name', ''),
            'name': case.attrib.get('name', ''),
            'status': problem.tag if problem is not None else 'passed',
            'message': problem.attrib.get('message') if problem is not None else None,
            'text': problem.text if problem is not None else None,
        })
    return result


failure_comparison = {}
for label, prior, issue, http in (
    ('connector-installed958-1', 'rework-installed-variants-68', 958, 422),
    ('connector-retry926-1', 'rework-general-log-retry-68', 926, 409),
):
    current = cases(PRIOR / 'proof' / (label + '.xml'))
    before = cases(PRIOR / 'proof' / (prior + '.xml'))
    run = read(PRIOR / 'proof' / (label + '.json'))
    assert run['exit_code'] == 1 and run['inputs_unchanged']
    assert [(x['name'], x['status'], x['message']) for x in current] == [(x['name'], x['status'], x['message']) for x in before]
    assert all(x['status'] == 'failure' and ('HTTP Error ' + str(http)) in x['text'] for x in current)
    failure_comparison[label] = {'issue': issue, 'raw_exit_code': 1, 'current': current, 'previous': before, 'same_case_names_status_and_exact_error': True}
failure_comparison['service958'] = {
    'observation': 'replacement-service958-1',
    'source': '62333bd797e84b21cb3995e4bcf580ed0bdcf9f0',
    'status': 'The separately executed two-case failure remains exact-source evidence: Runtime did not change during connector publication.',
    'comparison': read(PROOF / 'retained-failure-comparison.json')['replacement-service958-1'],
}
(PROOF / 'connector-retained-failure-comparison.json').write_text(json.dumps(failure_comparison, indent=2) + '\n')

pin = read(PROOF / 'connector-pin-commit.json')
counter = read(PROOF / 'connector-counter-1-run.json')
assert counter['status'] == 'passed_tested_pin_proposal' and counter['strict_checks_passed']
assert pin['head'] == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=AGENT, text=True).strip()

inputs = {}
for path in sorted(PROOF.glob('connector-*')):
    if path.is_file() and path.suffix in {'.py', '.json', '.xml', '.log', '.txt'} and not path.name.startswith('connector-package'):
        inputs['connector/' + path.name] = path
inputs['connector/build_connector_evidence.py'] = Path(__file__)
for prefix in ('connector-agent41-1', 'connector-vibe17-1', 'connector-pin14-1', 'connector-installed958-1', 'connector-retry926-1'):
    for path in sorted((PRIOR / 'proof').glob(prefix + '.*')):
        if path.is_file():
            inputs['current-runs/' + path.name] = path
inputs['launchers/run_focused.py'] = PRIOR / 'proof/run_focused.py'
inputs['intermediate-local/observations-combined-vibe.tar.xz'] = PROOF / 'observations-combined-vibe.tar.xz'
inputs['intermediate-local/failed-git-publication.json'] = PROOF / 'publication-readback.json'
inputs['unchanged-runtime/runtime159-carry-forward.json'] = PROOF / 'runtime159-carry-forward.json'
inputs['unchanged-guards/protection-audit.json'] = PROOF / 'protection-audit.json'

archive = PROOF / 'observations-connector-combined-vibe.tar.xz'
assert not archive.exists()
inventory = []
with tarfile.open(archive, 'w:xz') as bundle:
    for name, path in sorted(inputs.items()):
        data = path.read_bytes()
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        bundle.addfile(info, io.BytesIO(data))
        inventory.append({'path': name, 'bytes': len(data), 'sha256': sha(path)})

index = read(PRIOR / 'astrid-agent/docs/evidence/r14-p55-12/combined-vibe.json')
index['source_identity']['agent_tested_product'] = pin['head']
index['source_identity']['vibe_merge_tested_source'] = '158d6f144bb59407c8162edd4f0364f4434ba387'
index['source_identity']['vibe_merge_parents'] = ['8fd40d3314e5d460d1d9ae238db48338ce667fc1', 'a56a19b107ba819f7994b48b9b7e9983fa819903']
index['source_identity']['vibe_final_child'] = 'The frozen evidence-only child of the actual connector merge is both the current Agent canonical Vibe pin and Vibe PR head. Exact SHA/tree are in connector/connector-vibe-final.json.'
index['source_identity']['final_agent_child'] = 'Only this evidence and the final pin-copy observation follow the directly tested connector Agent pin commit.'
index['separate_pin_proposals']['vibe'] = pin['head']
index['focused_results']['staged_pin_copy_check'] = 'Pending final connector evidence staging check; raw result will be adjacent.'
index.pop('staged_pin_copy_observation', None)
index['counter_results'].update({
    'harness_sha256': counter['harness_sha256_after'],
    'observer_sha256': counter['observer_sha256_after'],
    'source_stable': counter['code_unchanged_during_run'],
    'strict_checks_passed': counter['strict_checks_passed'],
    'measurements': counter['measurements'],
})
index['retained_failures']['958'] = 'Unchanged installed journey reran on the actual connector Agent pin and final Vibe head: first create settlement HTTP422. Both service cases separately failed unchanged on exact Runtime623, which is still the final Runtime product. FIX-12 owns completion.'
index['retained_failures']['926'] = 'Unchanged ordinary durable-log owner retry reran on the actual connector Agent pin and final Vibe head: HTTP409 at the preserved immutable association guard. FIX-12 owns repair.'
index['publication_transport'] = {
    'blocked_status': 'https://github.com/banodoco/astrid-dev/issues/796#issuecomment-6997973244',
    'failure': 'CLI git push lacked Username credentials; it changed no remote ref.',
    'resolution': 'Authenticated GitHub Git-object API. Every returned blob/tree matched the staged local object. Actual commits were fetched and their tree/parent identities verified; fresh Vibe17, Agent41, pin14 and counters ran on the returned commits.',
    'history': 'Existing published parent chains preserved; true two-parent Vibe merge includes a56. No rebase, amend, force update, destination merge or deletion. Unpublished local proposal commits remain in local history and are not final PR identities.',
    'intermediate_evidence': 'The intermediate local proof/archive is retained inside this archive. The earlier local commit IDs in BLOCKED6997973244 are superseded by the actual connector identities named here and in the final STATUS.',
    'ref_updates': 'Only p55/ls-6-remainder in the three authorized repositories, with force=false and expected_sha guards.',
}
index['archive'] = {'path': 'docs/evidence/r14-p55-12/observations-combined-vibe.tar.xz', 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'members': len(inventory), 'inventory': inventory}
index['integration']['proof_home'] = 'Final combined proof is in Agent410; Runtime68 and Vibe176 link it in their PR submission. Original370-member rework archive remains identical in all three repositories.'
encoded = json.dumps(index, indent=2) + '\n'
assert pin['selected_vibe'] not in encoded
dest = AGENT / 'docs/evidence/r14-p55-12'
assert not (dest / 'observations-combined-vibe.tar.xz').exists()
(dest / 'observations-combined-vibe.tar.xz').write_bytes(archive.read_bytes())
(dest / 'combined-vibe.json').write_text(encoded)

with tarfile.open(archive, 'r:xz') as bundle:
    assert len(bundle.getmembers()) == len(inventory)
    for member, entry in zip(bundle.getmembers(), inventory):
        assert member.name == entry['path']
        data = bundle.extractfile(member).read()
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256']

summary = {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'members': len(inventory), 'current_agent_source': pin['head'], 'proof_home': 'Agent410'}
(PROOF / 'connector-package-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
