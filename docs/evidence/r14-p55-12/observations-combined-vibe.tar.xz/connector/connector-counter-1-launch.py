"""Run the frozen counter harness once against the tested pin proposal."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/31d84c8ecea8')
PROOF = ROOT / 'proof'
PLAN_PATH = PROOF / 'connector-counter-1-plan.json'
PLAN = json.loads(PLAN_PATH.read_text())
ROOTS = {name: Path(path) for name, path in PLAN['roots'].items()}
HARNESS = Path(PLAN['harness']['path'])
LOG = Path(PLAN['raw_log'])
OUTPUT = PROOF / 'connector-counter-1.json'
METADATA = Path(PLAN['run_metadata'])
FREEZE = PROOF / 'connector-counter-1-environment.txt'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def identity(path):
    return {
        'root': str(path),
        'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD', 'HEAD^{tree}'], cwd=path, text=True).splitlines(),
        'status': subprocess.check_output(['git', 'status', '--porcelain'], cwd=path, text=True).splitlines(),
        'tracked_diff_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff', '--binary', 'HEAD'], cwd=path)).hexdigest(),
    }


assert sha(HARNESS) == PLAN['harness']['sha256']
assert sha(Path(PLAN['observer']['path'])) == PLAN['observer']['sha256']
assert not any(path.exists() for path in (LOG, OUTPUT, METADATA, FREEZE))
identities = {name: identity(path) for name, path in ROOTS.items()}
for name, value in identities.items():
    assert value['revision'][0] == PLAN['expected_commits'][name]
    assert value['status'] == []
environment = os.environ.copy()
environment.update(PLAN['environment'])
Path(environment['TMPDIR']).mkdir(exist_ok=False)
with FREEZE.open('x') as stream:
    subprocess.run([sys.executable, '-m', 'pip', 'freeze'], stdout=stream, check=True)
report = {
    'phase': 'fresh AFTER observation against tested pin proposal',
    'pin_status': PLAN['pin_status'],
    'plan': {'path': str(PLAN_PATH), 'sha256': sha(PLAN_PATH)},
    'launcher': {'path': str(Path(__file__)), 'sha256': sha(Path(__file__))},
    'command': PLAN['command'], 'cwd': PLAN['cwd'], 'environment': PLAN['environment'],
    'environment_freeze_sha256': sha(FREEZE),
    'resolved_pins_and_client': PLAN['resolved_pins_and_client'],
    'started_utc': datetime.now(timezone.utc).isoformat(), 'identity_before': identities,
    'harness_sha256_before': sha(HARNESS), 'observer_sha256_before': sha(Path(PLAN['observer']['path'])),
    'disk_free_bytes_before': shutil.disk_usage(ROOT).free,
}
with LOG.open('xb') as stream:
    result = subprocess.run(PLAN['command'], cwd=PLAN['cwd'], env=environment,
                            stdout=stream, stderr=subprocess.STDOUT)
report.update({
    'exit_code': result.returncode, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'identity_after': {name: identity(path) for name, path in ROOTS.items()},
    'harness_sha256_after': sha(HARNESS), 'observer_sha256_after': sha(Path(PLAN['observer']['path'])),
    'disk_free_bytes_after': shutil.disk_usage(ROOT).free,
})
report['code_unchanged_during_run'] = report['identity_before'] == report['identity_after']
report['harness_unchanged_during_run'] = report['harness_sha256_before'] == report['harness_sha256_after']
report['observer_unchanged_during_run'] = report['observer_sha256_before'] == report['observer_sha256_after']
strict_checks = []
if OUTPUT.exists():
    observation = json.loads(OUTPUT.read_text())
    report['harness_status'] = observation['status']
    report['harness_code_unchanged'] = observation['code_unchanged']
    report['measurements'] = [{key: row[key] for key in (
        'bytes', 'sha256', 'fetch_count', 'producer', 'runtime_pre_delivery', 'runtime_transmit', 'caller',
        'cas_unchanged_after_caller_mutation', 'independent_caller_file', 'settlement_state',
        'task_status', 'runtime_primary_open_count', 'thumbnail_intent_count',
    )} for row in observation['measurements']]
    report['observer_loaded'] = observation['selected_modules'].get('tests._local_speed_hashes')
    if 'error' in observation:
        report['harness_error'] = observation['error']
    for row in observation['measurements']:
        checks = {
            'one_fetch': row['fetch_count'] == 1,
            'producer_one_hash_and_exact_bytes': row['producer']['completed_streams'] == 1 and row['producer']['bytes_hashed'] == row['bytes'],
            'caller_one_hash_and_exact_bytes': row['caller']['completed_streams'] == 1 and row['caller']['bytes_hashed'] == row['bytes'],
            'runtime_transmit_one_hash_and_exact_bytes': row['runtime_transmit']['completed_streams'] == 1 and row['runtime_transmit']['bytes_hashed'] == row['bytes'],
            'one_primary_open': row['runtime_primary_open_count'] == 1,
            'one_thumbnail_intent': row['thumbnail_intent_count'] == 1,
            'settlement_succeeded': row['settlement_state'] == 'succeeded',
            'task_completed': row['task_status'] == 'completed',
            'independent_caller_file': row['independent_caller_file'] is True,
            'cas_unchanged_after_caller_mutation': row['cas_unchanged_after_caller_mutation'] is True,
            'no_observer_coverage_gaps': all(not row[phase]['coverage_gaps'] for phase in ('producer', 'runtime_pre_delivery', 'runtime_transmit', 'caller')),
        }
        strict_checks.append({'bytes': row['bytes'], 'checks': checks})
report['strict_checks'] = strict_checks
report['strict_checks_passed'] = (len(strict_checks) == 2
    and [row['bytes'] for row in strict_checks] == [37, 9437197]
    and all(all(row['checks'].values()) for row in strict_checks))
report['artifacts'] = {str(path): {'sha256': sha(path), 'bytes': path.stat().st_size}
                       for path in (LOG, OUTPUT, FREEZE) if path.exists()}
report['status'] = ('passed_tested_pin_proposal' if result.returncode == 0
    and report.get('harness_status') == 'completed' and report.get('harness_code_unchanged')
    and report['code_unchanged_during_run'] and report['harness_unchanged_during_run']
    and report['observer_unchanged_during_run'] and report['strict_checks_passed'] else 'failed')
with METADATA.open('x') as stream:
    json.dump(report, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: report.get(key) for key in (
    'status', 'exit_code', 'harness_status', 'harness_error', 'code_unchanged_during_run',
    'strict_checks_passed', 'measurements', 'observer_loaded',
)}, indent=2))
print('metadata=' + str(METADATA))
print('metadata_sha256=' + sha(METADATA))
if report['status'] == 'failed':
    print(LOG.read_text()[-10000:])
sys.exit(0 if report['status'] != 'failed' else result.returncode or 1)
